# UniAssist AI - Production Deployment Guide

This guide covers deploying UniAssist AI to production environments.

## Table of Contents

1. [Pre-Deployment Checklist](#pre-deployment-checklist)
2. [Server Requirements](#server-requirements)
3. [Docker Deployment](#docker-deployment)
4. [Manual Deployment](#manual-deployment)
5. [Reverse Proxy Setup](#reverse-proxy-setup)
6. [SSL/TLS Configuration](#ssltls-configuration)
7. [Database Production Setup](#database-production-setup)
8. [Monitoring](#monitoring)
9. [Backup Strategy](#backup-strategy)
10. [Security Hardening](#security-hardening)
11. [Scaling](#scaling)

---

## Pre-Deployment Checklist

Before deploying to production, ensure:

- [ ] All environment variables are properly configured
- [ ] Database is secured with strong passwords
- [ ] SSL certificates are obtained
- [ ] Backup strategy is in place
- [ ] Monitoring is configured
- [ ] Security review completed
- [ ] Load testing performed

---

## Server Requirements

### Minimum Specifications

| Resource | Specification |
|----------|--------------|
| CPU | 2 cores |
| RAM | 4 GB |
| Storage | 20 GB SSD |
| Network | 100 Mbps |

### Recommended Specifications

| Resource | Specification |
|----------|--------------|
| CPU | 4 cores |
| RAM | 8 GB |
| Storage | 50 GB NVMe SSD |
| Network | 1 Gbps |

### Cloud Providers

Tested on:
- AWS (EC2, RDS, S3)
- Google Cloud (Compute Engine, Cloud SQL)
- DigitalOcean (Droplets, Managed Databases)
- Azure (VMs, Azure Database for PostgreSQL)

---

## Docker Deployment

### Production Docker Compose

Create `docker-compose.prod.yml`:

```yaml
version: '3.8'

services:
  postgres:
    image: postgres:15-alpine
    container_name: uniassist-db
    restart: always
    environment:
      POSTGRES_USER: ${DB_USER:-uniassist}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
      POSTGRES_DB: ${DB_NAME:-uniassist}
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./server/database/schema.sql:/docker-entrypoint-initdb.d/schema.sql:ro
    networks:
      - internal
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${DB_USER:-uniassist} -d ${DB_NAME:-uniassist}"]
      interval: 10s
      timeout: 5s
      retries: 5
    deploy:
      resources:
        limits:
          memory: 1G

  api:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: uniassist-api
    restart: always
    depends_on:
      postgres:
        condition: service_healthy
    environment:
      NODE_ENV: production
      PORT: 3001
      DATABASE_URL: postgresql://${DB_USER:-uniassist}:${DB_PASSWORD}@postgres:5432/${DB_NAME:-uniassist}
      JWT_SECRET: ${JWT_SECRET}
      JWT_REFRESH_SECRET: ${JWT_REFRESH_SECRET}
      ENCRYPTION_KEY: ${ENCRYPTION_KEY}
      TELEGRAM_BOT_TOKEN: ${TELEGRAM_BOT_TOKEN:-}
      STORAGE_PATH: /app/uploads
      CORS_ORIGIN: ${CORS_ORIGIN:-https://your-domain.com}
    volumes:
      - uploads_data:/app/uploads
    networks:
      - internal
      - web
    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost:3001/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    deploy:
      resources:
        limits:
          memory: 2G

  nginx:
    image: nginx:alpine
    container_name: uniassist-nginx
    restart: always
    depends_on:
      - api
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.prod.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/nginx/ssl:ro
      - ./certbot/conf:/etc/letsencrypt:ro
      - ./certbot/www:/var/www/certbot:ro
    networks:
      - web
    deploy:
      resources:
        limits:
          memory: 256M

  certbot:
    image: certbot/certbot
    container_name: uniassist-certbot
    volumes:
      - ./certbot/conf:/etc/letsencrypt
      - ./certbot/www:/var/www/certbot
    entrypoint: "/bin/sh -c 'trap exit TERM; while :; do certbot renew; sleep 12h & wait $${!}; done;'"

volumes:
  postgres_data:
  uploads_data:

networks:
  internal:
    driver: bridge
  web:
    driver: bridge
```

### Deploy Commands

```bash
# Build and start in production mode
docker-compose -f docker-compose.prod.yml up -d --build

# View logs
docker-compose -f docker-compose.prod.yml logs -f

# Scale API (if needed)
docker-compose -f docker-compose.prod.yml up -d --scale api=3

# Update deployment
docker-compose -f docker-compose.prod.yml pull
docker-compose -f docker-compose.prod.yml up -d --build

# Backup before update
docker-compose -f docker-compose.prod.yml exec postgres pg_dump -U uniassist uniassist > backup.sql
```

---

## Manual Deployment

### 1. Server Setup

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install PM2 for process management
sudo npm install -g pm2

# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Create application directory
sudo mkdir -p /var/www/uniassist
sudo chown $USER:$USER /var/www/uniassist
```

### 2. Deploy Application

```bash
# Clone repository
cd /var/www/uniassist
git clone https://github.com/your-org/uniassist-ai.git .

# Install dependencies
npm ci --production

# Build frontend
npm run build

# Configure environment
cp server/.env.example server/.env
nano server/.env  # Edit with production values

# Create uploads directory
mkdir -p uploads/documents uploads/audio
chmod 755 uploads
```

### 3. Setup PM2

Create `ecosystem.config.js`:

```javascript
module.exports = {
  apps: [{
    name: 'uniassist-api',
    script: 'npx',
    args: 'tsx server/index.ts',
    cwd: '/var/www/uniassist',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production'
    },
    error_file: '/var/log/uniassist/error.log',
    out_file: '/var/log/uniassist/out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    max_memory_restart: '1G',
    exp_backoff_restart_delay: 100
  }]
};
```

Start application:
```bash
# Create log directory
sudo mkdir -p /var/log/uniassist
sudo chown $USER:$USER /var/log/uniassist

# Start with PM2
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save

# Setup startup script
pm2 startup
```

---

## Reverse Proxy Setup

### Nginx Production Configuration

Create `/etc/nginx/sites-available/uniassist`:

```nginx
upstream api {
    least_conn;
    server 127.0.0.1:3001 weight=10 max_fails=3 fail_timeout=30s;
    keepalive 32;
}

server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    
    # Redirect to HTTPS
    location / {
        return 301 https://$server_name$request_uri;
    }
    
    # Let's Encrypt challenge
    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }
}

server {
    listen 443 ssl http2;
    server_name your-domain.com www.your-domain.com;

    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;
    ssl_session_timeout 1d;
    ssl_session_cache shared:SSL:50m;
    ssl_session_tickets off;

    # Modern SSL configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;

    # HSTS
    add_header Strict-Transport-Security "max-age=63072000" always;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Logging
    access_log /var/log/nginx/uniassist.access.log;
    error_log /var/log/nginx/uniassist.error.log;

    # File uploads
    client_max_body_size 25M;

    # Gzip
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml;

    # API proxy
    location /api/ {
        proxy_pass http://api;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300;
        proxy_connect_timeout 300;

        # Rate limiting
        limit_req zone=api burst=20 nodelay;
        limit_conn addr 10;
    }

    # Health check
    location /health {
        proxy_pass http://api/health;
        access_log off;
    }

    # Static files (if serving frontend from nginx)
    location / {
        root /var/www/uniassist/dist;
        try_files $uri $uri/ /index.html;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}

# Rate limiting zones
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
limit_conn_zone $binary_remote_addr zone=addr:10m;
```

Enable configuration:
```bash
sudo ln -s /etc/nginx/sites-available/uniassist /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## SSL/TLS Configuration

### Let's Encrypt (Recommended)

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Test renewal
sudo certbot renew --dry-run

# Setup auto-renewal
sudo systemctl enable certbot.timer
```

### Certificate Renewal Cron

```bash
# Add to crontab
echo "0 0 1 * * certbot renew --quiet && systemctl reload nginx" | sudo tee -a /etc/crontab
```

---

## Database Production Setup

### PostgreSQL Optimization

Edit `/etc/postgresql/15/main/postgresql.conf`:

```ini
# Memory
shared_buffers = 256MB
effective_cache_size = 768MB
work_mem = 16MB
maintenance_work_mem = 128MB

# Connections
max_connections = 100

# Write-ahead log
wal_buffers = 16MB
checkpoint_completion_target = 0.9

# Query planning
random_page_cost = 1.1
effective_io_concurrency = 200

# Logging
log_min_duration_statement = 1000
log_checkpoints = on
log_connections = on
log_disconnections = on
```

### Security Configuration

Edit `/etc/postgresql/15/main/pg_hba.conf`:

```
# Local connections
local   all   postgres   peer
local   all   uniassist  scram-sha-256

# Remote connections (if needed)
host    uniassist   uniassist   10.0.0.0/8   scram-sha-256
```

---

## Monitoring

### Health Check Endpoint

The API provides `/health` endpoint:

```bash
# Check health
curl https://your-domain.com/health

# Expected response
{
  "status": "healthy",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "database": "connected"
}
```

### PM2 Monitoring

```bash
# Real-time monitoring
pm2 monit

# Status
pm2 status

# Logs
pm2 logs uniassist-api
```

### Prometheus Metrics (Optional)

Add to server for metrics collection:

```bash
# Install prometheus-client
npm install prom-client
```

---

## Backup Strategy

### Database Backups

```bash
#!/bin/bash
# /etc/cron.daily/uniassist-backup

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR=/var/backups/uniassist
mkdir -p $BACKUP_DIR

# Database backup
pg_dump -U uniassist -Fc uniassist > $BACKUP_DIR/db_$DATE.dump

# Keep only last 7 days
find $BACKUP_DIR -name "*.dump" -mtime +7 -delete

# Upload to S3 (optional)
# aws s3 cp $BACKUP_DIR/db_$DATE.dump s3://your-bucket/backups/
```

### File Backups

```bash
# Backup uploads
tar -czf $BACKUP_DIR/uploads_$DATE.tar.gz /var/www/uniassist/uploads
```

### Restore

```bash
# Restore database
pg_restore -U uniassist -d uniassist backup.dump

# Restore files
tar -xzf uploads_backup.tar.gz -C /var/www/uniassist/
```

---

## Security Hardening

### Firewall (UFW)

```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

### Fail2ban

```bash
sudo apt install fail2ban

# Configure for nginx
cat > /etc/fail2ban/jail.local << EOF
[nginx-http-auth]
enabled = true

[nginx-limit-req]
enabled = true
EOF

sudo systemctl restart fail2ban
```

### Security Headers

Already configured in Nginx config above.

### Environment Security

```bash
# Restrict .env file
chmod 600 server/.env

# Use separate user
sudo useradd -r -s /bin/false uniassist
sudo chown -R uniassist:uniassist /var/www/uniassist
```

---

## Scaling

### Horizontal Scaling

1. **Load Balancer**: Use nginx upstream for multiple API instances
2. **Database**: Use PostgreSQL read replicas
3. **File Storage**: Move to S3/Cloud Storage
4. **Sessions**: Use Redis for session storage

### Kubernetes Deployment

See `kubernetes/` directory for Kubernetes manifests (coming soon).

---

## Troubleshooting

### Common Production Issues

#### High Memory Usage

```bash
# Check memory
free -h
pm2 monit

# Restart with memory limit
pm2 restart uniassist-api --max-memory-restart 1G
```

#### Database Connection Errors

```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Check connections
psql -U uniassist -c "SELECT count(*) FROM pg_stat_activity;"
```

#### SSL Certificate Issues

```bash
# Check certificate expiry
sudo certbot certificates

# Force renewal
sudo certbot renew --force-renewal
```

### Logs

```bash
# API logs
pm2 logs uniassist-api

# Nginx logs
sudo tail -f /var/log/nginx/uniassist.error.log

# PostgreSQL logs
sudo tail -f /var/log/postgresql/postgresql-15-main.log
```

---

## Updates

### Zero-Downtime Updates

```bash
# Pull latest code
cd /var/www/uniassist
git pull origin main

# Install dependencies
npm ci --production

# Build frontend
npm run build

# Reload PM2 gracefully
pm2 reload uniassist-api

# Or with zero-downtime
pm2 reload ecosystem.config.js --update-env
```

### Database Migrations

```bash
# Backup first
pg_dump -U uniassist uniassist > pre_migration_backup.sql

# Run migrations
psql -U uniassist -d uniassist -f migrations/001_update.sql
```
