# UniAssist AI

<div align="center">
  <h3>🎓 AI-Powered University Assistant</h3>
  <p>A comprehensive mobile-first application for managing academic life with AI integration</p>
</div>

---

## ✨ Features

### Core Features
| Feature | Description |
|---------|-------------|
| 🔐 **Authentication** | Secure login/registration with JWT tokens |
| 📚 **Course Management** | Add courses with schedules, instructors, and rooms |
| 📝 **Assignment Tracking** | Track assignments with priorities and deadlines |
| 📅 **Exam Scheduling** | Schedule exams with automatic reminders |
| 📊 **GPA Calculator** | Calculate cumulative and per-semester GPA |
| 📄 **Document Analysis** | Upload PDFs and extract assignments/exams with AI |
| 🎤 **Audio Transcription** | Convert voice recordings to text with Whisper AI |
| 🤖 **AI Chat Assistant** | Get study help using GPT-3.5/4 |

### Advanced Features
| Feature | Description |
|---------|-------------|
| 🔍 **Smart Detection** | Auto-detect deadlines from documents and voice |
| 🔔 **Notifications** | Multi-channel alerts (app + Telegram) |
| 📱 **Telegram Bot** | Full bot integration for mobile management |
| 🗃️ **Archive System** | Archive and restore any item |
| 🔎 **Full-Text Search** | Search across all your content |
| 🌍 **Bilingual** | English and Arabic support with RTL |
| 🌙 **Dark Mode** | Automatic theme switching |

---

## 🚀 Quick Start

### Option 1: Docker (Recommended)

```bash
# Clone repository
git clone https://github.com/your-org/uniassist-ai.git
cd uniassist-ai

# Configure environment
cp .env.example .env
# Edit .env with your settings

# Start services
docker-compose up -d

# Access at http://localhost:3001
```

### Option 2: Manual Setup

```bash
# Install dependencies
npm install

# Setup PostgreSQL database
createdb uniassist
psql -d uniassist -f server/database/schema.sql

# Configure environment
cp server/.env.example server/.env
# Edit server/.env with your settings

# Start development servers
npm run dev                    # Frontend (terminal 1)
npx tsx server/index.ts        # Backend (terminal 2)
```

---

## 📖 Documentation

- [**INSTALLATION.md**](./INSTALLATION.md) - Complete installation guide
- [**DEPLOYMENT.md**](./DEPLOYMENT.md) - Production deployment guide
- [**API Reference**](#api-reference) - REST API documentation

---

## 🛠️ Tech Stack

### Frontend
- **React 19** - UI framework
- **TypeScript** - Type safety
- **Vite** - Build tool
- **Tailwind CSS 4** - Styling
- **Lucide Icons** - Icons

### Backend
- **Node.js** - Runtime
- **Express 5** - Web framework
- **PostgreSQL** - Database
- **JWT** - Authentication
- **OpenAI** - AI features
- **Telegraf** - Telegram bot

---

## 📡 API Reference

### Authentication
```
POST   /api/auth/register   - Create account
POST   /api/auth/login      - Login
POST   /api/auth/refresh    - Refresh token
POST   /api/auth/logout     - Logout
GET    /api/auth/me         - Get profile
PATCH  /api/auth/me         - Update profile
GET    /api/auth/dashboard  - Get dashboard summary
```

### Courses
```
GET    /api/courses         - List courses
POST   /api/courses         - Create course
GET    /api/courses/:id     - Get course
PATCH  /api/courses/:id     - Update course
DELETE /api/courses/:id     - Delete course
GET    /api/courses/today   - Today's schedule
```

### Assignments
```
GET    /api/assignments          - List assignments
POST   /api/assignments          - Create assignment
GET    /api/assignments/:id      - Get assignment
PATCH  /api/assignments/:id      - Update assignment
DELETE /api/assignments/:id      - Delete assignment
POST   /api/assignments/:id/complete - Mark complete
GET    /api/assignments/upcoming - Upcoming deadlines
```

### Exams
```
GET    /api/exams           - List exams
POST   /api/exams           - Create exam
GET    /api/exams/:id       - Get exam
PATCH  /api/exams/:id       - Update exam
DELETE /api/exams/:id       - Delete exam
GET    /api/exams/upcoming  - Upcoming exams
```

### Grades
```
GET    /api/grades          - List grades
POST   /api/grades          - Add grade
DELETE /api/grades/:id      - Delete grade
GET    /api/grades/gpa      - Calculate GPA
```

### Documents
```
GET    /api/documents           - List documents
POST   /api/documents           - Upload document
GET    /api/documents/:id       - Get document
DELETE /api/documents/:id       - Delete document
POST   /api/documents/:id/ask   - Ask about document
```

### Audio Transcription
```
GET    /api/audio              - List transcriptions
POST   /api/audio/transcribe   - Upload & transcribe audio
GET    /api/audio/:id          - Get transcription
DELETE /api/audio/:id          - Delete transcription
```

### Chat
```
GET    /api/chat/history    - Get chat history
POST   /api/chat/message    - Send message
DELETE /api/chat/history    - Clear history
```

### Notifications
```
GET    /api/notifications             - List notifications
GET    /api/notifications/unread-count - Unread count
POST   /api/notifications/:id/read    - Mark as read
POST   /api/notifications/read-all    - Mark all read
```

### Search
```
GET    /api/search              - Global search
GET    /api/search/suggestions  - Get suggestions
```

### Archives
```
GET    /api/archives            - List archives
POST   /api/archives/:id/restore - Restore item
DELETE /api/archives/:id        - Permanently delete
```

---

## 🤖 Telegram Bot Commands

| Command | Description |
|---------|-------------|
| `/start` | Link your account |
| `/add_assignment` | Add assignment (Title \| Due Date) |
| `/add_exam` | Add exam (Title \| Date \| Time) |
| `/schedule` | View today's schedule |
| `/deadlines` | View upcoming deadlines |
| `/ask` | Ask AI a question |
| `/unlink` | Unlink account |

**Voice Messages**: Send voice messages - the bot will transcribe them and auto-detect any assignments or exams mentioned.

---

## ⚙️ Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | ✅ | PostgreSQL connection string |
| `JWT_SECRET` | ✅ | JWT signing secret (32+ chars) |
| `JWT_REFRESH_SECRET` | ✅ | Refresh token secret (32+ chars) |
| `ENCRYPTION_KEY` | ✅ | Data encryption key (32+ chars) |
| `STORAGE_PATH` | ✅ | File upload directory |
| `TELEGRAM_BOT_TOKEN` | ❌ | Telegram bot API token |
| `OPENAI_API_KEY` | ❌ | Default OpenAI API key |

See [.env.example](./.env.example) for full configuration options.

---

## 🔒 Security

- JWT-based authentication with refresh tokens
- Password hashing with bcrypt (12 rounds)
- API key encryption with AES-256-GCM
- SQL injection protection with parameterized queries
- Rate limiting support
- CORS configuration
- Session management

---

## 📱 Mobile Support

The application is designed as a mobile-first Progressive Web App (PWA):

- Responsive design optimized for phones
- Touch-friendly interface
- Offline capability (frontend)
- Add to home screen support
- Native-like experience

---

## 🌐 Language Support

- **English** - Full support
- **Arabic** - Full support with RTL layout

Users can switch languages in settings. The AI chat automatically responds in the same language as the user's message.

---

## 📝 License

MIT License - See [LICENSE](./LICENSE) file for details.

---

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 🆘 Support

- **Issues**: [GitHub Issues](https://github.com/your-org/uniassist-ai/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-org/uniassist-ai/discussions)

---

<div align="center">
  <p>Made with ❤️ for students everywhere</p>
</div>
