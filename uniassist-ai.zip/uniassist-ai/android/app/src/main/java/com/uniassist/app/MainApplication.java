package com.uniassist.app;

import android.app.Application;
import com.getcapacitor.BridgeActivity;

public class MainApplication extends Application {
}
