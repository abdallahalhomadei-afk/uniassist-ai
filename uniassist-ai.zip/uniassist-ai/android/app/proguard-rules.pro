# Add project specific ProGuard rules here.
-keep class com.getcapacitor.** { *; }
-keep class com.uniassist.app.** { *; }
