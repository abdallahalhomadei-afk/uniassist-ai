import { createContext, useContext, useReducer, useEffect, useCallback, type ReactNode, useRef } from 'react';
import type { User, ChatMessage, Course, Assignment, Exam, GradeEntry, UploadedDocument, Page, Language, Theme } from './types';
import { translations, type TranslationKey } from './i18n';
import api from './api/client';

interface AppState {
  user: User | null;
  isAuthenticated: boolean;
  currentPage: Page;
  theme: Theme;
  language: Language;
  courses: Course[];
  assignments: Assignment[];
  exams: Exam[];
  grades: GradeEntry[];
  chatMessages: ChatMessage[];
  documents: UploadedDocument[];
  notifications: boolean;
  loading: boolean;
  syncing: boolean;
  error: string | null;
}

type Action =
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'SET_AUTH'; payload: boolean }
  | { type: 'SET_PAGE'; payload: Page }
  | { type: 'SET_THEME'; payload: Theme }
  | { type: 'SET_LANGUAGE'; payload: Language }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_SYNCING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'SET_COURSES'; payload: Course[] }
  | { type: 'ADD_COURSE'; payload: Course }
  | { type: 'UPDATE_COURSE'; payload: Course }
  | { type: 'DELETE_COURSE'; payload: string }
  | { type: 'SET_ASSIGNMENTS'; payload: Assignment[] }
  | { type: 'ADD_ASSIGNMENT'; payload: Assignment }
  | { type: 'UPDATE_ASSIGNMENT'; payload: Assignment }
  | { type: 'DELETE_ASSIGNMENT'; payload: string }
  | { type: 'SET_EXAMS'; payload: Exam[] }
  | { type: 'ADD_EXAM'; payload: Exam }
  | { type: 'DELETE_EXAM'; payload: string }
  | { type: 'SET_GRADES'; payload: GradeEntry[] }
  | { type: 'ADD_GRADE'; payload: GradeEntry }
  | { type: 'DELETE_GRADE'; payload: string }
  | { type: 'ADD_CHAT_MESSAGE'; payload: ChatMessage }
  | { type: 'SET_CHAT_MESSAGES'; payload: ChatMessage[] }
  | { type: 'CLEAR_CHAT'; }
  | { type: 'SET_DOCUMENTS'; payload: UploadedDocument[] }
  | { type: 'ADD_DOCUMENT'; payload: UploadedDocument }
  | { type: 'DELETE_DOCUMENT'; payload: string }
  | { type: 'SET_NOTIFICATIONS'; payload: boolean }
  | { type: 'HYDRATE'; payload: Partial<AppState> }
  | { type: 'LOGOUT' };

const initialState: AppState = {
  user: null,
  isAuthenticated: false,
  currentPage: 'home',
  theme: 'light',
  language: 'en',
  courses: [],
  assignments: [],
  exams: [],
  grades: [],
  chatMessages: [],
  documents: [],
  notifications: true,
  loading: false,
  syncing: false,
  error: null,
};

function loadPersisted(): Partial<AppState> {
  try {
    const saved = localStorage.getItem('uniassist_state');
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        theme: parsed.theme,
        language: parsed.language,
        notifications: parsed.notifications,
        courses: parsed.courses || [],
        assignments: parsed.assignments || [],
        exams: parsed.exams || [],
        grades: parsed.grades || [],
        chatMessages: parsed.chatMessages || [],
        documents: parsed.documents || [],
      };
    }
  } catch {}
  return {};
}

function persistState(state: AppState) {
  try {
    const toSave = {
      theme: state.theme,
      language: state.language,
      notifications: state.notifications,
      courses: state.courses,
      assignments: state.assignments,
      exams: state.exams,
      grades: state.grades,
      chatMessages: state.chatMessages,
      documents: state.documents,
    };
    localStorage.setItem('uniassist_state', JSON.stringify(toSave));
  } catch {}
}

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'SET_USER': return { ...state, user: action.payload };
    case 'SET_AUTH': return { ...state, isAuthenticated: action.payload };
    case 'SET_PAGE': return { ...state, currentPage: action.payload };
    case 'SET_THEME': return { ...state, theme: action.payload };
    case 'SET_LANGUAGE': return { ...state, language: action.payload };
    case 'SET_LOADING': return { ...state, loading: action.payload };
    case 'SET_SYNCING': return { ...state, syncing: action.payload };
    case 'SET_ERROR': return { ...state, error: action.payload };
    case 'SET_COURSES': return { ...state, courses: action.payload };
    case 'ADD_COURSE': return { ...state, courses: [...state.courses, action.payload] };
    case 'UPDATE_COURSE': return { ...state, courses: state.courses.map(c => c.id === action.payload.id ? action.payload : c) };
    case 'DELETE_COURSE': return { ...state, courses: state.courses.filter(c => c.id !== action.payload) };
    case 'SET_ASSIGNMENTS': return { ...state, assignments: action.payload };
    case 'ADD_ASSIGNMENT': return { ...state, assignments: [...state.assignments, action.payload] };
    case 'UPDATE_ASSIGNMENT': return { ...state, assignments: state.assignments.map(a => a.id === action.payload.id ? action.payload : a) };
    case 'DELETE_ASSIGNMENT': return { ...state, assignments: state.assignments.filter(a => a.id !== action.payload) };
    case 'SET_EXAMS': return { ...state, exams: action.payload };
    case 'ADD_EXAM': return { ...state, exams: [...state.exams, action.payload] };
    case 'DELETE_EXAM': return { ...state, exams: state.exams.filter(e => e.id !== action.payload) };
    case 'SET_GRADES': return { ...state, grades: action.payload };
    case 'ADD_GRADE': return { ...state, grades: [...state.grades, action.payload] };
    case 'DELETE_GRADE': return { ...state, grades: state.grades.filter(g => g.id !== action.payload) };
    case 'ADD_CHAT_MESSAGE': return { ...state, chatMessages: [...state.chatMessages, action.payload] };
    case 'SET_CHAT_MESSAGES': return { ...state, chatMessages: action.payload };
    case 'CLEAR_CHAT': return { ...state, chatMessages: [] };
    case 'SET_DOCUMENTS': return { ...state, documents: action.payload };
    case 'ADD_DOCUMENT': return { ...state, documents: [...state.documents, action.payload] };
    case 'DELETE_DOCUMENT': return { ...state, documents: state.documents.filter(d => d.id !== action.payload) };
    case 'SET_NOTIFICATIONS': return { ...state, notifications: action.payload };
    case 'HYDRATE': return { ...state, ...action.payload };
    case 'LOGOUT': return { ...initialState, theme: state.theme, language: state.language };
    default: return state;
  }
}

interface AppContextType {
  state: AppState;
  dispatch: (action: Action) => void;
  t: (key: TranslationKey) => string;
  // Auth actions
  login: (email: string, password: string) => Promise<void>;
  register: (data: { email: string; password: string; name: string; university?: string; major?: string }) => Promise<void>;
  logout: () => Promise<void>;
  // Data actions
  syncAll: () => Promise<void>;
  // Courses
  createCourse: (data: any) => Promise<Course>;
  deleteCourse: (id: string) => Promise<void>;
  // Assignments
  createAssignment: (data: any) => Promise<Assignment>;
  updateAssignment: (id: string, data: any) => Promise<Assignment>;
  completeAssignment: (id: string) => Promise<void>;
  deleteAssignment: (id: string) => Promise<void>;
  // Exams
  createExam: (data: any) => Promise<Exam>;
  deleteExam: (id: string) => Promise<void>;
  // Grades
  createGrade: (data: any) => Promise<GradeEntry>;
  deleteGrade: (id: string) => Promise<void>;
  getGPA: () => Promise<any>;
  // Chat
  sendChatMessage: (message: string) => Promise<string>;
  clearChat: () => Promise<void>;
  // Documents
  uploadDocument: (file: File, courseId?: string) => Promise<UploadedDocument>;
  deleteDocument: (id: string) => Promise<void>;
  // Settings
  updateProfile: (data: any) => Promise<void>;
  setApiKey: (key: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined, () => {
    const persisted = loadPersisted();
    // Check for existing tokens
    const hasTokens = localStorage.getItem('uniassist_tokens') !== null;
    return {
      ...initialState,
      ...persisted,
      isAuthenticated: hasTokens,
    };
  });

  const initializedRef = useRef(false);

  const t = (key: TranslationKey): string => {
    return translations[state.language][key] || translations.en[key] || key;
  };

  // Apply theme and language to DOM
  useEffect(() => {
    document.documentElement.classList.toggle('dark', state.theme === 'dark');
    document.documentElement.dir = state.language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = state.language;
    if (state.language === 'ar') {
      document.body.style.fontFamily = "'Cairo', 'Inter', system-ui, sans-serif";
    } else {
      document.body.style.fontFamily = "'Inter', system-ui, sans-serif";
    }
  }, [state.theme, state.language]);

  // Persist state changes
  useEffect(() => {
    persistState(state);
  }, [state]);

  // Initialize - fetch user and sync data on auth
  useEffect(() => {
    if (state.isAuthenticated && api.isAuthenticated() && !initializedRef.current) {
      initializedRef.current = true;
      syncAll();
    }
    if (!state.isAuthenticated) {
      initializedRef.current = false;
    }
  }, [state.isAuthenticated]);

  const syncAll = useCallback(async () => {
    if (!api.isAuthenticated()) return;
    dispatch({ type: 'SET_SYNCING', payload: true });
    dispatch({ type: 'SET_ERROR', payload: null });
    
    try {
      const [profile, coursesResult, assignmentsResult, examsResult, gradesResult] = await Promise.allSettled([
        api.getProfile(),
        api.getCourses(),
        api.getAssignments(),
        api.getExams(),
        api.getGrades(),
      ]);

      if (profile.status === 'fulfilled') {
        dispatch({ type: 'SET_USER', payload: profile.value });
      }
      if (coursesResult.status === 'fulfilled') {
        // Transform course schedules
        const courses = coursesResult.value.map((c: any) => ({
          id: c.id,
          name: c.name,
          code: c.code,
          instructor: c.instructor || '',
          color: c.color || '#3b82f6',
          credits: c.credits || 3,
          schedule: (c.schedules || []).map((s: any) => ({
            day: ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'][s.day_of_week] || 'sunday',
            startTime: s.start_time?.slice(0, 5) || '08:00',
            endTime: s.end_time?.slice(0, 5) || '09:30',
            room: s.room || '',
          })),
          created_at: c.created_at,
        }));
        dispatch({ type: 'SET_COURSES', payload: courses });
      }
      if (assignmentsResult.status === 'fulfilled') {
        dispatch({ type: 'SET_ASSIGNMENTS', payload: assignmentsResult.value });
      }
      if (examsResult.status === 'fulfilled') {
        dispatch({ type: 'SET_EXAMS', payload: examsResult.value });
      }
      if (gradesResult.status === 'fulfilled') {
        dispatch({ type: 'SET_GRADES', payload: gradesResult.value });
      }
    } catch (err: any) {
      dispatch({ type: 'SET_ERROR', payload: err.message || 'Sync failed' });
    } finally {
      dispatch({ type: 'SET_SYNCING', payload: false });
    }
  }, []);

  // Auth actions
  const login = useCallback(async (email: string, password: string) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    dispatch({ type: 'SET_ERROR', payload: null });
    try {
      const result = await api.login({ email, password });
      dispatch({ type: 'SET_USER', payload: result.user });
      dispatch({ type: 'SET_AUTH', payload: true });
    } catch (err: any) {
      dispatch({ type: 'SET_ERROR', payload: err.message || 'Login failed' });
      throw err;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  }, []);

  const register = useCallback(async (data: { email: string; password: string; name: string; university?: string; major?: string }) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    dispatch({ type: 'SET_ERROR', payload: null });
    try {
      const result = await api.register(data);
      dispatch({ type: 'SET_USER', payload: result.user });
      dispatch({ type: 'SET_AUTH', payload: true });
    } catch (err: any) {
      dispatch({ type: 'SET_ERROR', payload: err.message || 'Registration failed' });
      throw err;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  }, []);

  const logout = useCallback(async () => {
    try { await api.logout(); } catch {}
    dispatch({ type: 'LOGOUT' });
  }, []);

  // Course actions
  const createCourse = useCallback(async (data: any) => {
    const course = await api.createCourse(data);
    const normalized: Course = {
      id: course.id,
      name: course.name,
      code: course.code,
      instructor: course.instructor || '',
      color: course.color || '#3b82f6',
      credits: course.credits || 3,
      schedule: (course.schedules || []).map((s: any) => ({
        day: ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'][s.day_of_week] || 'sunday',
        startTime: s.start_time?.slice(0, 5) || '08:00',
        endTime: s.end_time?.slice(0, 5) || '09:30',
        room: s.room || '',
      })),
    };
    dispatch({ type: 'ADD_COURSE', payload: normalized });
    return normalized;
  }, []);

  const deleteCourse = useCallback(async (id: string) => {
    await api.deleteCourse(id);
    dispatch({ type: 'DELETE_COURSE', payload: id });
  }, []);

  // Assignment actions
  const createAssignment = useCallback(async (data: any) => {
    const assignment = await api.createAssignment(data);
    dispatch({ type: 'ADD_ASSIGNMENT', payload: assignment });
    return assignment;
  }, []);

  const updateAssignment = useCallback(async (id: string, data: any) => {
    const assignment = await api.updateAssignment(id, data);
    dispatch({ type: 'UPDATE_ASSIGNMENT', payload: assignment });
    return assignment;
  }, []);

  const completeAssignment = useCallback(async (id: string) => {
    const assignment = await api.completeAssignment(id);
    dispatch({ type: 'UPDATE_ASSIGNMENT', payload: assignment });
  }, []);

  const deleteAssignment = useCallback(async (id: string) => {
    await api.deleteAssignment(id);
    dispatch({ type: 'DELETE_ASSIGNMENT', payload: id });
  }, []);

  // Exam actions
  const createExam = useCallback(async (data: any) => {
    const exam = await api.createExam(data);
    dispatch({ type: 'ADD_EXAM', payload: exam });
    return exam;
  }, []);

  const deleteExam = useCallback(async (id: string) => {
    await api.deleteExam(id);
    dispatch({ type: 'DELETE_EXAM', payload: id });
  }, []);

  // Grade actions
  const createGrade = useCallback(async (data: any) => {
    const grade = await api.createGrade(data);
    dispatch({ type: 'ADD_GRADE', payload: grade });
    return grade;
  }, []);

  const deleteGrade = useCallback(async (id: string) => {
    await api.deleteGrade(id);
    dispatch({ type: 'DELETE_GRADE', payload: id });
  }, []);

  const getGPA = useCallback(async () => {
    return api.getGPA();
  }, []);

  // Chat actions
  const sendChatMessage = useCallback(async (message: string) => {
    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: message,
      timestamp: new Date().toISOString(),
    };
    dispatch({ type: 'ADD_CHAT_MESSAGE', payload: userMsg });

    try {
      const response = await api.sendChatMessage(message);
      const assistantMsg: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: response.message,
        timestamp: new Date().toISOString(),
      };
      dispatch({ type: 'ADD_CHAT_MESSAGE', payload: assistantMsg });
      return response.message;
    } catch (err: any) {
      const errorMsg: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: `Error: ${err.message || 'Failed to send message'}`,
        timestamp: new Date().toISOString(),
      };
      dispatch({ type: 'ADD_CHAT_MESSAGE', payload: errorMsg });
      throw err;
    }
  }, []);

  const clearChat = useCallback(async () => {
    try { await api.clearChatHistory(); } catch {}
    dispatch({ type: 'CLEAR_CHAT' });
  }, []);

  // Document actions
  const uploadDocument = useCallback(async (file: File, courseId?: string) => {
    const doc = await api.uploadDocument(file, courseId);
    const uploadedDoc: UploadedDocument = {
      id: doc.id,
      name: doc.original_filename,
      size: doc.file_size,
      type: doc.mime_type,
      content: doc.content_text || '',
      uploadedAt: doc.created_at,
      summary: doc.summary,
    };
    dispatch({ type: 'ADD_DOCUMENT', payload: uploadedDoc });
    return uploadedDoc;
  }, []);

  const deleteDocument = useCallback(async (id: string) => {
    await api.deleteDocument(id);
    dispatch({ type: 'DELETE_DOCUMENT', payload: id });
  }, []);

  // Settings
  const updateProfile = useCallback(async (data: any) => {
    const profile = await api.updateProfile(data);
    dispatch({ type: 'SET_USER', payload: profile });
  }, []);

  const setApiKey = useCallback(async (key: string) => {
    await api.setApiKey(key);
  }, []);

  return (
    <AppContext.Provider value={{
      state,
      dispatch,
      t,
      login,
      register,
      logout,
      syncAll,
      createCourse,
      deleteCourse,
      createAssignment,
      updateAssignment,
      completeAssignment,
      deleteAssignment,
      createExam,
      deleteExam,
      createGrade,
      deleteGrade,
      getGPA,
      sendChatMessage,
      clearChat,
      uploadDocument,
      deleteDocument,
      updateProfile,
      setApiKey,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
