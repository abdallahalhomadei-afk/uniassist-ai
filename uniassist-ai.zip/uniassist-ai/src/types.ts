export interface User {
  id: string;
  name: string;
  email: string;
  university: string;
  major: string;
  avatar?: string;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface Course {
  id: string;
  name: string;
  code: string;
  instructor: string;
  color: string;
  schedule: CourseSchedule[];
  credits: number;
}

export interface CourseSchedule {
  day: string;
  startTime: string;
  endTime: string;
  room: string;
}

export interface Assignment {
  id: string;
  title: string;
  courseId: string;
  courseName: string;
  dueDate: string;
  description: string;
  status: 'pending' | 'in-progress' | 'completed' | 'overdue';
  priority: 'low' | 'medium' | 'high';
}

export interface Exam {
  id: string;
  title: string;
  courseId: string;
  courseName: string;
  date: string;
  time: string;
  duration: string;
  room: string;
  type: 'midterm' | 'final' | 'quiz';
  notes: string;
}

export interface GradeEntry {
  id: string;
  courseName: string;
  courseCode: string;
  credits: number;
  grade: string;
  semester: string;
}

export interface UploadedDocument {
  id: string;
  name: string;
  size: number;
  type: string;
  content: string;
  uploadedAt: string;
  summary?: string;
}

export type Page = 'home' | 'chat' | 'courses' | 'assignments' | 'exams' | 'gpa' | 'documents' | 'settings';

export type Language = 'en' | 'ar';

export type Theme = 'light' | 'dark';
