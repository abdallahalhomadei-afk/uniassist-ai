import { useState, useCallback } from 'react';
import api from '../api/client';

export function useApi<T = any>() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<T | null>(null);

  const execute = useCallback(async (
    apiCall: () => Promise<T>,
    options: { onSuccess?: (data: T) => void; onError?: (error: string) => void } = {}
  ) => {
    setLoading(true);
    setError(null);
    try {
      const result = await apiCall();
      setData(result);
      options.onSuccess?.(result);
      return result;
    } catch (err: any) {
      const errorMessage = err.message || 'An error occurred';
      setError(errorMessage);
      options.onError?.(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const reset = useCallback(() => {
    setLoading(false);
    setError(null);
    setData(null);
  }, []);

  return { loading, error, data, execute, reset };
}

// Specific hooks for common operations
export function useAuth() {
  const { loading, error, execute } = useApi();

  const login = useCallback(async (email: string, password: string) => {
    return execute(() => api.login({ email, password }));
  }, [execute]);

  const register = useCallback(async (data: {
    email: string;
    password: string;
    name: string;
    university?: string;
    major?: string;
  }) => {
    return execute(() => api.register(data));
  }, [execute]);

  const logout = useCallback(async () => {
    return execute(() => api.logout());
  }, [execute]);

  return { login, register, logout, loading, error };
}

export function useCourses() {
  const { loading, error, data, execute } = useApi();

  const fetchCourses = useCallback(() => {
    return execute(() => api.getCourses());
  }, [execute]);

  const createCourse = useCallback((data: any) => {
    return execute(() => api.createCourse(data));
  }, [execute]);

  const updateCourse = useCallback((id: string, data: any) => {
    return execute(() => api.updateCourse(id, data));
  }, [execute]);

  const deleteCourse = useCallback((id: string) => {
    return execute(() => api.deleteCourse(id));
  }, [execute]);

  return { courses: data, fetchCourses, createCourse, updateCourse, deleteCourse, loading, error };
}

export function useAssignments() {
  const { loading, error, data, execute } = useApi();

  const fetchAssignments = useCallback((options?: { status?: string; upcoming?: boolean }) => {
    return execute(() => api.getAssignments(options));
  }, [execute]);

  const createAssignment = useCallback((data: any) => {
    return execute(() => api.createAssignment(data));
  }, [execute]);

  const updateAssignment = useCallback((id: string, data: any) => {
    return execute(() => api.updateAssignment(id, data));
  }, [execute]);

  const deleteAssignment = useCallback((id: string) => {
    return execute(() => api.deleteAssignment(id));
  }, [execute]);

  const completeAssignment = useCallback((id: string) => {
    return execute(() => api.completeAssignment(id));
  }, [execute]);

  return { assignments: data, fetchAssignments, createAssignment, updateAssignment, deleteAssignment, completeAssignment, loading, error };
}

export function useExams() {
  const { loading, error, data, execute } = useApi();

  const fetchExams = useCallback((options?: { upcoming?: boolean }) => {
    return execute(() => api.getExams(options));
  }, [execute]);

  const createExam = useCallback((data: any) => {
    return execute(() => api.createExam(data));
  }, [execute]);

  const updateExam = useCallback((id: string, data: any) => {
    return execute(() => api.updateExam(id, data));
  }, [execute]);

  const deleteExam = useCallback((id: string) => {
    return execute(() => api.deleteExam(id));
  }, [execute]);

  return { exams: data, fetchExams, createExam, updateExam, deleteExam, loading, error };
}

export function useGrades() {
  const { loading, error, data, execute } = useApi();

  const fetchGrades = useCallback((semester?: string) => {
    return execute(() => api.getGrades(semester));
  }, [execute]);

  const fetchGPA = useCallback(() => {
    return execute(() => api.getGPA());
  }, [execute]);

  const createGrade = useCallback((data: any) => {
    return execute(() => api.createGrade(data));
  }, [execute]);

  const deleteGrade = useCallback((id: string) => {
    return execute(() => api.deleteGrade(id));
  }, [execute]);

  return { grades: data, fetchGrades, fetchGPA, createGrade, deleteGrade, loading, error };
}

export function useDocuments() {
  const { loading, error, data, execute } = useApi();

  const fetchDocuments = useCallback(() => {
    return execute(() => api.getDocuments());
  }, [execute]);

  const uploadDocument = useCallback((file: File, courseId?: string) => {
    return execute(() => api.uploadDocument(file, courseId));
  }, [execute]);

  const deleteDocument = useCallback((id: string) => {
    return execute(() => api.deleteDocument(id));
  }, [execute]);

  const askAboutDocument = useCallback((id: string, question: string) => {
    return execute(() => api.askAboutDocument(id, question));
  }, [execute]);

  return { documents: data, fetchDocuments, uploadDocument, deleteDocument, askAboutDocument, loading, error };
}

export function useChat() {
  const { loading, error, execute } = useApi();

  const sendMessage = useCallback((message: string) => {
    return execute(() => api.sendChatMessage(message));
  }, [execute]);

  const fetchHistory = useCallback(() => {
    return execute(() => api.getChatHistory());
  }, [execute]);

  const clearHistory = useCallback(() => {
    return execute(() => api.clearChatHistory());
  }, [execute]);

  return { sendMessage, fetchHistory, clearHistory, loading, error };
}

export function useSearch() {
  const { loading, error, data, execute } = useApi();

  const search = useCallback((query: string, types?: string[]) => {
    return execute(() => api.search(query, types));
  }, [execute]);

  const getSuggestions = useCallback((query: string) => {
    return execute(() => api.getSearchSuggestions(query));
  }, [execute]);

  return { results: data, search, getSuggestions, loading, error };
}

export function useNotifications() {
  const { loading, error, data, execute } = useApi();

  const fetchNotifications = useCallback((unreadOnly = false) => {
    return execute(() => api.getNotifications(unreadOnly));
  }, [execute]);

  const getUnreadCount = useCallback(() => {
    return execute(() => api.getUnreadCount());
  }, [execute]);

  const markAsRead = useCallback((id: string) => {
    return execute(() => api.markNotificationRead(id));
  }, [execute]);

  const markAllAsRead = useCallback(() => {
    return execute(() => api.markAllNotificationsRead());
  }, [execute]);

  return { notifications: data, fetchNotifications, getUnreadCount, markAsRead, markAllAsRead, loading, error };
}
