import { AppProvider, useApp } from './store';
import AuthPage from './components/AuthPage';
import HomePage from './components/HomePage';
import ChatPage from './components/ChatPage';
import CoursesPage from './components/CoursesPage';
import AssignmentsPage from './components/AssignmentsPage';
import ExamsPage from './components/ExamsPage';
import GPAPage from './components/GPAPage';
import DocumentsPage from './components/DocumentsPage';
import SettingsPage from './components/SettingsPage';
import BottomNav from './components/BottomNav';

function AppContent() {
  const { state } = useApp();

  if (!state.isAuthenticated) {
    return <AuthPage />;
  }

  const renderPage = () => {
    switch (state.currentPage) {
      case 'home': return <HomePage />;
      case 'chat': return <ChatPage />;
      case 'courses': return <CoursesPage />;
      case 'assignments': return <AssignmentsPage />;
      case 'exams': return <ExamsPage />;
      case 'gpa': return <GPAPage />;
      case 'documents': return <DocumentsPage />;
      case 'settings': return <SettingsPage />;
      default: return <HomePage />;
    }
  };

  const hideNav = state.currentPage === 'chat';

  return (
    <div className={`h-full flex flex-col bg-gray-50 dark:bg-gray-900 ${state.language === 'ar' ? 'font-arabic' : 'font-sans'}`}>
      <div className="flex-1 overflow-hidden">
        {renderPage()}
      </div>
      {!hideNav && <BottomNav />}
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <div className="h-screen w-screen max-w-lg mx-auto bg-white dark:bg-gray-900 shadow-2xl relative overflow-hidden">
        <AppContent />
      </div>
    </AppProvider>
  );
}
