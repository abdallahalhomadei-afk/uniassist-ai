import { useState, useRef, useEffect } from 'react';
import { useApp } from '../store';
import { Send, Trash2, Bot, User, Sparkles, ArrowLeft, Loader2 } from 'lucide-react';

export default function ChatPage() {
  const { state, dispatch, t, sendChatMessage, clearChat } = useApp();
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [state.chatMessages, isTyping]);

  const handleSend = async () => {
    const text = input.trim();
    if (!text || isTyping) return;
    setInput('');
    setIsTyping(true);
    try {
      await sendChatMessage(text);
    } catch {
      // Error message already added to chat
    } finally {
      setIsTyping(false);
    }
    if (inputRef.current) inputRef.current.style.height = 'auto';
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    e.target.style.height = 'auto';
    e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px';
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const renderContent = (content: string) => {
    const lines = content.split('\n');
    return lines.map((line, i) => {
      let processed = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
      processed = processed.replace(/`(.*?)`/g, '<code class="bg-gray-100 dark:bg-gray-700 px-1.5 py-0.5 rounded text-sm font-mono">$1</code>');
      if (!processed.trim()) return <br key={i} />;
      return <p key={i} className="mb-1" dangerouslySetInnerHTML={{ __html: processed }} />;
    });
  };

  return (
    <div className="h-full flex flex-col bg-gray-50 dark:bg-gray-900">
      <div className="flex-shrink-0 bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => dispatch({ type: 'SET_PAGE', payload: 'home' })} className="p-1.5 -ml-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
            <ArrowLeft className="w-5 h-5 text-gray-600 dark:text-gray-400 rtl:rotate-180" />
          </button>
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-gray-900 dark:text-white text-sm">{t('chatTitle')}</h1>
            <p className="text-xs text-green-500 font-medium">{isTyping ? t('typing') : '● Online'}</p>
          </div>
        </div>
        <button onClick={clearChat} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-xl transition-colors">
          <Trash2 className="w-5 h-5 text-gray-400" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {state.chatMessages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center px-4 animate-fade-in">
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center mb-4 shadow-lg shadow-primary-500/30">
              <Sparkles className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{t('chatTitle')}</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-4 leading-relaxed">{t('chatWelcome')}</p>
            <div className="space-y-2 w-full max-w-xs">
              {[t('chatFeature1'), t('chatFeature2'), t('chatFeature3'), t('chatFeature4'), t('chatFeature5')].map((f, i) => (
                <div key={i} className="bg-white dark:bg-gray-800 rounded-xl px-4 py-2.5 text-sm text-gray-700 dark:text-gray-300 shadow-sm text-left rtl:text-right">{f}</div>
              ))}
            </div>
          </div>
        )}

        {state.chatMessages.map(msg => (
          <div key={msg.id} className={`flex gap-2.5 animate-fade-in ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${msg.role === 'user' ? 'bg-primary-600 text-white' : 'bg-gradient-to-br from-primary-500 to-primary-700 text-white'}`}>
              {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>
            <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${msg.role === 'user' ? 'bg-primary-600 text-white rounded-br-md rtl:rounded-br-2xl rtl:rounded-bl-md' : 'bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 shadow-sm border border-gray-100 dark:border-gray-700 rounded-bl-md rtl:rounded-bl-2xl rtl:rounded-br-md'}`}>
              <div className="text-sm leading-relaxed">{renderContent(msg.content)}</div>
              <p className={`text-[10px] mt-1.5 ${msg.role === 'user' ? 'text-primary-200' : 'text-gray-400 dark:text-gray-500'}`}>{formatTime(msg.timestamp)}</p>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex gap-2.5 animate-fade-in">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-2xl rounded-bl-md px-5 py-4 shadow-sm border border-gray-100 dark:border-gray-700">
              <Loader2 className="w-4 h-4 text-gray-400 animate-spin" />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="flex-shrink-0 bg-white dark:bg-gray-800 border-t border-gray-100 dark:border-gray-700 px-4 py-3">
        <div className="flex items-end gap-2">
          <div className="flex-1 bg-gray-50 dark:bg-gray-700 rounded-2xl border border-gray-200 dark:border-gray-600 overflow-hidden">
            <textarea
              ref={inputRef}
              value={input}
              onChange={handleInput}
              onKeyDown={handleKeyDown}
              placeholder={t('chatPlaceholder')}
              rows={1}
              className="w-full px-4 py-3 bg-transparent text-gray-900 dark:text-white placeholder-gray-400 resize-none focus:outline-none text-sm"
              style={{ maxHeight: '120px' }}
            />
          </div>
          <button onClick={handleSend} disabled={!input.trim() || isTyping} className="w-11 h-11 bg-primary-600 hover:bg-primary-700 disabled:bg-gray-300 dark:disabled:bg-gray-600 rounded-2xl flex items-center justify-center transition-colors shrink-0 active:scale-95">
            <Send className="w-5 h-5 text-white rtl:-scale-x-100" />
          </button>
        </div>
      </div>
    </div>
  );
}
