import { useApp } from '../store';
import { useState } from 'react';
import {
  User, Globe, Bell, Key, LogOut, Moon, Sun, ChevronRight,
  GraduationCap, Building2, BookOpen, Mail, Shield, Info, Heart, Check
} from 'lucide-react';

export default function SettingsPage() {
  const { state, dispatch, t, setApiKey, logout } = useApp();
  const [apiKeyInput, setApiKeyInput] = useState('');

  const toggleTheme = () => {
    dispatch({ type: 'SET_THEME', payload: state.theme === 'dark' ? 'light' : 'dark' });
  };

  const toggleLanguage = () => {
    dispatch({ type: 'SET_LANGUAGE', payload: state.language === 'en' ? 'ar' : 'en' });
  };

  const handleLogout = async () => {
    await logout();
  };

  return (
    <div className="h-full overflow-y-auto bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary-600 via-primary-700 to-primary-800 dark:from-primary-900 dark:via-primary-950 dark:to-gray-900 px-5 pt-12 pb-8">
        <h1 className="text-2xl font-bold text-white mb-6">{t('settingsTitle')}</h1>
        
        {/* Profile Card */}
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 border border-white/10">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center text-white text-2xl font-bold">
              {state.user?.name?.charAt(0).toUpperCase() || 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-lg font-bold text-white truncate">{state.user?.name}</h2>
              <p className="text-sm text-primary-200 truncate">{state.user?.email}</p>
              <div className="flex items-center gap-2 mt-1">
                <Building2 className="w-3 h-3 text-primary-300" />
                <span className="text-xs text-primary-200">{state.user?.university}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="px-5 py-4 space-y-4 pb-8">
        {/* Profile Section */}
        <div>
          <h3 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-2 px-1">
            {t('profile')}
          </h3>
          <div className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700/50">
            <div className="p-4 flex items-center gap-3 border-b border-gray-50 dark:border-gray-700/50">
              <div className="w-9 h-9 bg-blue-50 dark:bg-blue-900/30 rounded-xl flex items-center justify-center">
                <User className="w-4.5 h-4.5 text-blue-500" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-gray-500 dark:text-gray-400">{t('fullName')}</p>
                <p className="text-sm font-medium text-gray-900 dark:text-white">{state.user?.name}</p>
              </div>
            </div>
            <div className="p-4 flex items-center gap-3 border-b border-gray-50 dark:border-gray-700/50">
              <div className="w-9 h-9 bg-green-50 dark:bg-green-900/30 rounded-xl flex items-center justify-center">
                <Mail className="w-4.5 h-4.5 text-green-500" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-gray-500 dark:text-gray-400">{t('email')}</p>
                <p className="text-sm font-medium text-gray-900 dark:text-white">{state.user?.email}</p>
              </div>
            </div>
            <div className="p-4 flex items-center gap-3 border-b border-gray-50 dark:border-gray-700/50">
              <div className="w-9 h-9 bg-purple-50 dark:bg-purple-900/30 rounded-xl flex items-center justify-center">
                <GraduationCap className="w-4.5 h-4.5 text-purple-500" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-gray-500 dark:text-gray-400">{t('university')}</p>
                <p className="text-sm font-medium text-gray-900 dark:text-white">{state.user?.university}</p>
              </div>
            </div>
            <div className="p-4 flex items-center gap-3">
              <div className="w-9 h-9 bg-orange-50 dark:bg-orange-900/30 rounded-xl flex items-center justify-center">
                <BookOpen className="w-4.5 h-4.5 text-orange-500" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-gray-500 dark:text-gray-400">{t('major')}</p>
                <p className="text-sm font-medium text-gray-900 dark:text-white">{state.user?.major}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Appearance Section */}
        <div>
          <h3 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-2 px-1">
            {t('appearance')}
          </h3>
          <div className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700/50">
            <button
              onClick={toggleTheme}
              className="w-full p-4 flex items-center gap-3 border-b border-gray-50 dark:border-gray-700/50"
            >
              <div className="w-9 h-9 bg-indigo-50 dark:bg-indigo-900/30 rounded-xl flex items-center justify-center">
                {state.theme === 'dark' ? <Moon className="w-4.5 h-4.5 text-indigo-500" /> : <Sun className="w-4.5 h-4.5 text-indigo-500" />}
              </div>
              <span className="flex-1 text-sm font-medium text-gray-900 dark:text-white text-left rtl:text-right">{t('darkMode')}</span>
              <div className={`w-12 h-7 rounded-full transition-colors relative ${state.theme === 'dark' ? 'bg-primary-600' : 'bg-gray-300'}`}>
                <div className={`w-5 h-5 bg-white rounded-full absolute top-1 transition-transform shadow-sm ${
                  state.theme === 'dark' ? 'translate-x-6 rtl:-translate-x-6' : 'translate-x-1 rtl:-translate-x-1'
                }`} />
              </div>
            </button>
            <button
              onClick={toggleLanguage}
              className="w-full p-4 flex items-center gap-3"
            >
              <div className="w-9 h-9 bg-teal-50 dark:bg-teal-900/30 rounded-xl flex items-center justify-center">
                <Globe className="w-4.5 h-4.5 text-teal-500" />
              </div>
              <span className="flex-1 text-sm font-medium text-gray-900 dark:text-white text-left rtl:text-right">{t('language')}</span>
              <span className="text-sm text-gray-500 dark:text-gray-400">
                {state.language === 'en' ? 'English' : 'العربية'}
              </span>
              <ChevronRight className="w-4 h-4 text-gray-400 rtl:rotate-180" />
            </button>
          </div>
        </div>

        {/* API Key Section */}
        <div>
          <h3 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-2 px-1">
            AI Configuration
          </h3>
          <div className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700/50">
            <div className="p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-9 h-9 bg-amber-50 dark:bg-amber-900/30 rounded-xl flex items-center justify-center">
                  <Key className="w-4.5 h-4.5 text-amber-500" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">{t('apiKey')}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {t('apiKeyRequired')}
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <input
                  type="password"
                  value={apiKeyInput}
                  onChange={e => setApiKeyInput(e.target.value)}
                  placeholder={t('apiKeyPlaceholder')}
                  className="flex-1 px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 font-mono"
                />
                <button
                  onClick={async () => {
                    if (apiKeyInput.trim()) {
                      await setApiKey(apiKeyInput.trim());
                      setApiKeyInput('');
                    }
                  }}
                  className="px-4 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-xl font-medium text-sm active:scale-95 transition-transform"
                >
                  <Check className="w-5 h-5" />
                </button>
              </div>
              <p className="text-xs text-gray-400 mt-2 flex items-center gap-1">
                <Shield className="w-3 h-3" />
                {state.language === 'ar' ? 'يتم تخزين المفتاح بشكل آمن على الخادم' : 'Key is stored securely on the server'}
              </p>
            </div>
          </div>
        </div>

        {/* Notifications */}
        <div>
          <h3 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-2 px-1">
            {t('notifications')}
          </h3>
          <div className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700/50">
            <button
              onClick={() => dispatch({ type: 'SET_NOTIFICATIONS', payload: !state.notifications })}
              className="w-full p-4 flex items-center gap-3"
            >
              <div className="w-9 h-9 bg-red-50 dark:bg-red-900/30 rounded-xl flex items-center justify-center">
                <Bell className="w-4.5 h-4.5 text-red-500" />
              </div>
              <span className="flex-1 text-sm font-medium text-gray-900 dark:text-white text-left rtl:text-right">{t('notifications')}</span>
              <div className={`w-12 h-7 rounded-full transition-colors relative ${state.notifications ? 'bg-primary-600' : 'bg-gray-300'}`}>
                <div className={`w-5 h-5 bg-white rounded-full absolute top-1 transition-transform shadow-sm ${
                  state.notifications ? 'translate-x-6 rtl:-translate-x-6' : 'translate-x-1 rtl:-translate-x-1'
                }`} />
              </div>
            </button>
          </div>
        </div>

        {/* About */}
        <div>
          <h3 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-2 px-1">
            {t('about')}
          </h3>
          <div className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700/50">
            <div className="p-4 flex items-center gap-3 border-b border-gray-50 dark:border-gray-700/50">
              <div className="w-9 h-9 bg-primary-50 dark:bg-primary-900/30 rounded-xl flex items-center justify-center">
                <Info className="w-4.5 h-4.5 text-primary-500" />
              </div>
              <span className="flex-1 text-sm font-medium text-gray-900 dark:text-white">{t('version')}</span>
            </div>
            <div className="p-4 flex items-center gap-3">
              <div className="w-9 h-9 bg-pink-50 dark:bg-pink-900/30 rounded-xl flex items-center justify-center">
                <Heart className="w-4.5 h-4.5 text-pink-500" />
              </div>
              <span className="flex-1 text-sm font-medium text-gray-900 dark:text-white">
                {state.language === 'ar' ? 'صُنع بـ ❤️ للطلاب' : 'Made with ❤️ for students'}
              </span>
            </div>
          </div>
        </div>

        {/* Logout */}
        <button
          onClick={handleLogout}
          className="w-full bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-700/50 flex items-center justify-center gap-2 text-red-500 font-semibold active:scale-[0.98] transition-transform"
        >
          <LogOut className="w-5 h-5" />
          <span>{t('logout')}</span>
        </button>
      </div>
    </div>
  );
}
