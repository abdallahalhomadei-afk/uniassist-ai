import { useState, useMemo } from 'react';
import { useApp } from '../store';
import type { GradeEntry } from '../types';
import { Plus, X, Trash2, TrendingUp, Award, ChevronDown } from 'lucide-react';

const GRADES = ['A+', 'A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'F'];
const GPA_MAP: Record<string, number> = {
  'A+': 4.0, 'A': 4.0, 'A-': 3.7, 'B+': 3.3, 'B': 3.0, 'B-': 2.7,
  'C+': 2.3, 'C': 2.0, 'C-': 1.7, 'D+': 1.3, 'D': 1.0, 'F': 0
};

export default function GPAPage() {
  const { state, t, createGrade, deleteGrade } = useApp();
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Partial<GradeEntry>>({
    courseName: '', courseCode: '', credits: 3, grade: 'A', semester: 'Fall 2024'
  });

  const handleSave = async () => {
    if (!form.courseName || !form.grade) return;
    setSaving(true);
    try {
      await createGrade({
        course_name: form.courseName,
        course_code: form.courseCode,
        credits: form.credits || 3,
        grade: form.grade || 'A',
        semester: form.semester || 'Fall 2024',
      });
      setForm({ courseName: '', courseCode: '', credits: 3, grade: 'A', semester: form.semester });
      setShowForm(false);
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try { await deleteGrade(id); } catch (err) { console.error(err); }
  };

  const { cumulativeGPA, totalCredits, semesters } = useMemo(() => {
    const total = state.grades.reduce((sum, g) => sum + g.credits, 0);
    const points = state.grades.reduce((sum, g) => sum + (GPA_MAP[g.grade] || 0) * g.credits, 0);
    const cumGPA = total > 0 ? points / total : 0;

    const semMap = new Map<string, GradeEntry[]>();
    state.grades.forEach(g => {
      if (!semMap.has(g.semester)) semMap.set(g.semester, []);
      semMap.get(g.semester)!.push(g);
    });

    const sems = Array.from(semMap.entries()).map(([name, grades]) => {
      const semCredits = grades.reduce((s, g) => s + g.credits, 0);
      const semPoints = grades.reduce((s, g) => s + (GPA_MAP[g.grade] || 0) * g.credits, 0);
      return {
        name,
        grades,
        gpa: semCredits > 0 ? semPoints / semCredits : 0,
        credits: semCredits,
      };
    });

    return { cumulativeGPA: cumGPA, totalCredits: total, semesters: sems };
  }, [state.grades]);

  const getGPAColor = (gpa: number) => {
    if (gpa >= 3.5) return 'text-green-600 dark:text-green-400';
    if (gpa >= 3.0) return 'text-blue-600 dark:text-blue-400';
    if (gpa >= 2.0) return 'text-amber-600 dark:text-amber-400';
    return 'text-red-600 dark:text-red-400';
  };

  const getGradeColor = (grade: string) => {
    if (grade.startsWith('A')) return 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400';
    if (grade.startsWith('B')) return 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400';
    if (grade.startsWith('C')) return 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400';
    if (grade.startsWith('D')) return 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400';
    return 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400';
  };

  // GPA progress circle
  const circumference = 2 * Math.PI * 54;
  const progress = (cumulativeGPA / 4.0) * circumference;

  return (
    <div className="h-full overflow-y-auto bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700 px-5 pt-12 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t('gpaTitle')}</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{t('gpaScale')}</p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="w-11 h-11 bg-primary-600 hover:bg-primary-700 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-primary-500/30 active:scale-95 transition-transform"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="px-5 py-4 space-y-6">
        {/* GPA Circle */}
        <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 shadow-sm border border-gray-100 dark:border-gray-700/50 text-center">
          <div className="relative w-36 h-36 mx-auto mb-4">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
              <circle cx="60" cy="60" r="54" fill="none" strokeWidth="8" className="stroke-gray-100 dark:stroke-gray-700" />
              <circle
                cx="60" cy="60" r="54" fill="none" strokeWidth="8"
                strokeDasharray={circumference}
                strokeDashoffset={circumference - progress}
                strokeLinecap="round"
                className="stroke-primary-500 transition-all duration-1000"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={`text-3xl font-bold ${getGPAColor(cumulativeGPA)}`}>
                {cumulativeGPA.toFixed(2)}
              </span>
              <span className="text-xs text-gray-400 font-medium">/ 4.00</span>
            </div>
          </div>

          <h2 className="text-lg font-bold text-gray-900 dark:text-white">{t('cumulativeGPA')}</h2>
          <div className="flex justify-center gap-6 mt-3">
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{totalCredits}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">{t('totalCredits')}</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{state.grades.length}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">{t('courses')}</p>
            </div>
          </div>
        </div>

        {/* Semesters */}
        {semesters.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="w-16 h-16 bg-purple-50 dark:bg-purple-900/30 rounded-2xl flex items-center justify-center mb-4">
              <Award className="w-8 h-8 text-purple-500" />
            </div>
            <p className="text-gray-500 dark:text-gray-400 font-medium">{t('noGrades')}</p>
          </div>
        ) : (
          semesters.map(sem => (
            <div key={sem.name}>
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-gray-900 dark:text-white">{sem.name}</h3>
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-gray-400" />
                  <span className={`font-bold ${getGPAColor(sem.gpa)}`}>{sem.gpa.toFixed(2)}</span>
                </div>
              </div>
              <div className="space-y-2">
                {sem.grades.map(g => (
                  <div key={g.id} className="bg-white dark:bg-gray-800 rounded-xl p-3.5 shadow-sm border border-gray-100 dark:border-gray-700/50 flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 dark:text-white text-sm truncate">{g.courseName}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">{g.courseCode} • {g.credits} {t('credits')}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${getGradeColor(g.grade)}`}>
                        {g.grade}
                      </span>
                      <button
                        onClick={() => handleDelete(g.id)}
                        className="p-1 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-red-400" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add Grade Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end justify-center animate-fade-in" onClick={() => setShowForm(false)}>
          <div
            className="w-full max-w-lg bg-white dark:bg-gray-800 rounded-t-3xl p-5 max-h-[85vh] overflow-y-auto animate-slide-up"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">{t('addGrade')}</h2>
              <button onClick={() => setShowForm(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-xl">
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('courseName')}</label>
                <input
                  type="text"
                  value={form.courseName}
                  onChange={e => setForm({...form, courseName: e.target.value})}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('courseCode')}</label>
                  <input
                    type="text"
                    value={form.courseCode}
                    onChange={e => setForm({...form, courseCode: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('credits')}</label>
                  <input
                    type="number"
                    min={1}
                    max={6}
                    value={form.credits}
                    onChange={e => setForm({...form, credits: parseInt(e.target.value) || 3})}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('grade')}</label>
                  <div className="relative">
                    <select
                      value={form.grade}
                      onChange={e => setForm({...form, grade: e.target.value})}
                      className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white appearance-none focus:outline-none focus:ring-2 focus:ring-primary-500"
                    >
                      {GRADES.map(g => (
                        <option key={g} value={g}>{g} ({GPA_MAP[g].toFixed(1)})</option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-3 rtl:right-auto rtl:left-3 top-3.5 w-5 h-5 text-gray-400 pointer-events-none" />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('semester')}</label>
                  <input
                    type="text"
                    value={form.semester}
                    onChange={e => setForm({...form, semester: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                    placeholder="Fall 2024"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => setShowForm(false)}
                  className="flex-1 py-3 border border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-xl font-medium active:scale-95 transition-transform"
                >
                  {t('cancel')}
                </button>
                <button
                  onClick={handleSave}
                  disabled={!form.courseName || saving}
                  className="flex-1 py-3 bg-primary-600 hover:bg-primary-700 disabled:bg-gray-300 text-white rounded-xl font-medium active:scale-95 transition-transform"
                >
                  {saving ? t('loading') : t('save')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
