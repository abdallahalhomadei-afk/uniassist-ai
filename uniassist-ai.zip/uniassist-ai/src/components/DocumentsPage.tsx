import { useState, useRef, useCallback } from 'react';
import { useApp } from '../store';
import { Upload, FileText, Trash2, Eye, X, Send, File, Loader2 } from 'lucide-react';

export default function DocumentsPage() {
  const { state, t, uploadDocument, deleteDocument } = useApp();
  const [viewDoc, setViewDoc] = useState<any>(null);
  const [uploading, setUploading] = useState(false);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [askLoading, setAskLoading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      await uploadDocument(file);
    } catch (err: any) {
      console.error('Upload failed:', err);
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  }, [uploadDocument]);

  const handleDelete = useCallback(async (id: string) => {
    try {
      await deleteDocument(id);
    } catch (err) {
      console.error(err);
    }
  }, [deleteDocument]);

  const handleAsk = useCallback(async () => {
    if (!question.trim()) return;
    setAskLoading(true);
    try {
      const api = (await import('../api/client')).default;
      const resp = await api.askAboutDocument(viewDoc.id, question);
      setAnswer(resp.answer);
    } catch (err: any) {
      setAnswer('Error: ' + (err.message || 'Could not get answer'));
    } finally {
      setAskLoading(false);
      setQuestion('');
    }
  }, [question, viewDoc]);

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const formatDate = (dateStr: string) => {
    try { return new Date(dateStr).toLocaleDateString(); } catch { return dateStr; }
  };

  const processingStatus = (status: string) => {
    switch (status) {
      case 'pending': return 'Pending...';
      case 'processing': return 'Analyzing...';
      case 'completed': return '';
      case 'failed': return 'Failed';
      default: return '';
    }
  };

  return (
    <div className="h-full overflow-y-auto bg-gray-50 dark:bg-gray-900">
      <div className="bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700 px-5 pt-12 pb-4">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t('documentsTitle')}</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{state.documents.length} {t('documents')}</p>
      </div>

      <div className="px-5 py-4 space-y-4">
        <label className="block cursor-pointer">
          <div className={`border-2 border-dashed rounded-2xl p-8 text-center transition-colors ${uploading ? 'border-primary-400 bg-primary-50 dark:bg-primary-900/20' : 'border-gray-300 dark:border-gray-600 hover:border-primary-400 hover:bg-primary-50/50 dark:hover:bg-primary-900/10'}`}>
            {uploading ? (
              <div className="flex flex-col items-center gap-3">
                <Loader2 className="w-12 h-12 text-primary-500 animate-spin" />
                <p className="text-primary-600 dark:text-primary-400 font-medium">{t('analyzing')}</p>
              </div>
            ) : (
              <>
                <div className="w-14 h-14 mx-auto bg-primary-50 dark:bg-primary-900/30 rounded-2xl flex items-center justify-center mb-3">
                  <Upload className="w-7 h-7 text-primary-500" />
                </div>
                <p className="text-gray-700 dark:text-gray-300 font-semibold mb-1">{t('dragDrop')}</p>
                <p className="text-sm text-gray-400">{t('supportedFormats')}</p>
              </>
            )}
          </div>
          <input ref={fileRef} type="file" accept=".pdf,.txt,.doc,.docx,.md" onChange={handleUpload} className="hidden" />
        </label>

        {state.documents.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="w-16 h-16 bg-teal-50 dark:bg-teal-900/30 rounded-2xl flex items-center justify-center mb-4">
              <File className="w-8 h-8 text-teal-500" />
            </div>
            <p className="text-gray-500 dark:text-gray-400 font-medium">{t('noDocuments')}</p>
          </div>
        ) : (
          <div className="space-y-3">
            {state.documents.map(doc => (
              <div key={doc.id} className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-700/50 animate-fade-in">
                <div className="flex items-start gap-3">
                  <div className="w-11 h-11 bg-red-50 dark:bg-red-900/30 rounded-xl flex items-center justify-center shrink-0">
                    <FileText className="w-5 h-5 text-red-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 dark:text-white text-sm truncate">{doc.name}</h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{formatSize(doc.size)} • {formatDate(doc.uploadedAt)}</p>
                    {doc.summary && (
                      <p className="text-xs text-gray-600 dark:text-gray-400 mt-2 bg-gray-50 dark:bg-gray-700/50 rounded-lg px-3 py-2">{doc.summary}</p>
                    )}
                    {(doc as any).processing_status && (doc as any).processing_status !== 'completed' && (
                      <div className="flex items-center gap-2 mt-2 text-xs text-amber-600 dark:text-amber-400">
                        <Loader2 className="w-3 h-3 animate-spin" />
                        {processingStatus((doc as any).processing_status)}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <button onClick={() => { setViewDoc(doc); setAnswer(''); }} className="p-2 hover:bg-primary-50 dark:hover:bg-primary-900/20 rounded-lg">
                      <Eye className="w-4 h-4 text-primary-500" />
                    </button>
                    <button onClick={() => handleDelete(doc.id)} className="p-2 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg">
                      <Trash2 className="w-4 h-4 text-red-400" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {viewDoc && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end justify-center animate-fade-in" onClick={() => setViewDoc(null)}>
          <div className="w-full max-w-lg bg-white dark:bg-gray-800 rounded-t-3xl max-h-[90vh] flex flex-col animate-slide-up" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-gray-100 dark:border-gray-700">
              <h2 className="text-lg font-bold text-gray-900 dark:text-white truncate flex-1">{viewDoc.name}</h2>
              <button onClick={() => setViewDoc(null)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-xl ml-2">
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {viewDoc.summary && (
                <div className="bg-primary-50 dark:bg-primary-900/20 rounded-xl p-4 border border-primary-100 dark:border-primary-800">
                  <p className="text-sm font-semibold text-primary-700 dark:text-primary-300 mb-2">{t('summary')}</p>
                  <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">{viewDoc.summary}</p>
                </div>
              )}
              {viewDoc.content && (
                <div className="bg-gray-50 dark:bg-gray-700/50 rounded-xl p-4 max-h-60 overflow-y-auto">
                  <pre className="text-xs text-gray-600 dark:text-gray-400 whitespace-pre-wrap font-mono leading-relaxed">{viewDoc.content.substring(0, 3000)}{viewDoc.content.length > 3000 && '...'}</pre>
                </div>
              )}
              {answer && (
                <div className="bg-white dark:bg-gray-800 rounded-xl p-4 border border-gray-200 dark:border-gray-600">
                  <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">{answer}</p>
                </div>
              )}
            </div>
            <div className="p-4 border-t border-gray-100 dark:border-gray-700">
              <div className="flex items-center gap-2">
                <input type="text" value={question} onChange={e => setQuestion(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleAsk()} placeholder={t('askAboutDoc')} className="flex-1 px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary-500" />
                <button onClick={handleAsk} disabled={!question.trim() || askLoading} className="w-11 h-11 bg-primary-600 hover:bg-primary-700 disabled:bg-gray-300 rounded-xl flex items-center justify-center text-white active:scale-95 transition-transform shrink-0">
                  {askLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
