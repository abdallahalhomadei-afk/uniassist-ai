import type React from 'react';
import { useApp } from '../store';
import {
  MessageSquare, BookOpen, ClipboardList, Calendar, Calculator, FileText,
  Clock, TrendingUp, Award, AlertCircle, ChevronRight
} from 'lucide-react';
import type { Page } from '../types';

export default function HomePage() {
  const { state, dispatch, t } = useApp();

  const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'] as const;
  const today = dayNames[new Date().getDay()];

  const todayCourses = state.courses.filter(c =>
    c.schedule.some(s => s.day.toLowerCase() === today)
  ).map(c => ({
    ...c,
    todaySchedule: c.schedule.filter(s => s.day.toLowerCase() === today)
  }));

  const upcomingAssignments = state.assignments
    .filter(a => a.status !== 'completed')
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
    .slice(0, 3);

  const upcomingExams = state.exams
    .filter(e => new Date(e.date) >= new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 2);

  const totalCredits = state.grades.reduce((sum, g) => sum + g.credits, 0);
  const gpaPoints: Record<string, number> = {
    'A+': 4.0, 'A': 4.0, 'A-': 3.7, 'B+': 3.3, 'B': 3.0, 'B-': 2.7,
    'C+': 2.3, 'C': 2.0, 'C-': 1.7, 'D+': 1.3, 'D': 1.0, 'F': 0
  };
  const gpa = totalCredits > 0
    ? (state.grades.reduce((sum, g) => sum + (gpaPoints[g.grade] || 0) * g.credits, 0) / totalCredits).toFixed(2)
    : '0.00';

  const pendingCount = state.assignments.filter(a => a.status !== 'completed').length;

  const getDaysUntil = (date: string) => {
    const diff = Math.ceil((new Date(date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
    return diff;
  };

  const quickActions: { icon: React.ReactNode; label: string; page: Page; color: string; bg: string }[] = [
    { icon: <MessageSquare className="w-6 h-6" />, label: t('chat'), page: 'chat', color: 'text-blue-600 dark:text-blue-400', bg: 'bg-blue-50 dark:bg-blue-900/30' },
    { icon: <BookOpen className="w-6 h-6" />, label: t('courses'), page: 'courses', color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-900/30' },
    { icon: <ClipboardList className="w-6 h-6" />, label: t('assignments'), page: 'assignments', color: 'text-orange-600 dark:text-orange-400', bg: 'bg-orange-50 dark:bg-orange-900/30' },
    { icon: <Calendar className="w-6 h-6" />, label: t('exams'), page: 'exams', color: 'text-red-600 dark:text-red-400', bg: 'bg-red-50 dark:bg-red-900/30' },
    { icon: <Calculator className="w-6 h-6" />, label: t('gpa'), page: 'gpa', color: 'text-purple-600 dark:text-purple-400', bg: 'bg-purple-50 dark:bg-purple-900/30' },
    { icon: <FileText className="w-6 h-6" />, label: t('documents'), page: 'documents', color: 'text-teal-600 dark:text-teal-400', bg: 'bg-teal-50 dark:bg-teal-900/30' },
  ];

  const firstName = state.user?.name?.split(' ')[0] || '';

  return (
    <div className="h-full overflow-y-auto pb-4">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary-600 via-primary-700 to-primary-800 dark:from-primary-900 dark:via-primary-950 dark:to-gray-900 px-5 pt-12 pb-8 rounded-b-[2rem]">
        <div className="flex items-center justify-between mb-6">
          <div>
            <p className="text-primary-200 text-sm font-medium">{t('greeting')},</p>
            <h1 className="text-2xl font-bold text-white">{firstName} 👋</h1>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-white font-bold text-lg backdrop-blur-sm border border-white/10">
            {firstName.charAt(0).toUpperCase()}
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-3.5 border border-white/10">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-primary-200" />
              <span className="text-xs text-primary-200 font-medium">{t('currentGPA')}</span>
            </div>
            <p className="text-2xl font-bold text-white">{gpa}</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-3.5 border border-white/10">
            <div className="flex items-center gap-2 mb-1">
              <Award className="w-4 h-4 text-primary-200" />
              <span className="text-xs text-primary-200 font-medium">{t('totalCredits')}</span>
            </div>
            <p className="text-2xl font-bold text-white">{totalCredits}</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-3.5 border border-white/10">
            <div className="flex items-center gap-2 mb-1">
              <BookOpen className="w-4 h-4 text-primary-200" />
              <span className="text-xs text-primary-200 font-medium">{t('activeCourses')}</span>
            </div>
            <p className="text-2xl font-bold text-white">{state.courses.length}</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-3.5 border border-white/10">
            <div className="flex items-center gap-2 mb-1">
              <AlertCircle className="w-4 h-4 text-primary-200" />
              <span className="text-xs text-primary-200 font-medium">{t('pendingTasks')}</span>
            </div>
            <p className="text-2xl font-bold text-white">{pendingCount}</p>
          </div>
        </div>
      </div>

      <div className="px-5 mt-6 space-y-6">
        {/* Quick Actions */}
        <div>
          <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-3">{t('quickActions')}</h2>
          <div className="grid grid-cols-3 gap-3">
            {quickActions.map((action) => (
              <button
                key={action.page}
                onClick={() => dispatch({ type: 'SET_PAGE', payload: action.page })}
                className={`${action.bg} rounded-2xl p-4 flex flex-col items-center gap-2 active:scale-95 transition-transform`}
              >
                <div className={action.color}>{action.icon}</div>
                <span className="text-xs font-semibold text-gray-700 dark:text-gray-300">{action.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Today's Schedule */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white">{t('todaySchedule')}</h2>
            <button
              onClick={() => dispatch({ type: 'SET_PAGE', payload: 'courses' })}
              className="text-primary-600 dark:text-primary-400 text-sm font-medium flex items-center gap-1"
            >
              <span>{t('courses')}</span>
              <ChevronRight className="w-4 h-4 rtl:rotate-180" />
            </button>
          </div>
          {todayCourses.length === 0 ? (
            <div className="bg-gray-50 dark:bg-gray-800/50 rounded-2xl p-6 text-center">
              <p className="text-gray-500 dark:text-gray-400">{t('noCourseToday')}</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {todayCourses.map(course => (
                course.todaySchedule.map((sched, idx) => (
                  <div key={`${course.id}-${idx}`} className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-700/50 flex items-center gap-3">
                    <div className="w-1 h-12 rounded-full" style={{ backgroundColor: course.color }} />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-900 dark:text-white text-sm truncate">{course.name}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">{course.code} • {sched.room}</p>
                    </div>
                    <div className="flex items-center gap-1.5 text-gray-500 dark:text-gray-400 shrink-0">
                      <Clock className="w-3.5 h-3.5" />
                      <span className="text-xs font-medium">{sched.startTime} - {sched.endTime}</span>
                    </div>
                  </div>
                ))
              ))}
            </div>
          )}
        </div>

        {/* Upcoming Deadlines */}
        {upcomingAssignments.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold text-gray-900 dark:text-white">{t('upcomingDeadlines')}</h2>
              <button
                onClick={() => dispatch({ type: 'SET_PAGE', payload: 'assignments' })}
                className="text-primary-600 dark:text-primary-400 text-sm font-medium flex items-center gap-1"
              >
                <span>{t('assignments')}</span>
                <ChevronRight className="w-4 h-4 rtl:rotate-180" />
              </button>
            </div>
            <div className="space-y-2.5">
              {upcomingAssignments.map(a => {
                const days = getDaysUntil(a.dueDate);
                const urgencyColor = days <= 1 ? 'text-red-600 bg-red-50 dark:text-red-400 dark:bg-red-900/30'
                  : days <= 3 ? 'text-orange-600 bg-orange-50 dark:text-orange-400 dark:bg-orange-900/30'
                  : 'text-green-600 bg-green-50 dark:text-green-400 dark:bg-green-900/30';
                return (
                  <div key={a.id} className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-700/50">
                    <div className="flex items-start justify-between">
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-gray-900 dark:text-white text-sm truncate">{a.title}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{a.courseName}</p>
                      </div>
                      <span className={`text-xs font-semibold px-2.5 py-1 rounded-full shrink-0 ${urgencyColor}`}>
                        {days <= 0 ? t('pastDue') : days === 1 ? t('dueTomorrow') : `${days} ${t('daysLeft')}`}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Upcoming Exams */}
        {upcomingExams.length > 0 && (
          <div className="pb-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold text-gray-900 dark:text-white">{t('examsTitle')}</h2>
              <button
                onClick={() => dispatch({ type: 'SET_PAGE', payload: 'exams' })}
                className="text-primary-600 dark:text-primary-400 text-sm font-medium flex items-center gap-1"
              >
                <span>{t('exams')}</span>
                <ChevronRight className="w-4 h-4 rtl:rotate-180" />
              </button>
            </div>
            <div className="space-y-2.5">
              {upcomingExams.map(exam => {
                const days = getDaysUntil(exam.date);
                return (
                  <div key={exam.id} className="bg-gradient-to-r from-red-50 to-orange-50 dark:from-red-900/20 dark:to-orange-900/20 rounded-2xl p-4 border border-red-100 dark:border-red-900/30">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-gray-900 dark:text-white text-sm">{exam.title}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{exam.courseName} • {exam.type}</p>
                      </div>
                      <div className="text-right rtl:text-left">
                        <p className="text-sm font-bold text-red-600 dark:text-red-400">{t('examIn')} {days} {t('daysLeft')}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{exam.date}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
