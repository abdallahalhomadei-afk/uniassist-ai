import { useApp } from '../store';
import type { Page } from '../types';
import { Home, MessageSquare, BookOpen, ClipboardList, Settings } from 'lucide-react';

export default function BottomNav() {
  const { state, dispatch, t } = useApp();

  const items: { page: Page; icon: typeof Home; label: string }[] = [
    { page: 'home', icon: Home, label: t('home') },
    { page: 'chat', icon: MessageSquare, label: t('chat') },
    { page: 'courses', icon: BookOpen, label: t('courses') },
    { page: 'assignments', icon: ClipboardList, label: t('assignments') },
    { page: 'settings', icon: Settings, label: t('settings') },
  ];

  return (
    <nav className="flex-shrink-0 bg-white dark:bg-gray-800 border-t border-gray-100 dark:border-gray-700 px-2 pb-[env(safe-area-inset-bottom)]">
      <div className="flex items-center justify-around">
        {items.map(({ page, icon: Icon, label }) => {
          const active = state.currentPage === page;
          return (
            <button
              key={page}
              onClick={() => dispatch({ type: 'SET_PAGE', payload: page })}
              className={`flex flex-col items-center py-2 px-3 min-w-[60px] transition-colors ${
                active ? 'text-primary-600 dark:text-primary-400' : 'text-gray-400 dark:text-gray-500'
              }`}
            >
              <div className={`p-1.5 rounded-xl transition-colors ${active ? 'bg-primary-50 dark:bg-primary-900/30' : ''}`}>
                <Icon className="w-5 h-5" strokeWidth={active ? 2.5 : 2} />
              </div>
              <span className={`text-[10px] mt-0.5 font-medium ${active ? 'font-semibold' : ''}`}>
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
