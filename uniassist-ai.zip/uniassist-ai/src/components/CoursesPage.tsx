import { useState } from 'react';
import { useApp } from '../store';
import type { Course } from '../types';
import { Plus, X, Trash2, Clock, MapPin, UserCircle, BookOpen, ChevronDown } from 'lucide-react';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#f97316'];
const DAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

export default function CoursesPage() {
  const { state, t, createCourse, deleteCourse } = useApp();
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Partial<Course>>({
    name: '', code: '', instructor: '', color: COLORS[0], credits: 3, schedule: []
  });
  const [scheduleItem, setScheduleItem] = useState<{ day: string; startTime: string; endTime: string; room: string }>({
    day: 'sunday', startTime: '08:00', endTime: '09:30', room: ''
  });

  const handleAddScheduleItem = () => {
    if (!scheduleItem.room) return;
    setForm({
      ...form,
      schedule: [...(form.schedule || []), { ...scheduleItem }]
    });
    setScheduleItem({ day: 'sunday', startTime: '08:00', endTime: '09:30', room: '' });
  };

  const handleRemoveSchedule = (idx: number) => {
    setForm({
      ...form,
      schedule: (form.schedule || []).filter((_, i) => i !== idx)
    });
  };

  const handleSave = async () => {
    if (!form.name || !form.code) return;
    setSaving(true);
    try {
      const dayMap: Record<string, number> = { sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6 };
      await createCourse({
        name: form.name,
        code: form.code,
        instructor: form.instructor,
        color: form.color,
        credits: form.credits,
        schedule: (form.schedule || []).map(s => ({
          day_of_week: dayMap[s.day] ?? 0,
          start_time: s.startTime,
          end_time: s.endTime,
          room: s.room,
        })),
      });
      setForm({ name: '', code: '', instructor: '', color: COLORS[Math.floor(Math.random() * COLORS.length)], credits: 3, schedule: [] });
      setShowForm(false);
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteCourse(id);
    } catch (err) {
      console.error(err);
    }
  };

  const dayLabel = (day: string) => {
    const key = day as keyof typeof import('../i18n').translations.en;
    return t(key as any) || day;
  };

  return (
    <div className="h-full overflow-y-auto bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700 px-5 pt-12 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t('coursesTitle')}</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{state.courses.length} {t('courses')}</p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="w-11 h-11 bg-primary-600 hover:bg-primary-700 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-primary-500/30 active:scale-95 transition-transform"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="px-5 py-4">
        {state.courses.length === 0 && !showForm ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-16 h-16 bg-primary-50 dark:bg-primary-900/30 rounded-2xl flex items-center justify-center mb-4">
              <BookOpen className="w-8 h-8 text-primary-500" />
            </div>
            <p className="text-gray-500 dark:text-gray-400 font-medium">{t('noCourses')}</p>
            <button
              onClick={() => setShowForm(true)}
              className="mt-4 px-6 py-2.5 bg-primary-600 text-white rounded-xl font-medium text-sm active:scale-95 transition-transform"
            >
              {t('addCourse')}
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {state.courses.map(course => (
              <div key={course.id} className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-700/50 animate-fade-in">
                <div className="flex items-start gap-3">
                  <div className="w-1.5 h-full min-h-[60px] rounded-full shrink-0" style={{ backgroundColor: course.color }} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-bold text-gray-900 dark:text-white">{course.name}</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{course.code} • {course.credits} {t('credits')}</p>
                      </div>
                      <button
                        onClick={() => handleDelete(course.id)}
                        className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4 text-red-400" />
                      </button>
                    </div>
                    {course.instructor && (
                      <div className="flex items-center gap-1.5 mt-2 text-sm text-gray-500 dark:text-gray-400">
                        <UserCircle className="w-4 h-4" />
                        <span>{course.instructor}</span>
                      </div>
                    )}
                    {course.schedule.length > 0 && (
                      <div className="mt-3 space-y-1.5">
                        {course.schedule.map((s, i) => (
                          <div key={i} className="flex items-center gap-3 text-xs bg-gray-50 dark:bg-gray-700/50 rounded-lg px-3 py-2">
                            <span className="font-medium text-gray-700 dark:text-gray-300 min-w-[50px]">{dayLabel(s.day)}</span>
                            <div className="flex items-center gap-1 text-gray-500 dark:text-gray-400">
                              <Clock className="w-3 h-3" />
                              <span>{s.startTime} - {s.endTime}</span>
                            </div>
                            <div className="flex items-center gap-1 text-gray-500 dark:text-gray-400">
                              <MapPin className="w-3 h-3" />
                              <span>{s.room}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Course Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end justify-center animate-fade-in" onClick={() => setShowForm(false)}>
          <div
            className="w-full max-w-lg bg-white dark:bg-gray-800 rounded-t-3xl p-5 max-h-[85vh] overflow-y-auto animate-slide-up"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">{t('addCourse')}</h2>
              <button onClick={() => setShowForm(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-xl">
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('courseName')}</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={e => setForm({...form, name: e.target.value})}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                  placeholder="Data Structures"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('courseCode')}</label>
                  <input
                    type="text"
                    value={form.code}
                    onChange={e => setForm({...form, code: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                    placeholder="CS201"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('credits')}</label>
                  <input
                    type="number"
                    min={1}
                    max={6}
                    value={form.credits}
                    onChange={e => setForm({...form, credits: parseInt(e.target.value) || 3})}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('instructor')}</label>
                <input
                  type="text"
                  value={form.instructor}
                  onChange={e => setForm({...form, instructor: e.target.value})}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                  placeholder="Dr. Smith"
                />
              </div>

              {/* Color Picker */}
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">Color</label>
                <div className="flex gap-2.5">
                  {COLORS.map(c => (
                    <button
                      key={c}
                      onClick={() => setForm({...form, color: c})}
                      className={`w-8 h-8 rounded-full transition-transform ${form.color === c ? 'scale-125 ring-2 ring-offset-2 ring-gray-400 dark:ring-offset-gray-800' : ''}`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              {/* Schedule */}
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">{t('schedule')}</label>
                
                {(form.schedule || []).map((s, i) => (
                  <div key={i} className="flex items-center gap-2 mb-2 bg-gray-50 dark:bg-gray-700/50 rounded-xl px-3 py-2 text-sm">
                    <span className="flex-1 text-gray-700 dark:text-gray-300">{dayLabel(s.day)} • {s.startTime}-{s.endTime} • {s.room}</span>
                    <button onClick={() => handleRemoveSchedule(i)} className="text-red-400 hover:text-red-600">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}

                <div className="grid grid-cols-2 gap-2 mt-2">
                  <div className="relative">
                    <select
                      value={scheduleItem.day}
                      onChange={e => setScheduleItem({...scheduleItem, day: e.target.value})}
                      className="w-full px-3 py-2.5 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white appearance-none focus:outline-none focus:ring-2 focus:ring-primary-500"
                    >
                      {DAYS.map(d => (
                        <option key={d} value={d}>{dayLabel(d)}</option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-2.5 rtl:right-auto rtl:left-2.5 top-3 w-4 h-4 text-gray-400 pointer-events-none" />
                  </div>
                  <input
                    type="text"
                    placeholder={t('room')}
                    value={scheduleItem.room}
                    onChange={e => setScheduleItem({...scheduleItem, room: e.target.value})}
                    className="px-3 py-2.5 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                  <input
                    type="time"
                    value={scheduleItem.startTime}
                    onChange={e => setScheduleItem({...scheduleItem, startTime: e.target.value})}
                    className="px-3 py-2.5 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                  <input
                    type="time"
                    value={scheduleItem.endTime}
                    onChange={e => setScheduleItem({...scheduleItem, endTime: e.target.value})}
                    className="px-3 py-2.5 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                <button
                  onClick={handleAddScheduleItem}
                  className="mt-2 w-full py-2.5 border-2 border-dashed border-gray-300 dark:border-gray-600 text-gray-500 dark:text-gray-400 rounded-xl text-sm font-medium hover:border-primary-400 hover:text-primary-500 transition-colors"
                >
                  + {t('addSchedule')}
                </button>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => setShowForm(false)}
                  className="flex-1 py-3 border border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-xl font-medium active:scale-95 transition-transform"
                >
                  {t('cancel')}
                </button>
                <button
                  onClick={handleSave}
                  disabled={!form.name || !form.code || saving}
                  className="flex-1 py-3 bg-primary-600 hover:bg-primary-700 disabled:bg-gray-300 text-white rounded-xl font-medium active:scale-95 transition-transform flex items-center justify-center gap-2"
                >
                  {saving ? t('loading') : t('save')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
