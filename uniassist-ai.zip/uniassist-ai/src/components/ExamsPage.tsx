import { useState } from 'react';
import { useApp } from '../store';
import type { Exam } from '../types';
import { Plus, X, Trash2, Calendar, Clock, MapPin, FileQuestion, ChevronDown, AlertCircle } from 'lucide-react';

export default function ExamsPage() {
  const { state, t, createExam, deleteExam } = useApp();
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Partial<Exam>>({
    title: '', courseId: '', courseName: '', date: '', time: '09:00', duration: '120', room: '', type: 'midterm', notes: ''
  });

  const handleSave = async () => {
    if (!form.title || !form.date) return;
    setSaving(true);
    try {
      await createExam({
        title: form.title,
        course_id: form.courseId || undefined,
        exam_date: form.date,
        start_time: form.time,
        duration_minutes: form.duration ? parseInt(form.duration) : 120,
        room: form.room,
        exam_type: form.type,
        notes: form.notes,
      });
      setForm({ title: '', courseId: '', courseName: '', date: '', time: '09:00', duration: '120', room: '', type: 'midterm', notes: '' });
      setShowForm(false);
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try { await deleteExam(id); } catch (err) { console.error(err); }
  };

  const getDaysUntil = (date: string) => {
    return Math.ceil((new Date(date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
  };

  const sorted = [...state.exams].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const typeStyle = (type: string) => {
    switch (type) {
      case 'final': return 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400';
      case 'midterm': return 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400';
      default: return 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400';
    }
  };

  const typeLabel = (type: string) => {
    switch (type) {
      case 'final': return t('final');
      case 'midterm': return t('midterm');
      default: return t('quiz');
    }
  };

  return (
    <div className="h-full overflow-y-auto bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700 px-5 pt-12 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t('examsTitle')}</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{state.exams.length} {t('exams')}</p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="w-11 h-11 bg-primary-600 hover:bg-primary-700 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-primary-500/30 active:scale-95 transition-transform"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="px-5 py-4">
        {sorted.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-16 h-16 bg-red-50 dark:bg-red-900/30 rounded-2xl flex items-center justify-center mb-4">
              <FileQuestion className="w-8 h-8 text-red-500" />
            </div>
            <p className="text-gray-500 dark:text-gray-400 font-medium">{t('noExams')}</p>
            <button
              onClick={() => setShowForm(true)}
              className="mt-4 px-6 py-2.5 bg-primary-600 text-white rounded-xl font-medium text-sm active:scale-95 transition-transform"
            >
              {t('addExam')}
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {sorted.map(exam => {
              const days = getDaysUntil(exam.date);
              const isPast = days < 0;
              return (
                <div
                  key={exam.id}
                  className={`bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-700/50 animate-fade-in ${isPast ? 'opacity-50' : ''}`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-xs px-2.5 py-0.5 rounded-full font-semibold ${typeStyle(exam.type)}`}>
                          {typeLabel(exam.type)}
                        </span>
                        {!isPast && days <= 7 && (
                          <span className="flex items-center gap-1 text-xs text-red-500 font-medium">
                            <AlertCircle className="w-3 h-3" />
                            {days === 0 ? t('dueToday') : `${t('examIn')} ${days} ${t('daysLeft')}`}
                          </span>
                        )}
                      </div>
                      <h3 className="font-bold text-gray-900 dark:text-white">{exam.title}</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{exam.courseName}</p>
                    </div>
                    <button
                      onClick={() => handleDelete(exam.id)}
                      className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"
                    >
                      <Trash2 className="w-4 h-4 text-red-400" />
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-3 text-xs text-gray-500 dark:text-gray-400">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{exam.date}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{exam.time} ({exam.duration} {t('minutes')})</span>
                    </div>
                    {exam.room && (
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5" />
                        <span>{exam.room}</span>
                      </div>
                    )}
                  </div>

                  {exam.notes && (
                    <p className="mt-2 text-sm text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-700/50 rounded-lg px-3 py-2">
                      {exam.notes}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Add Exam Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end justify-center animate-fade-in" onClick={() => setShowForm(false)}>
          <div
            className="w-full max-w-lg bg-white dark:bg-gray-800 rounded-t-3xl p-5 max-h-[85vh] overflow-y-auto animate-slide-up"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">{t('addExam')}</h2>
              <button onClick={() => setShowForm(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-xl">
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('examTitle')}</label>
                <input
                  type="text"
                  value={form.title}
                  onChange={e => setForm({...form, title: e.target.value})}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('course')}</label>
                <div className="relative">
                  <select
                    value={form.courseName}
                    onChange={e => setForm({...form, courseName: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white appearance-none focus:outline-none focus:ring-2 focus:ring-primary-500"
                  >
                    <option value="">--</option>
                    {state.courses.map(c => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-3 rtl:right-auto rtl:left-3 top-3.5 w-5 h-5 text-gray-400 pointer-events-none" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('date')}</label>
                  <input
                    type="date"
                    value={form.date}
                    onChange={e => setForm({...form, date: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('time')}</label>
                  <input
                    type="time"
                    value={form.time}
                    onChange={e => setForm({...form, time: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('type')}</label>
                  <div className="relative">
                    <select
                      value={form.type}
                      onChange={e => setForm({...form, type: e.target.value as any})}
                      className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white appearance-none focus:outline-none focus:ring-2 focus:ring-primary-500"
                    >
                      <option value="quiz">{t('quiz')}</option>
                      <option value="midterm">{t('midterm')}</option>
                      <option value="final">{t('final')}</option>
                    </select>
                    <ChevronDown className="absolute right-3 rtl:right-auto rtl:left-3 top-3.5 w-5 h-5 text-gray-400 pointer-events-none" />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('duration')} ({t('minutes')})</label>
                  <input
                    type="number"
                    value={form.duration}
                    onChange={e => setForm({...form, duration: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('room')}</label>
                <input
                  type="text"
                  value={form.room}
                  onChange={e => setForm({...form, room: e.target.value})}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('notes')}</label>
                <textarea
                  value={form.notes}
                  onChange={e => setForm({...form, notes: e.target.value})}
                  rows={2}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500 resize-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => setShowForm(false)}
                  className="flex-1 py-3 border border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-xl font-medium active:scale-95 transition-transform"
                >
                  {t('cancel')}
                </button>
                <button
                  onClick={handleSave}
                  disabled={!form.title || !form.date || saving}
                  className="flex-1 py-3 bg-primary-600 hover:bg-primary-700 disabled:bg-gray-300 text-white rounded-xl font-medium active:scale-95 transition-transform"
                >
                  {saving ? t('loading') : t('save')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
