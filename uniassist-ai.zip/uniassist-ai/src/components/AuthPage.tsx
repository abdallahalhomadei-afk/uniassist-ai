import type React from 'react';
import { useState } from 'react';
import { useApp } from '../store';
import { GraduationCap, Mail, Lock, User, Building2, BookOpen, Eye, EyeOff, Sparkles } from 'lucide-react';

export default function AuthPage() {
  const { state, dispatch, t, login, register } = useApp();
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({
    name: '', email: '', password: '', confirmPassword: '', university: '', major: ''
  });
  const [error, setError] = useState('');
  const loading = state.loading;

  const isRtl = state.language === 'ar';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!form.email || !form.password) {
      setError(isRtl ? 'يرجى ملء جميع الحقول' : 'Please fill in all fields');
      return;
    }

    if (!isLogin) {
      if (form.password !== form.confirmPassword) {
        setError(isRtl ? 'كلمات المرور غير متطابقة' : 'Passwords do not match');
        return;
      }
      if (form.password.length < 8) {
        setError(isRtl ? 'كلمة المرور يجب أن تكون 8 أحرف على الأقل' : 'Password must be at least 8 characters');
        return;
      }
    }

    try {
      if (isLogin) {
        await login(form.email, form.password);
      } else {
        await register({
          email: form.email,
          password: form.password,
          name: form.name || form.email.split('@')[0],
          university: form.university,
          major: form.major,
        });
      }
    } catch (err: any) {
      setError(err.message || (isRtl ? 'حدث خطأ ما' : 'An error occurred'));
    }
  };

  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-primary-600 via-primary-700 to-primary-900 dark:from-gray-900 dark:via-primary-950 dark:to-gray-900">
      {/* Top Section with Logo */}
      <div className="flex-shrink-0 pt-12 pb-6 px-6 text-center">
        <div className="animate-bounce-in">
          <div className="w-20 h-20 mx-auto bg-white/20 rounded-3xl flex items-center justify-center mb-4 backdrop-blur-sm border border-white/20">
            <GraduationCap className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-1">{t('appName')}</h1>
          <div className="flex items-center justify-center gap-1.5 text-primary-200">
            <Sparkles className="w-4 h-4" />
            <p className="text-sm font-medium">{t('appTagline')}</p>
          </div>
        </div>
      </div>

      {/* Form Card */}
      <div className="flex-1 bg-white dark:bg-gray-900 rounded-t-[2rem] px-6 pt-8 pb-6 overflow-y-auto animate-slide-up">
        <div className="max-w-sm mx-auto">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">
            {isLogin ? t('loginTitle') : t('registerTitle')}
          </h2>
          <p className="text-gray-500 dark:text-gray-400 mb-6 text-sm">
            {isLogin ? t('loginSubtitle') : t('registerSubtitle')}
          </p>

          {error && (
            <div className="bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 px-4 py-3 rounded-xl mb-4 text-sm animate-fade-in">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <>
                <div className="relative animate-fade-in">
                  <User className="absolute top-3.5 left-3 rtl:left-auto rtl:right-3 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder={t('fullName')}
                    value={form.name}
                    onChange={e => setForm({...form, name: e.target.value})}
                    className="w-full pl-11 rtl:pl-4 rtl:pr-11 pr-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                  />
                </div>
                <div className="relative animate-fade-in">
                  <Building2 className="absolute top-3.5 left-3 rtl:left-auto rtl:right-3 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder={t('university')}
                    value={form.university}
                    onChange={e => setForm({...form, university: e.target.value})}
                    className="w-full pl-11 rtl:pl-4 rtl:pr-11 pr-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                  />
                </div>
                <div className="relative animate-fade-in">
                  <BookOpen className="absolute top-3.5 left-3 rtl:left-auto rtl:right-3 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder={t('major')}
                    value={form.major}
                    onChange={e => setForm({...form, major: e.target.value})}
                    className="w-full pl-11 rtl:pl-4 rtl:pr-11 pr-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                  />
                </div>
              </>
            )}

            <div className="relative">
              <Mail className="absolute top-3.5 left-3 rtl:left-auto rtl:right-3 w-5 h-5 text-gray-400" />
              <input
                type="email"
                placeholder={t('email')}
                value={form.email}
                onChange={e => setForm({...form, email: e.target.value})}
                className="w-full pl-11 rtl:pl-4 rtl:pr-11 pr-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
              />
            </div>

            <div className="relative">
              <Lock className="absolute top-3.5 left-3 rtl:left-auto rtl:right-3 w-5 h-5 text-gray-400" />
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder={t('password')}
                value={form.password}
                onChange={e => setForm({...form, password: e.target.value})}
                className="w-full pl-11 rtl:pl-4 rtl:pr-11 pr-10 rtl:pr-11 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute top-3.5 right-3 rtl:right-auto rtl:left-3 text-gray-400"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>

            {!isLogin && (
              <div className="relative animate-fade-in">
                <Lock className="absolute top-3.5 left-3 rtl:left-auto rtl:right-3 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  placeholder={t('confirmPassword')}
                  value={form.confirmPassword}
                  onChange={e => setForm({...form, confirmPassword: e.target.value})}
                  className="w-full pl-11 rtl:pl-4 rtl:pr-11 pr-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                />
              </div>
            )}

            {isLogin && (
              <div className="text-right rtl:text-left">
                <button type="button" className="text-sm text-primary-600 dark:text-primary-400 font-medium hover:underline">
                  {t('forgotPassword')}
                </button>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 bg-gradient-to-r from-primary-600 to-primary-700 hover:from-primary-700 hover:to-primary-800 text-white font-semibold rounded-xl shadow-lg shadow-primary-500/30 transition-all duration-200 disabled:opacity-70 active:scale-[0.98]"
            >
              {loading ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>{t('loading')}</span>
                </div>
              ) : (
                isLogin ? t('loginButton') : t('registerButton')
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="flex items-center my-6">
            <div className="flex-1 border-t border-gray-200 dark:border-gray-700" />
            <span className="px-4 text-sm text-gray-400">{t('orContinueWith')}</span>
            <div className="flex-1 border-t border-gray-200 dark:border-gray-700" />
          </div>

          {/* Google Sign In */}
          <button
            type="button"
            className="w-full flex items-center justify-center gap-3 py-3 border border-gray-200 dark:border-gray-700 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            <span className="text-gray-700 dark:text-gray-300 font-medium">{t('google')}</span>
          </button>

          {/* Toggle */}
          <p className="text-center mt-6 text-sm text-gray-500 dark:text-gray-400">
            {isLogin ? t('noAccount') : t('hasAccount')}{' '}
            <button
              onClick={() => { setIsLogin(!isLogin); setError(''); }}
              className="text-primary-600 dark:text-primary-400 font-semibold hover:underline"
            >
              {isLogin ? t('register') : t('login')}
            </button>
          </p>

          {/* Language Toggle */}
          <div className="flex justify-center mt-4 gap-2">
            <button
              onClick={() => dispatch({ type: 'SET_LANGUAGE', payload: 'en' })}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${state.language === 'en' ? 'bg-primary-100 dark:bg-primary-900/50 text-primary-700 dark:text-primary-300' : 'text-gray-500 dark:text-gray-400'}`}
            >
              English
            </button>
            <button
              onClick={() => dispatch({ type: 'SET_LANGUAGE', payload: 'ar' })}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${state.language === 'ar' ? 'bg-primary-100 dark:bg-primary-900/50 text-primary-700 dark:text-primary-300' : 'text-gray-500 dark:text-gray-400'}`}
            >
              العربية
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
