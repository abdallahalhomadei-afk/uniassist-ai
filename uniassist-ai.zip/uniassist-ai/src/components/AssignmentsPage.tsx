import { useState } from 'react';
import { useApp } from '../store';
import type { Assignment } from '../types';
import { Plus, X, Trash2, CheckCircle2, Clock, AlertTriangle, ClipboardList, ChevronDown, Circle } from 'lucide-react';

export default function AssignmentsPage() {
  const { state, t, createAssignment, updateAssignment, completeAssignment, deleteAssignment } = useApp();
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState<string>('all');
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Partial<Assignment>>({
    title: '', courseId: '', courseName: '', dueDate: '', description: '', status: 'pending', priority: 'medium'
  });

  const handleSave = async () => {
    if (!form.title || !form.dueDate) return;
    setSaving(true);
    try {
      await createAssignment({
        title: form.title,
        course_id: form.courseId || undefined,
        due_date: form.dueDate,
        description: form.description,
        priority: form.priority,
        status: form.status,
      });
      setForm({ title: '', courseId: '', courseName: '', dueDate: '', description: '', status: 'pending', priority: 'medium' });
      setShowForm(false);
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const handleComplete = async (a: Assignment) => {
    try {
      if (a.status === 'completed') {
        await updateAssignment(a.id, { status: 'pending' });
      } else {
        await completeAssignment(a.id);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteAssignment(id);
    } catch (err) {
      console.error(err);
    }
  };

  const getDaysUntil = (date: string) => {
    return Math.ceil((new Date(date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
  };

  const filtered = state.assignments
    .filter(a => filter === 'all' || a.status === filter)
    .sort((a, b) => {
      if (a.status === 'completed' && b.status !== 'completed') return 1;
      if (a.status !== 'completed' && b.status === 'completed') return -1;
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    });

  const statusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400';
      case 'in-progress': return 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400';
      case 'overdue': return 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400';
      default: return 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300';
    }
  };

  const priorityColor = (p: string) => {
    switch (p) {
      case 'high': return 'border-l-red-500';
      case 'medium': return 'border-l-amber-500';
      default: return 'border-l-green-500';
    }
  };

  const filters = [
    { key: 'all', label: t('all') },
    { key: 'pending', label: t('pending') },
    { key: 'in-progress', label: t('inProgress') },
    { key: 'completed', label: t('completed') },
  ];

  return (
    <div className="h-full overflow-y-auto bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700 px-5 pt-12 pb-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t('assignmentsTitle')}</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{state.assignments.length} {t('assignments')}</p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="w-11 h-11 bg-primary-600 hover:bg-primary-700 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-primary-500/30 active:scale-95 transition-transform"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        {/* Filters */}
        <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
          {filters.map(f => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-colors ${
                filter === f.key
                  ? 'bg-primary-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-5 py-4">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-16 h-16 bg-orange-50 dark:bg-orange-900/30 rounded-2xl flex items-center justify-center mb-4">
              <ClipboardList className="w-8 h-8 text-orange-500" />
            </div>
            <p className="text-gray-500 dark:text-gray-400 font-medium">{t('noAssignments')}</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map(a => {
              const days = getDaysUntil(a.dueDate);
              return (
                <div
                  key={a.id}
                  className={`bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-700/50 border-l-4 ${priorityColor(a.priority)} animate-fade-in ${a.status === 'completed' ? 'opacity-60' : ''}`}
                >
                  <div className="flex items-start gap-3">
                    <button
                      onClick={() => handleComplete(a)}
                      className="mt-0.5 shrink-0"
                    >
                      {a.status === 'completed' ? (
                        <CheckCircle2 className="w-6 h-6 text-green-500" />
                      ) : (
                        <Circle className="w-6 h-6 text-gray-300 dark:text-gray-600" />
                      )}
                    </button>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <h3 className={`font-semibold text-gray-900 dark:text-white ${a.status === 'completed' ? 'line-through' : ''}`}>
                          {a.title}
                        </h3>
                        <button
                          onClick={() => handleDelete(a.id)}
                          className="p-1 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg ml-2"
                        >
                          <Trash2 className="w-4 h-4 text-red-400" />
                        </button>
                      </div>
                      {a.courseName && (
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{a.courseName}</p>
                      )}
                      {a.description && (
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1 line-clamp-2">{a.description}</p>
                      )}
                      <div className="flex items-center gap-2 mt-2 flex-wrap">
                        <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${statusColor(a.status)}`}>
                          {a.status === 'pending' ? t('pending') : a.status === 'in-progress' ? t('inProgress') : a.status === 'completed' ? t('completed') : t('overdue')}
                        </span>
                        <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400">
                          <Clock className="w-3 h-3" />
                          <span>{days <= 0 ? t('pastDue') : days === 1 ? t('dueTomorrow') : `${days} ${t('daysLeft')}`}</span>
                        </div>
                        {a.priority === 'high' && (
                          <div className="flex items-center gap-1 text-xs text-red-500">
                            <AlertTriangle className="w-3 h-3" />
                            <span>{t('high')}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Add Assignment Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end justify-center animate-fade-in" onClick={() => setShowForm(false)}>
          <div
            className="w-full max-w-lg bg-white dark:bg-gray-800 rounded-t-3xl p-5 max-h-[85vh] overflow-y-auto animate-slide-up"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">{t('addAssignment')}</h2>
              <button onClick={() => setShowForm(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-xl">
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('assignmentTitle')}</label>
                <input
                  type="text"
                  value={form.title}
                  onChange={e => setForm({...form, title: e.target.value})}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('course')}</label>
                <div className="relative">
                  <select
                    value={form.courseName}
                    onChange={e => setForm({...form, courseName: e.target.value, courseId: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white appearance-none focus:outline-none focus:ring-2 focus:ring-primary-500"
                  >
                    <option value="">--</option>
                    {state.courses.map(c => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-3 rtl:right-auto rtl:left-3 top-3.5 w-5 h-5 text-gray-400 pointer-events-none" />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('dueDate')}</label>
                <input
                  type="date"
                  value={form.dueDate}
                  onChange={e => setForm({...form, dueDate: e.target.value})}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('priority')}</label>
                  <div className="relative">
                    <select
                      value={form.priority}
                      onChange={e => setForm({...form, priority: e.target.value as any})}
                      className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white appearance-none focus:outline-none focus:ring-2 focus:ring-primary-500"
                    >
                      <option value="low">{t('low')}</option>
                      <option value="medium">{t('medium')}</option>
                      <option value="high">{t('high')}</option>
                    </select>
                    <ChevronDown className="absolute right-3 rtl:right-auto rtl:left-3 top-3.5 w-5 h-5 text-gray-400 pointer-events-none" />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('status')}</label>
                  <div className="relative">
                    <select
                      value={form.status}
                      onChange={e => setForm({...form, status: e.target.value as any})}
                      className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white appearance-none focus:outline-none focus:ring-2 focus:ring-primary-500"
                    >
                      <option value="pending">{t('pending')}</option>
                      <option value="in-progress">{t('inProgress')}</option>
                    </select>
                    <ChevronDown className="absolute right-3 rtl:right-auto rtl:left-3 top-3.5 w-5 h-5 text-gray-400 pointer-events-none" />
                  </div>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">{t('description')}</label>
                <textarea
                  value={form.description}
                  onChange={e => setForm({...form, description: e.target.value})}
                  rows={3}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500 resize-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => setShowForm(false)}
                  className="flex-1 py-3 border border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-xl font-medium active:scale-95 transition-transform"
                >
                  {t('cancel')}
                </button>
                <button
                  onClick={handleSave}
                  disabled={!form.title || !form.dueDate || saving}
                  className="flex-1 py-3 bg-primary-600 hover:bg-primary-700 disabled:bg-gray-300 text-white rounded-xl font-medium active:scale-95 transition-transform"
                >
                  {saving ? t('loading') : t('save')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
