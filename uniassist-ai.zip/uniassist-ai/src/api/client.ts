declare const __API_URL__: string | undefined;
const API_BASE_URL = (typeof __API_URL__ !== 'undefined' ? __API_URL__ : null) || 'http://localhost:3001/api';

interface RequestOptions {
  method?: string;
  body?: any;
  headers?: Record<string, string>;
}

class ApiClient {
  private accessToken: string | null = null;
  private refreshToken: string | null = null;
  
  constructor() {
    this.loadTokens();
  }
  
  private loadTokens() {
    try {
      const stored = localStorage.getItem('uniassist_tokens');
      if (stored) {
        const tokens = JSON.parse(stored);
        this.accessToken = tokens.accessToken;
        this.refreshToken = tokens.refreshToken;
      }
    } catch {
      // ignore
    }
  }
  
  private saveTokens(accessToken: string, refreshToken: string) {
    this.accessToken = accessToken;
    this.refreshToken = refreshToken;
    localStorage.setItem('uniassist_tokens', JSON.stringify({ accessToken, refreshToken }));
  }
  
  clearTokens() {
    this.accessToken = null;
    this.refreshToken = null;
    localStorage.removeItem('uniassist_tokens');
  }
  
  isAuthenticated(): boolean {
    return !!this.accessToken;
  }
  
  async request<T = any>(endpoint: string, options: RequestOptions = {}): Promise<T> {
    const { method = 'GET', body, headers = {} } = options;
    
    const requestHeaders: Record<string, string> = {
      ...headers,
    };
    
    if (this.accessToken) {
      requestHeaders['Authorization'] = `Bearer ${this.accessToken}`;
    }
    
    if (body && !(body instanceof FormData)) {
      requestHeaders['Content-Type'] = 'application/json';
    }
    
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method,
      headers: requestHeaders,
      body: body instanceof FormData ? body : body ? JSON.stringify(body) : undefined,
    });
    
    // Handle token refresh
    if (response.status === 401 && this.refreshToken) {
      const refreshed = await this.refreshAccessToken();
      if (refreshed) {
        requestHeaders['Authorization'] = `Bearer ${this.accessToken}`;
        const retryResponse = await fetch(`${API_BASE_URL}${endpoint}`, {
          method,
          headers: requestHeaders,
          body: body instanceof FormData ? body : body ? JSON.stringify(body) : undefined,
        });
        return this.handleResponse(retryResponse);
      }
    }
    
    return this.handleResponse(response);
  }
  
  private async handleResponse<T>(response: Response): Promise<T> {
    if (response.status === 204) {
      return undefined as T;
    }
    
    const data = await response.json().catch(() => ({}));
    
    if (!response.ok) {
      throw new Error(data.error || `HTTP error ${response.status}`);
    }
    
    return data;
  }
  
  private async refreshAccessToken(): Promise<boolean> {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken: this.refreshToken }),
      });
      
      if (response.ok) {
        const data = await response.json();
        this.saveTokens(data.accessToken, data.refreshToken);
        return true;
      }
    } catch {
      // ignore
    }
    
    this.clearTokens();
    return false;
  }
  
  // Auth endpoints
  async register(data: { email: string; password: string; name: string; university?: string; major?: string }) {
    const result = await this.request<{ user: any; accessToken: string; refreshToken: string }>('/auth/register', {
      method: 'POST',
      body: data,
    });
    this.saveTokens(result.accessToken, result.refreshToken);
    return result;
  }
  
  async login(data: { email: string; password: string }) {
    const result = await this.request<{ user: any; accessToken: string; refreshToken: string }>('/auth/login', {
      method: 'POST',
      body: data,
    });
    this.saveTokens(result.accessToken, result.refreshToken);
    return result;
  }
  
  async logout() {
    try {
      await this.request('/auth/logout', { method: 'POST', body: { refreshToken: this.refreshToken } });
    } finally {
      this.clearTokens();
    }
  }
  
  async getProfile() {
    return this.request('/auth/me');
  }
  
  async updateProfile(data: any) {
    return this.request('/auth/me', { method: 'PATCH', body: data });
  }
  
  async setApiKey(apiKey: string) {
    return this.request('/auth/api-key', { method: 'POST', body: { apiKey } });
  }
  
  async getDashboard() {
    return this.request('/auth/dashboard');
  }
  
  // Courses
  async getCourses() {
    return this.request('/courses');
  }
  
  async createCourse(data: any) {
    return this.request('/courses', { method: 'POST', body: data });
  }
  
  async updateCourse(id: string, data: any) {
    return this.request(`/courses/${id}`, { method: 'PATCH', body: data });
  }
  
  async deleteCourse(id: string) {
    return this.request(`/courses/${id}`, { method: 'DELETE' });
  }
  
  async getTodaySchedule() {
    return this.request('/courses/today');
  }
  
  // Assignments
  async getAssignments(options: { status?: string; upcoming?: boolean } = {}) {
    const params = new URLSearchParams();
    if (options.status) params.append('status', options.status);
    if (options.upcoming) params.append('upcoming', 'true');
    return this.request(`/assignments?${params}`);
  }
  
  async createAssignment(data: any) {
    return this.request('/assignments', { method: 'POST', body: data });
  }
  
  async updateAssignment(id: string, data: any) {
    return this.request(`/assignments/${id}`, { method: 'PATCH', body: data });
  }
  
  async deleteAssignment(id: string) {
    return this.request(`/assignments/${id}`, { method: 'DELETE' });
  }
  
  async completeAssignment(id: string) {
    return this.request(`/assignments/${id}/complete`, { method: 'POST' });
  }
  
  async getUpcomingDeadlines(days = 7) {
    return this.request(`/assignments/upcoming?days=${days}`);
  }
  
  // Exams
  async getExams(options: { upcoming?: boolean } = {}) {
    const params = new URLSearchParams();
    if (options.upcoming) params.append('upcoming', 'true');
    return this.request(`/exams?${params}`);
  }
  
  async createExam(data: any) {
    return this.request('/exams', { method: 'POST', body: data });
  }
  
  async updateExam(id: string, data: any) {
    return this.request(`/exams/${id}`, { method: 'PATCH', body: data });
  }
  
  async deleteExam(id: string) {
    return this.request(`/exams/${id}`, { method: 'DELETE' });
  }
  
  async getUpcomingExams(days = 14) {
    return this.request(`/exams/upcoming?days=${days}`);
  }
  
  // Grades
  async getGrades(semester?: string) {
    const params = semester ? `?semester=${semester}` : '';
    return this.request(`/grades${params}`);
  }
  
  async createGrade(data: any) {
    return this.request('/grades', { method: 'POST', body: data });
  }
  
  async deleteGrade(id: string) {
    return this.request(`/grades/${id}`, { method: 'DELETE' });
  }
  
  async getGPA() {
    return this.request('/grades/gpa');
  }
  
  // Documents
  async getDocuments() {
    return this.request('/documents');
  }
  
  async uploadDocument(file: File, courseId?: string) {
    const formData = new FormData();
    formData.append('file', file);
    if (courseId) formData.append('course_id', courseId);
    return this.request('/documents', { method: 'POST', body: formData });
  }
  
  async deleteDocument(id: string) {
    return this.request(`/documents/${id}`, { method: 'DELETE' });
  }
  
  async askAboutDocument(id: string, question: string) {
    return this.request(`/documents/${id}/ask`, { method: 'POST', body: { question } });
  }
  
  // Audio
  async transcribeAudio(file: File) {
    const formData = new FormData();
    formData.append('audio', file);
    return this.request('/audio/transcribe', { method: 'POST', body: formData });
  }
  
  async getTranscriptions() {
    return this.request('/audio');
  }
  
  // Chat
  async sendChatMessage(message: string) {
    return this.request('/chat/message', { method: 'POST', body: { message } });
  }
  
  async getChatHistory() {
    return this.request('/chat/history');
  }
  
  async clearChatHistory() {
    return this.request('/chat/history', { method: 'DELETE' });
  }
  
  // Notifications
  async getNotifications(unreadOnly = false) {
    return this.request(`/notifications?unreadOnly=${unreadOnly}`);
  }
  
  async getUnreadCount() {
    return this.request<{ count: number }>('/notifications/unread-count');
  }
  
  async markNotificationRead(id: string) {
    return this.request(`/notifications/${id}/read`, { method: 'POST' });
  }
  
  async markAllNotificationsRead() {
    return this.request('/notifications/read-all', { method: 'POST' });
  }
  
  // Search
  async search(query: string, types?: string[]) {
    const params = new URLSearchParams({ q: query });
    if (types) params.append('types', types.join(','));
    return this.request(`/search?${params}`);
  }
  
  async getSearchSuggestions(query: string) {
    return this.request(`/search/suggestions?q=${encodeURIComponent(query)}`);
  }
  
  // Archives
  async getArchives(entityType?: string) {
    const params = entityType ? `?entityType=${entityType}` : '';
    return this.request(`/archives${params}`);
  }
  
  async restoreFromArchive(id: string) {
    return this.request(`/archives/${id}/restore`, { method: 'POST' });
  }
  
  async permanentlyDelete(id: string) {
    return this.request(`/archives/${id}`, { method: 'DELETE' });
  }
}

export const api = new ApiClient();
export default api;
