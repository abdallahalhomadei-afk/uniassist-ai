# UniAssist AI - Installation Guide

This guide covers the complete installation process for UniAssist AI on various platforms.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Quick Start](#quick-start)
3. [Manual Installation](#manual-installation)
4. [Docker Installation](#docker-installation)
5. [Database Setup](#database-setup)
6. [Environment Configuration](#environment-configuration)
7. [Telegram Bot Setup](#telegram-bot-setup)
8. [Verification](#verification)
9. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Required Software

| Software | Minimum Version | Purpose |
|----------|-----------------|---------|
| Node.js | 18.x | Runtime environment |
| npm | 9.x | Package manager |
| PostgreSQL | 14.x | Database |

### Optional Software

| Software | Purpose |
|----------|---------|
| Docker & Docker Compose | Containerized deployment |
| OpenAI API Key | AI features (chat, analysis) |
| Telegram Bot Token | Telegram integration |

### System Requirements

- **RAM**: Minimum 2GB, Recommended 4GB
- **Storage**: Minimum 1GB free space
- **OS**: Linux, macOS, or Windows with WSL2

---

## Quick Start

### Using Docker (Recommended)

```bash
# Clone the repository
git clone https://github.com/your-org/uniassist-ai.git
cd uniassist-ai

# Start all services
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f api
```

The application will be available at `http://localhost:3001`

### Using npm

```bash
# Clone the repository
git clone https://github.com/your-org/uniassist-ai.git
cd uniassist-ai

# Install dependencies
npm install

# Setup database (see Database Setup section)
# Configure environment (see Environment Configuration section)

# Start development servers
npm run dev                    # Frontend (Vite)
npx tsx server/index.ts        # Backend (in separate terminal)
```

---

## Manual Installation

### Step 1: Install Node.js

**Ubuntu/Debian:**
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
```

**macOS:**
```bash
brew install node@20
```

**Windows:**
Download from https://nodejs.org/

Verify installation:
```bash
node --version  # Should show v20.x.x
npm --version   # Should show 10.x.x
```

### Step 2: Install PostgreSQL

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib

# Start PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

**macOS:**
```bash
brew install postgresql@15
brew services start postgresql@15
```

**Windows:**
Download from https://www.postgresql.org/download/windows/

### Step 3: Clone and Install

```bash
# Clone repository
git clone https://github.com/your-org/uniassist-ai.git
cd uniassist-ai

# Install dependencies
npm install

# Create uploads directory
mkdir -p uploads/documents uploads/audio
```

---

## Docker Installation

### Prerequisites

Install Docker and Docker Compose:

**Ubuntu:**
```bash
# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo apt install docker-compose-plugin

# Add your user to docker group
sudo usermod -aG docker $USER
```

### Configuration

1. Create environment file:
```bash
cp server/.env.example .env
```

2. Edit `.env` with your settings:
```bash
nano .env
```

3. Generate secrets:
```bash
# Generate JWT secret
echo "JWT_SECRET=$(openssl rand -hex 32)"
echo "JWT_REFRESH_SECRET=$(openssl rand -hex 32)"
echo "ENCRYPTION_KEY=$(openssl rand -hex 32)"
```

### Start Services

```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down

# Stop and remove volumes (WARNING: deletes data)
docker-compose down -v
```

---

## Database Setup

### Create Database

```bash
# Connect to PostgreSQL
sudo -u postgres psql

# Create user and database
CREATE USER uniassist WITH PASSWORD 'your_secure_password';
CREATE DATABASE uniassist OWNER uniassist;
GRANT ALL PRIVILEGES ON DATABASE uniassist TO uniassist;

# Connect to the database
\c uniassist

# Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

# Exit
\q
```

### Run Schema

```bash
# Apply schema
psql -U uniassist -d uniassist -f server/database/schema.sql
```

Or using environment variable:
```bash
export DATABASE_URL="postgresql://uniassist:your_password@localhost:5432/uniassist"
psql $DATABASE_URL -f server/database/schema.sql
```

### Verify Tables

```bash
psql -U uniassist -d uniassist -c "\dt"
```

Expected output:
```
                List of relations
 Schema |         Name          | Type  |  Owner   
--------+-----------------------+-------+----------
 public | api_usage_log         | table | uniassist
 public | archives              | table | uniassist
 public | assignments           | table | uniassist
 public | audio_transcriptions  | table | uniassist
 public | chat_messages         | table | uniassist
 public | course_schedules      | table | uniassist
 public | courses               | table | uniassist
 public | documents             | table | uniassist
 public | exams                 | table | uniassist
 public | grades                | table | uniassist
 public | notifications         | table | uniassist
 public | search_history        | table | uniassist
 public | sessions              | table | uniassist
 public | telegram_messages     | table | uniassist
 public | users                 | table | uniassist
```

---

## Environment Configuration

### Create Configuration File

```bash
cp server/.env.example server/.env
```

### Generate Secrets

```bash
# Generate secure random strings
openssl rand -hex 32  # For JWT_SECRET
openssl rand -hex 32  # For JWT_REFRESH_SECRET
openssl rand -hex 32  # For ENCRYPTION_KEY
```

### Required Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://user:pass@localhost:5432/uniassist` |
| `JWT_SECRET` | JWT signing key (32+ chars) | Random hex string |
| `JWT_REFRESH_SECRET` | Refresh token key (32+ chars) | Random hex string |
| `ENCRYPTION_KEY` | Data encryption key (32+ chars) | Random hex string |
| `STORAGE_PATH` | File upload directory | `./uploads` |

### Optional Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `OPENAI_API_KEY` | OpenAI API key | - |
| `TELEGRAM_BOT_TOKEN` | Telegram bot token | - |
| `PORT` | Server port | `3001` |
| `NODE_ENV` | Environment | `development` |

---

## Telegram Bot Setup

### Create Bot

1. Open Telegram and search for `@BotFather`
2. Send `/newbot`
3. Follow the prompts to name your bot
4. Copy the HTTP API token

### Configure Bot

Add to your `.env`:
```bash
TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
```

### Bot Commands

After starting the server, set up bot commands:

1. Open `@BotFather`
2. Send `/setcommands`
3. Select your bot
4. Paste:
```
start - Link your account
add_assignment - Add assignment (Title | Due Date)
add_exam - Add exam (Title | Date | Time)
schedule - View today's schedule
deadlines - View upcoming deadlines
ask - Ask AI a question
unlink - Unlink account
```

---

## Verification

### Check Server Health

```bash
curl http://localhost:3001/health
```

Expected response:
```json
{
  "status": "healthy",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "database": "connected"
}
```

### Test API

```bash
# Register a user
curl -X POST http://localhost:3001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "testpassword123",
    "name": "Test User"
  }'
```

### Test Database Connection

```bash
psql $DATABASE_URL -c "SELECT COUNT(*) FROM users;"
```

---

## Troubleshooting

### Common Issues

#### Database Connection Failed

```
Error: Connection refused to localhost:5432
```

**Solution:**
```bash
# Check PostgreSQL is running
sudo systemctl status postgresql

# Start if not running
sudo systemctl start postgresql
```

#### Permission Denied on Uploads

```
Error: EACCES: permission denied, mkdir 'uploads'
```

**Solution:**
```bash
mkdir -p uploads/documents uploads/audio
chmod 755 uploads
```

#### Invalid Token Error

```
Error: Invalid JWT token
```

**Solution:**
- Ensure `JWT_SECRET` is at least 32 characters
- Clear browser storage and login again

#### PostgreSQL Extension Missing

```
Error: extension "uuid-ossp" is not available
```

**Solution:**
```bash
sudo apt install postgresql-contrib
sudo -u postgres psql -d uniassist -c "CREATE EXTENSION uuid-ossp;"
```

### Logs

```bash
# View server logs
npx tsx server/index.ts 2>&1 | tee server.log

# Docker logs
docker-compose logs -f api

# PostgreSQL logs
sudo tail -f /var/log/postgresql/postgresql-*-main.log
```

### Reset Database

```bash
# WARNING: This deletes all data
psql -U postgres -c "DROP DATABASE uniassist;"
psql -U postgres -c "CREATE DATABASE uniassist OWNER uniassist;"
psql -U uniassist -d uniassist -f server/database/schema.sql
```

---

## Next Steps

After successful installation:

1. Review [DEPLOYMENT.md](./DEPLOYMENT.md) for production deployment
2. Configure OpenAI API key for AI features
3. Set up Telegram bot for mobile notifications
4. Configure email for password reset functionality

## Support

- **Issues**: Open an issue on GitHub
- **Documentation**: See `/docs` directory
- **API Reference**: See `README.md`
