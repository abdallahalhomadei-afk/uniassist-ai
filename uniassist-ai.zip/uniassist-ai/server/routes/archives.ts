import { Router } from 'express';
import { asyncHandler } from '../middleware/errorHandler';
import { authenticate, AuthRequest } from '../middleware/auth';
import * as archiveService from '../services/archiveService';

const router = Router();

// Get archives
router.get('/', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { entityType, limit, offset } = req.query;
  const archives = await archiveService.getArchives(req.userId!, {
    entityType: entityType as any,
    limit: limit ? parseInt(limit as string) : undefined,
    offset: offset ? parseInt(offset as string) : undefined,
  });
  res.json(archives);
}));

// Get archive stats
router.get('/stats', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const stats = await archiveService.getArchiveStats(req.userId!);
  res.json(stats);
}));

// Get single archive
router.get('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const archive = await archiveService.getArchiveById(req.userId!, req.params.id);
  res.json(archive);
}));

// Restore from archive
router.post('/:id/restore', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const result = await archiveService.restoreFromArchive(req.userId!, req.params.id);
  res.json(result);
}));

// Permanently delete
router.delete('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  await archiveService.permanentlyDelete(req.userId!, req.params.id);
  res.status(204).send();
}));

export default router;
