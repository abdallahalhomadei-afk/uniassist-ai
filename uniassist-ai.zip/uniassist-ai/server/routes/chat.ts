import { Router } from 'express';
import { asyncHandler } from '../middleware/errorHandler';
import { authenticate, AuthRequest } from '../middleware/auth';
import * as chatService from '../services/chatService';

const router = Router();

// Get chat history
router.get('/history', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { limit, offset, before } = req.query;
  const messages = await chatService.getChatHistory(req.userId!, {
    limit: limit ? parseInt(limit as string) : undefined,
    offset: offset ? parseInt(offset as string) : undefined,
    before: before as string,
  });
  res.json(messages);
}));

// Send message
router.post('/message', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { message } = req.body;
  if (!message || typeof message !== 'string') {
    res.status(400).json({ error: 'Message required' });
    return;
  }
  
  const response = await chatService.sendMessage(req.userId!, message);
  res.json(response);
}));

// Clear chat history
router.delete('/history', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  await chatService.clearChatHistory(req.userId!);
  res.status(204).send();
}));

// Delete specific message
router.delete('/message/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  await chatService.deleteChatMessage(req.userId!, req.params.id);
  res.status(204).send();
}));

export default router;
