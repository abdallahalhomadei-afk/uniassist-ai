import { Router } from 'express';
import { asyncHandler } from '../middleware/errorHandler';
import { authenticate, AuthRequest } from '../middleware/auth';
import * as gradeService from '../services/gradeService';
import { z } from 'zod';

const router = Router();

const gradeSchema = z.object({
  course_id: z.string().uuid().optional(),
  course_name: z.string().min(1),
  course_code: z.string().optional(),
  credits: z.number().min(1).max(10),
  grade: z.string().min(1),
  semester: z.string().min(1),
  year: z.number().optional(),
});

// Get all grades
router.get('/', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { semester, includeArchived } = req.query;
  const grades = await gradeService.getGrades(req.userId!, {
    semester: semester as string,
    includeArchived: includeArchived === 'true',
  });
  res.json(grades);
}));

// Get GPA calculation
router.get('/gpa', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const gpa = await gradeService.calculateGPA(req.userId!);
  res.json(gpa);
}));

// Get semesters
router.get('/semesters', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const semesters = await gradeService.getSemesters(req.userId!);
  res.json(semesters);
}));

// Get single grade
router.get('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const grade = await gradeService.getGradeById(req.userId!, req.params.id);
  res.json(grade);
}));

// Create grade
router.post('/', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const data = gradeSchema.parse(req.body);
  const grade = await gradeService.createGrade(req.userId!, data);
  res.status(201).json(grade);
}));

// Update grade
router.patch('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const data = gradeSchema.partial().parse(req.body);
  const grade = await gradeService.updateGrade(req.userId!, req.params.id, data);
  res.json(grade);
}));

// Delete grade
router.delete('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  await gradeService.deleteGrade(req.userId!, req.params.id);
  res.status(204).send();
}));

export default router;
