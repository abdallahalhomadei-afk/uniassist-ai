import { Router } from 'express';
import { asyncHandler } from '../middleware/errorHandler';
import { authenticate, AuthRequest } from '../middleware/auth';
import * as userService from '../services/userService';
import { z } from 'zod';

const router = Router();

// Validation schemas
const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  name: z.string().min(2),
  university: z.string().optional(),
  major: z.string().optional(),
  language: z.enum(['en', 'ar']).optional(),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

// Register
router.post('/register', asyncHandler(async (req, res) => {
  const data = registerSchema.parse(req.body);
  const result = await userService.createUser(data);
  res.status(201).json(result);
}));

// Login
router.post('/login', asyncHandler(async (req, res) => {
  const data = loginSchema.parse(req.body);
  const result = await userService.loginUser(data);
  res.json(result);
}));

// Refresh token
router.post('/refresh', asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) {
    res.status(400).json({ error: 'Refresh token required' });
    return;
  }
  const result = await userService.refreshTokens(refreshToken);
  res.json(result);
}));

// Logout
router.post('/logout', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { refreshToken } = req.body;
  await userService.logout(req.userId!, refreshToken);
  res.json({ success: true });
}));

// Get current user
router.get('/me', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const profile = await userService.getProfile(req.userId!);
  res.json(profile);
}));

// Update profile
router.patch('/me', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const profile = await userService.updateProfile(req.userId!, req.body);
  res.json(profile);
}));

// Change password
router.post('/change-password', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { currentPassword, newPassword } = req.body;
  await userService.changePassword(req.userId!, currentPassword, newPassword);
  res.json({ success: true });
}));

// Set API key
router.post('/api-key', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { apiKey } = req.body;
  await userService.setApiKey(req.userId!, apiKey);
  res.json({ success: true });
}));

// Get dashboard summary
router.get('/dashboard', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const summary = await userService.getDashboardSummary(req.userId!);
  res.json(summary);
}));

export default router;
