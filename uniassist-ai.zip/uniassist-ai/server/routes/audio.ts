import { Router } from 'express';
import { asyncHandler } from '../middleware/errorHandler';
import { authenticate, AuthRequest } from '../middleware/auth';
import * as audioService from '../services/audioService';
import multer from 'multer';

const router = Router();

// Configure multer for audio uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 25 * 1024 * 1024, // 25MB limit (Whisper max)
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'audio/mpeg',
      'audio/mp3',
      'audio/wav',
      'audio/webm',
      'audio/ogg',
      'audio/mp4',
      'audio/m4a',
      'audio/x-m4a',
    ];
    if (allowedTypes.includes(file.mimetype) || file.originalname.match(/\.(mp3|wav|webm|ogg|m4a)$/i)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid audio format. Supported: MP3, WAV, WEBM, OGG, M4A'));
    }
  },
});

// Get all transcriptions
router.get('/', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const transcriptions = await audioService.getTranscriptions(req.userId!);
  res.json(transcriptions);
}));

// Get single transcription
router.get('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const transcription = await audioService.getTranscriptionById(req.userId!, req.params.id);
  res.json(transcription);
}));

// Upload and transcribe audio
router.post('/transcribe', authenticate, upload.single('audio'), asyncHandler(async (req: AuthRequest, res) => {
  if (!req.file) {
    res.status(400).json({ error: 'No audio file uploaded' });
    return;
  }
  
  const transcription = await audioService.uploadAndTranscribe(req.userId!, {
    originalname: req.file.originalname,
    mimetype: req.file.mimetype,
    size: req.file.size,
    buffer: req.file.buffer,
  });
  
  res.status(201).json(transcription);
}));

// Delete transcription
router.delete('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  await audioService.deleteTranscription(req.userId!, req.params.id);
  res.status(204).send();
}));

export default router;
