import { Router } from 'express';
import { asyncHandler } from '../middleware/errorHandler';
import { authenticate, AuthRequest } from '../middleware/auth';
import * as notificationService from '../services/notificationService';

const router = Router();

// Get notifications
router.get('/', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { unreadOnly, limit, offset } = req.query;
  const notifications = await notificationService.getNotifications(req.userId!, {
    unreadOnly: unreadOnly === 'true',
    limit: limit ? parseInt(limit as string) : undefined,
    offset: offset ? parseInt(offset as string) : undefined,
  });
  res.json(notifications);
}));

// Get unread count
router.get('/unread-count', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const count = await notificationService.getUnreadCount(req.userId!);
  res.json({ count });
}));

// Mark as read
router.post('/:id/read', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  await notificationService.markAsRead(req.userId!, req.params.id);
  res.json({ success: true });
}));

// Mark all as read
router.post('/read-all', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  await notificationService.markAllAsRead(req.userId!);
  res.json({ success: true });
}));

// Delete notification
router.delete('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  await notificationService.deleteNotification(req.userId!, req.params.id);
  res.status(204).send();
}));

export default router;
