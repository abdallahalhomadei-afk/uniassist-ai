import { Router } from 'express';
import { asyncHandler } from '../middleware/errorHandler';
import { authenticate, AuthRequest } from '../middleware/auth';
import * as assignmentService from '../services/assignmentService';
import { z } from 'zod';

const router = Router();

const assignmentSchema = z.object({
  course_id: z.string().uuid().optional(),
  title: z.string().min(1),
  description: z.string().optional(),
  due_date: z.string(),
  priority: z.enum(['low', 'medium', 'high']).optional(),
  status: z.enum(['pending', 'in-progress', 'completed']).optional(),
  estimated_hours: z.number().positive().optional(),
  tags: z.array(z.string()).optional(),
});

// Get all assignments
router.get('/', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { status, courseId, includeArchived, upcoming, overdue } = req.query;
  const assignments = await assignmentService.getAssignments(req.userId!, {
    status: status as string,
    courseId: courseId as string,
    includeArchived: includeArchived === 'true',
    upcoming: upcoming === 'true',
    overdue: overdue === 'true',
  });
  res.json(assignments);
}));

// Get upcoming deadlines
router.get('/upcoming', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const days = parseInt(req.query.days as string) || 7;
  const deadlines = await assignmentService.getUpcomingDeadlines(req.userId!, days);
  res.json(deadlines);
}));

// Get single assignment
router.get('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const assignment = await assignmentService.getAssignmentById(req.userId!, req.params.id);
  res.json(assignment);
}));

// Create assignment
router.post('/', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const data = assignmentSchema.parse(req.body);
  const assignment = await assignmentService.createAssignment(req.userId!, data);
  res.status(201).json(assignment);
}));

// Update assignment
router.patch('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const data = assignmentSchema.partial().extend({
    grade: z.number().optional(),
    max_grade: z.number().optional(),
    actual_hours: z.number().optional(),
    submission_url: z.string().optional(),
    notes: z.string().optional(),
  }).parse(req.body);
  const assignment = await assignmentService.updateAssignment(req.userId!, req.params.id, data);
  res.json(assignment);
}));

// Delete assignment
router.delete('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  await assignmentService.deleteAssignment(req.userId!, req.params.id);
  res.status(204).send();
}));

// Archive assignment
router.post('/:id/archive', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const result = await assignmentService.archiveAssignment(req.userId!, req.params.id);
  res.json(result);
}));

// Mark as complete
router.post('/:id/complete', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const assignment = await assignmentService.updateAssignment(req.userId!, req.params.id, {
    status: 'completed',
  });
  res.json(assignment);
}));

export default router;
