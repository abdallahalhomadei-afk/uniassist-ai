import { Router } from 'express';
import { asyncHandler } from '../middleware/errorHandler';
import { authenticate, AuthRequest } from '../middleware/auth';
import * as courseService from '../services/courseService';
import { z } from 'zod';

const router = Router();

const scheduleSchema = z.object({
  day_of_week: z.number().min(0).max(6),
  start_time: z.string(),
  end_time: z.string(),
  room: z.string().optional(),
  building: z.string().optional(),
});

const courseSchema = z.object({
  name: z.string().min(1),
  code: z.string().min(1),
  instructor: z.string().optional(),
  color: z.string().optional(),
  credits: z.number().min(1).max(10).optional(),
  semester: z.string().optional(),
  year: z.number().optional(),
  schedule: z.array(scheduleSchema).optional(),
});

// Get all courses
router.get('/', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { includeArchived, semester } = req.query;
  const courses = await courseService.getCourses(req.userId!, {
    includeArchived: includeArchived === 'true',
    semester: semester as string,
  });
  res.json(courses);
}));

// Get today's schedule
router.get('/today', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const schedule = await courseService.getTodaySchedule(req.userId!);
  res.json(schedule);
}));

// Get single course
router.get('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const course = await courseService.getCourseById(req.userId!, req.params.id);
  res.json(course);
}));

// Create course
router.post('/', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const data = courseSchema.parse(req.body);
  const course = await courseService.createCourse(req.userId!, data);
  res.status(201).json(course);
}));

// Update course
router.patch('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const data = courseSchema.partial().parse(req.body);
  const course = await courseService.updateCourse(req.userId!, req.params.id, data);
  res.json(course);
}));

// Delete course
router.delete('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  await courseService.deleteCourse(req.userId!, req.params.id);
  res.status(204).send();
}));

// Archive course
router.post('/:id/archive', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const result = await courseService.archiveCourse(req.userId!, req.params.id);
  res.json(result);
}));

export default router;
