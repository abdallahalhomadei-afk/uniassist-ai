import { Router } from 'express';
import { asyncHandler } from '../middleware/errorHandler';
import { authenticate, AuthRequest } from '../middleware/auth';
import * as documentService from '../services/documentService';
import multer from 'multer';

const router = Router();

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'application/pdf',
      'text/plain',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/markdown',
    ];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Supported: PDF, TXT, DOC, DOCX, MD'));
    }
  },
});

// Get all documents
router.get('/', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { courseId, includeArchived } = req.query;
  const documents = await documentService.getDocuments(req.userId!, {
    courseId: courseId as string,
    includeArchived: includeArchived === 'true',
  });
  res.json(documents);
}));

// Get single document
router.get('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const document = await documentService.getDocumentById(req.userId!, req.params.id);
  res.json(document);
}));

// Download document
router.get('/:id/download', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { buffer, mimeType, filename } = await documentService.getDocumentContent(req.userId!, req.params.id);
  res.setHeader('Content-Type', mimeType);
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.send(buffer);
}));

// Upload document
router.post('/', authenticate, upload.single('file'), asyncHandler(async (req: AuthRequest, res) => {
  if (!req.file) {
    res.status(400).json({ error: 'No file uploaded' });
    return;
  }
  
  const courseId = req.body.course_id;
  const document = await documentService.uploadDocument(req.userId!, {
    originalname: req.file.originalname,
    mimetype: req.file.mimetype,
    size: req.file.size,
    buffer: req.file.buffer,
  }, courseId);
  
  res.status(201).json(document);
}));

// Ask about document
router.post('/:id/ask', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { question } = req.body;
  if (!question) {
    res.status(400).json({ error: 'Question required' });
    return;
  }
  
  const answer = await documentService.askAboutDocument(req.userId!, req.params.id, question);
  res.json({ answer });
}));

// Delete document
router.delete('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  await documentService.deleteDocument(req.userId!, req.params.id);
  res.status(204).send();
}));

export default router;
