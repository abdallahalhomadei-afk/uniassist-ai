import { Router } from 'express';
import { asyncHandler } from '../middleware/errorHandler';
import { authenticate, AuthRequest } from '../middleware/auth';
import * as searchService from '../services/searchService';

const router = Router();

// Global search
router.get('/', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { q, types, courseId, dateFrom, dateTo, status, limit, offset } = req.query;
  
  if (!q || typeof q !== 'string') {
    res.status(400).json({ error: 'Search query required' });
    return;
  }
  
  const results = await searchService.search(req.userId!, q, {
    types: types ? (types as string).split(',') : undefined,
    courseId: courseId as string,
    dateFrom: dateFrom as string,
    dateTo: dateTo as string,
    status: status as string,
    limit: limit ? parseInt(limit as string) : undefined,
    offset: offset ? parseInt(offset as string) : undefined,
  });
  
  res.json(results);
}));

// Get suggestions
router.get('/suggestions', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { q } = req.query;
  
  if (!q || typeof q !== 'string') {
    res.json([]);
    return;
  }
  
  const suggestions = await searchService.getSuggestions(req.userId!, q);
  res.json(suggestions);
}));

// Get search history
router.get('/history', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
  const history = await searchService.getSearchHistory(req.userId!, limit);
  res.json(history);
}));

export default router;
