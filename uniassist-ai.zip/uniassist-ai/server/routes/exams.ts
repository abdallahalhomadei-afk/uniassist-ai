import { Router } from 'express';
import { asyncHandler } from '../middleware/errorHandler';
import { authenticate, AuthRequest } from '../middleware/auth';
import * as examService from '../services/examService';
import { z } from 'zod';

const router = Router();

const examSchema = z.object({
  course_id: z.string().uuid().optional(),
  title: z.string().min(1),
  description: z.string().optional(),
  exam_date: z.string(),
  start_time: z.string(),
  end_time: z.string().optional(),
  duration_minutes: z.number().positive().optional(),
  room: z.string().optional(),
  building: z.string().optional(),
  exam_type: z.enum(['quiz', 'midterm', 'final', 'practical', 'oral', 'other']).optional(),
  weight: z.number().min(0).max(100).optional(),
  topics: z.array(z.string()).optional(),
  materials_allowed: z.string().optional(),
  notes: z.string().optional(),
});

// Get all exams
router.get('/', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const { courseId, examType, includeArchived, upcoming, past } = req.query;
  const exams = await examService.getExams(req.userId!, {
    courseId: courseId as string,
    examType: examType as string,
    includeArchived: includeArchived === 'true',
    upcoming: upcoming === 'true',
    past: past === 'true',
  });
  res.json(exams);
}));

// Get upcoming exams
router.get('/upcoming', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const days = parseInt(req.query.days as string) || 14;
  const exams = await examService.getUpcomingExams(req.userId!, days);
  res.json(exams);
}));

// Get single exam
router.get('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const exam = await examService.getExamById(req.userId!, req.params.id);
  res.json(exam);
}));

// Create exam
router.post('/', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const data = examSchema.parse(req.body);
  const exam = await examService.createExam(req.userId!, data);
  res.status(201).json(exam);
}));

// Update exam
router.patch('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const data = examSchema.partial().extend({
    grade: z.number().optional(),
    max_grade: z.number().optional(),
  }).parse(req.body);
  const exam = await examService.updateExam(req.userId!, req.params.id, data);
  res.json(exam);
}));

// Delete exam
router.delete('/:id', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  await examService.deleteExam(req.userId!, req.params.id);
  res.status(204).send();
}));

// Archive exam
router.post('/:id/archive', authenticate, asyncHandler(async (req: AuthRequest, res) => {
  const result = await examService.archiveExam(req.userId!, req.params.id);
  res.json(result);
}));

export default router;
