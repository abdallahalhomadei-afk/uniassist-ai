import { Request, Response, NextFunction } from 'express';
import { env } from '../config/env';

export class AppError extends Error {
  statusCode: number;
  isOperational: boolean;
  
  constructor(message: string, statusCode: number = 500) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

export class ValidationError extends AppError {
  constructor(message: string) {
    super(message, 400);
  }
}

export class NotFoundError extends AppError {
  constructor(resource: string = 'Resource') {
    super(`${resource} not found`, 404);
  }
}

export class UnauthorizedError extends AppError {
  constructor(message: string = 'Unauthorized') {
    super(message, 401);
  }
}

export class ForbiddenError extends AppError {
  constructor(message: string = 'Forbidden') {
    super(message, 403);
  }
}

export function errorHandler(
  err: Error | AppError,
  req: Request,
  res: Response,
  _next: NextFunction
): void {
  console.error('Error:', err);
  
  if (err instanceof AppError) {
    res.status(err.statusCode).json({
      error: err.message,
      ...(env.isDev && { stack: err.stack }),
    });
    return;
  }
  
  // Handle specific errors
  if (err.name === 'JsonWebTokenError') {
    res.status(401).json({ error: 'Invalid token' });
    return;
  }
  
  if (err.name === 'TokenExpiredError') {
    res.status(401).json({ error: 'Token expired' });
    return;
  }
  
  // PostgreSQL errors
  if ((err as any).code) {
    const pgError = err as any;
    switch (pgError.code) {
      case '23505': // Unique violation
        res.status(409).json({ error: 'Resource already exists' });
        return;
      case '23503': // Foreign key violation
        res.status(400).json({ error: 'Invalid reference' });
        return;
      case '22P02': // Invalid UUID
        res.status(400).json({ error: 'Invalid ID format' });
        return;
    }
  }
  
  // Default error
  res.status(500).json({
    error: env.isProd ? 'Internal server error' : err.message,
    ...(env.isDev && { stack: err.stack }),
  });
}

export function notFoundHandler(req: Request, res: Response): void {
  res.status(404).json({
    error: `Route ${req.method} ${req.path} not found`,
  });
}

export function asyncHandler(
  fn: (req: Request, res: Response, next: NextFunction) => Promise<any>
) {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}
