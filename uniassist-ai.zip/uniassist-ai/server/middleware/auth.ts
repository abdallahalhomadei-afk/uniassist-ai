import { Request, Response, NextFunction } from 'express';
import { verifyAccessToken } from '../utils/crypto';
import { query } from '../database/db';

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  university?: string;
  major?: string;
  language: string;
  timezone: string;
}

export interface AuthRequest extends Request {
  user?: AuthUser;
  userId?: string;
}

export async function authenticate(
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'No token provided' });
      return;
    }
    
    const token = authHeader.substring(7);
    const decoded = verifyAccessToken(token);
    
    if (!decoded || !decoded.userId) {
      res.status(401).json({ error: 'Invalid token' });
      return;
    }
    
    // Verify user exists and is active
    const result = await query(
      `SELECT id, email, name, university, major, language, timezone
       FROM users WHERE id = $1 AND is_active = true`,
      [decoded.userId]
    );
    
    if (result.rows.length === 0) {
      res.status(401).json({ error: 'User not found or inactive' });
      return;
    }
    
    req.user = result.rows[0];
    req.userId = decoded.userId;
    next();
  } catch (error) {
    console.error('Auth error:', error);
    res.status(401).json({ error: 'Authentication failed' });
  }
}

export async function optionalAuth(
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const authHeader = req.headers.authorization;
    
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      const decoded = verifyAccessToken(token);
      
      if (decoded && decoded.userId) {
        const result = await query(
          `SELECT id, email, name, university, major, language, timezone
           FROM users WHERE id = $1 AND is_active = true`,
          [decoded.userId]
        );
        
        if (result.rows.length > 0) {
          req.user = result.rows[0];
          req.userId = decoded.userId;
        }
      }
    }
    
    next();
  } catch {
    next();
  }
}
