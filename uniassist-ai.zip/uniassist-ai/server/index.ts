import express from 'express';
import cors from 'cors';
import cron from 'node-cron';
import { env } from './config/env';
import { checkConnection, closePool } from './database/db';
import { errorHandler, notFoundHandler } from './middleware/errorHandler';
import { initializeTelegramBot } from './services/telegramService';
import { processScheduledNotifications, createUpcomingReminders } from './services/notificationService';
import { checkAndUpdateOverdue } from './services/assignmentService';

// Routes
import authRoutes from './routes/auth';
import coursesRoutes from './routes/courses';
import assignmentsRoutes from './routes/assignments';
import examsRoutes from './routes/exams';
import gradesRoutes from './routes/grades';
import documentsRoutes from './routes/documents';
import audioRoutes from './routes/audio';
import chatRoutes from './routes/chat';
import notificationsRoutes from './routes/notifications';
import searchRoutes from './routes/search';
import archivesRoutes from './routes/archives';

const app = express();

// Middleware
app.use(cors({
  origin: env.CORS_ORIGIN === '*' ? true : env.CORS_ORIGIN.split(','),
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Request logging (development)
if (env.isDev) {
  app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
      console.log(`${req.method} ${req.path} ${res.statusCode} ${Date.now() - start}ms`);
    });
    next();
  });
}

// Health check
app.get('/health', async (req, res) => {
  const dbOk = await checkConnection();
  res.json({
    status: dbOk ? 'healthy' : 'unhealthy',
    timestamp: new Date().toISOString(),
    database: dbOk ? 'connected' : 'disconnected',
  });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/courses', coursesRoutes);
app.use('/api/assignments', assignmentsRoutes);
app.use('/api/exams', examsRoutes);
app.use('/api/grades', gradesRoutes);
app.use('/api/documents', documentsRoutes);
app.use('/api/audio', audioRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/notifications', notificationsRoutes);
app.use('/api/search', searchRoutes);
app.use('/api/archives', archivesRoutes);

// Error handling
app.use(notFoundHandler);
app.use(errorHandler);

// Initialize services
async function initialize() {
  // Check database connection
  const dbOk = await checkConnection();
  if (!dbOk) {
    console.error('❌ Database connection failed');
    process.exit(1);
  }
  console.log('✅ Database connected');

  // Initialize Telegram bot
  initializeTelegramBot();

  // Schedule cron jobs
  
  // Process scheduled notifications every minute
  cron.schedule('* * * * *', async () => {
    try {
      await processScheduledNotifications();
    } catch (e) {
      console.error('Scheduled notifications error:', e);
    }
  });

  // Check for upcoming reminders every 15 minutes
  cron.schedule('*/15 * * * *', async () => {
    try {
      await createUpcomingReminders();
    } catch (e) {
      console.error('Reminder creation error:', e);
    }
  });

  // Check for overdue assignments every hour
  cron.schedule('0 * * * *', async () => {
    try {
      await checkAndUpdateOverdue();
    } catch (e) {
      console.error('Overdue check error:', e);
    }
  });

  console.log('✅ Cron jobs scheduled');
}

// Start server
async function start() {
  await initialize();
  
  app.listen(env.PORT, env.HOST, () => {
    console.log(`\n🚀 UniAssist API Server running on http://${env.HOST}:${env.PORT}`);
    console.log(`   Environment: ${env.NODE_ENV}`);
    console.log(`   Database: ${env.DATABASE_URL.split('@')[1]?.split('/')[0] || 'configured'}`);
    console.log(`   Telegram: ${env.TELEGRAM_BOT_TOKEN ? 'enabled' : 'disabled'}\n`);
  });
}

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Shutting down gracefully...');
  await closePool();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Shutting down gracefully...');
  await closePool();
  process.exit(0);
});

start().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

export default app;
