import { query, transaction } from '../database/db';
import { NotFoundError } from '../middleware/errorHandler';

export interface CourseScheduleInput {
  day_of_week: number;
  start_time: string;
  end_time: string;
  room?: string;
  building?: string;
}

export interface CreateCourseData {
  name: string;
  code: string;
  instructor?: string;
  color?: string;
  credits?: number;
  semester?: string;
  year?: number;
  schedule?: CourseScheduleInput[];
}

export async function createCourse(userId: string, data: CreateCourseData) {
  return transaction(async (client) => {
    // Create course
    const result = await client.query(
      `INSERT INTO courses (user_id, name, code, instructor, color, credits, semester, year)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [
        userId,
        data.name,
        data.code,
        data.instructor || null,
        data.color || '#3b82f6',
        data.credits || 3,
        data.semester || null,
        data.year || null,
      ]
    );
    
    const course = result.rows[0];
    
    // Add schedules
    if (data.schedule && data.schedule.length > 0) {
      for (const sched of data.schedule) {
        await client.query(
          `INSERT INTO course_schedules (course_id, day_of_week, start_time, end_time, room, building)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [course.id, sched.day_of_week, sched.start_time, sched.end_time, sched.room, sched.building]
        );
      }
    }
    
    // Fetch complete course with schedules
    return getCourseById(userId, course.id);
  });
}

export async function getCourses(userId: string, options: {
  includeArchived?: boolean;
  semester?: string;
} = {}) {
  let whereClause = 'c.user_id = $1';
  const params: any[] = [userId];
  
  if (!options.includeArchived) {
    whereClause += ' AND c.is_archived = false';
  }
  
  if (options.semester) {
    params.push(options.semester);
    whereClause += ` AND c.semester = $${params.length}`;
  }
  
  const result = await query(
    `SELECT c.*,
            COALESCE(
              json_agg(
                json_build_object(
                  'id', cs.id,
                  'day_of_week', cs.day_of_week,
                  'start_time', cs.start_time::text,
                  'end_time', cs.end_time::text,
                  'room', cs.room,
                  'building', cs.building
                ) ORDER BY cs.day_of_week, cs.start_time
              ) FILTER (WHERE cs.id IS NOT NULL),
              '[]'
            ) as schedules
     FROM courses c
     LEFT JOIN course_schedules cs ON cs.course_id = c.id
     WHERE ${whereClause}
     GROUP BY c.id
     ORDER BY c.name`,
    params
  );
  
  return result.rows;
}

export async function getCourseById(userId: string, courseId: string) {
  const result = await query(
    `SELECT c.*,
            COALESCE(
              json_agg(
                json_build_object(
                  'id', cs.id,
                  'day_of_week', cs.day_of_week,
                  'start_time', cs.start_time::text,
                  'end_time', cs.end_time::text,
                  'room', cs.room,
                  'building', cs.building
                ) ORDER BY cs.day_of_week, cs.start_time
              ) FILTER (WHERE cs.id IS NOT NULL),
              '[]'
            ) as schedules
     FROM courses c
     LEFT JOIN course_schedules cs ON cs.course_id = c.id
     WHERE c.id = $1 AND c.user_id = $2
     GROUP BY c.id`,
    [courseId, userId]
  );
  
  if (result.rows.length === 0) {
    throw new NotFoundError('Course');
  }
  
  return result.rows[0];
}

export async function updateCourse(userId: string, courseId: string, data: Partial<CreateCourseData>) {
  return transaction(async (client) => {
    // Verify ownership
    const check = await client.query(
      'SELECT id FROM courses WHERE id = $1 AND user_id = $2',
      [courseId, userId]
    );
    
    if (check.rows.length === 0) {
      throw new NotFoundError('Course');
    }
    
    // Update course fields
    const fields: string[] = [];
    const values: any[] = [];
    let paramCount = 0;
    
    if (data.name !== undefined) {
      paramCount++;
      fields.push(`name = $${paramCount}`);
      values.push(data.name);
    }
    if (data.code !== undefined) {
      paramCount++;
      fields.push(`code = $${paramCount}`);
      values.push(data.code);
    }
    if (data.instructor !== undefined) {
      paramCount++;
      fields.push(`instructor = $${paramCount}`);
      values.push(data.instructor);
    }
    if (data.color !== undefined) {
      paramCount++;
      fields.push(`color = $${paramCount}`);
      values.push(data.color);
    }
    if (data.credits !== undefined) {
      paramCount++;
      fields.push(`credits = $${paramCount}`);
      values.push(data.credits);
    }
    if (data.semester !== undefined) {
      paramCount++;
      fields.push(`semester = $${paramCount}`);
      values.push(data.semester);
    }
    if (data.year !== undefined) {
      paramCount++;
      fields.push(`year = $${paramCount}`);
      values.push(data.year);
    }
    
    if (fields.length > 0) {
      paramCount++;
      values.push(courseId);
      await client.query(
        `UPDATE courses SET ${fields.join(', ')} WHERE id = $${paramCount}`,
        values
      );
    }
    
    // Update schedules if provided
    if (data.schedule !== undefined) {
      // Remove existing schedules
      await client.query('DELETE FROM course_schedules WHERE course_id = $1', [courseId]);
      
      // Add new schedules
      for (const sched of data.schedule) {
        await client.query(
          `INSERT INTO course_schedules (course_id, day_of_week, start_time, end_time, room, building)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [courseId, sched.day_of_week, sched.start_time, sched.end_time, sched.room, sched.building]
        );
      }
    }
    
    return getCourseById(userId, courseId);
  });
}

export async function deleteCourse(userId: string, courseId: string) {
  const result = await query(
    'DELETE FROM courses WHERE id = $1 AND user_id = $2 RETURNING id',
    [courseId, userId]
  );
  
  if (result.rows.length === 0) {
    throw new NotFoundError('Course');
  }
}

export async function archiveCourse(userId: string, courseId: string) {
  return transaction(async (client) => {
    // Get course data
    const courseResult = await client.query(
      'SELECT * FROM courses WHERE id = $1 AND user_id = $2',
      [courseId, userId]
    );
    
    if (courseResult.rows.length === 0) {
      throw new NotFoundError('Course');
    }
    
    const course = courseResult.rows[0];
    
    // Get schedules
    const schedulesResult = await client.query(
      'SELECT * FROM course_schedules WHERE course_id = $1',
      [courseId]
    );
    
    // Create archive entry
    await client.query(
      `INSERT INTO archives (user_id, entity_type, entity_id, entity_data)
       VALUES ($1, 'course', $2, $3)`,
      [userId, courseId, JSON.stringify({ ...course, schedules: schedulesResult.rows })]
    );
    
    // Mark as archived
    await client.query(
      'UPDATE courses SET is_archived = true, is_active = false WHERE id = $1',
      [courseId]
    );
    
    return { archived: true };
  });
}

export async function getTodaySchedule(userId: string) {
  const result = await query(
    `SELECT * FROM todays_schedule WHERE user_id = $1`,
    [userId]
  );
  return result.rows;
}
