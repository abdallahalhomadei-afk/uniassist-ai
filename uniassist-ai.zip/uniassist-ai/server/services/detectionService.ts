import OpenAI from 'openai';

export interface DetectedAssignment {
  title: string;
  description?: string;
  due_date?: string;
  course_hint?: string;
  confidence: number;
}

export interface DetectedExam {
  title: string;
  description?: string;
  exam_date?: string;
  start_time?: string;
  duration_minutes?: number;
  exam_type?: string;
  course_hint?: string;
  room?: string;
  confidence: number;
}

export interface DetectionResult {
  assignments: DetectedAssignment[];
  exams: DetectedExam[];
}

export async function detectAssignmentsAndExams(text: string, apiKey: string): Promise<DetectionResult> {
  const openai = new OpenAI({ apiKey });
  
  const prompt = `Analyze the following text and extract any assignments and exams mentioned.

For each assignment found, extract:
- title (required)
- description (if available)
- due_date (in ISO format YYYY-MM-DD if found)
- course_hint (course name/code if mentioned)
- confidence (0-1 how confident you are this is an assignment)

For each exam found, extract:
- title (required)
- description (if available)
- exam_date (in ISO format YYYY-MM-DD if found)
- start_time (in HH:MM format if found)
- duration_minutes (if found)
- exam_type (quiz, midterm, final, practical, oral, or other)
- course_hint (course name/code if mentioned)
- room (if mentioned)
- confidence (0-1 how confident you are this is an exam)

Return JSON in this exact format:
{
  "assignments": [...],
  "exams": [...]
}

If no assignments or exams are found, return empty arrays.

Text to analyze:
${text.substring(0, 6000)}`;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        {
          role: 'system',
          content: 'You are an academic content analyzer. Extract assignments and exams from academic documents, syllabi, announcements, and communications. Always respond with valid JSON.'
        },
        { role: 'user', content: prompt }
      ],
      max_tokens: 2000,
      temperature: 0.1,
    });
    
    const content = response.choices[0]?.message?.content || '{}';
    
    // Try to parse JSON from the response
    let parsed: DetectionResult;
    try {
      // Handle potential markdown code blocks
      const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)\s*```/) || [null, content];
      parsed = JSON.parse(jsonMatch[1] || content);
    } catch {
      // If JSON parsing fails, try to extract with regex
      parsed = { assignments: [], exams: [] };
    }
    
    // Validate and clean the results
    const assignments = (parsed.assignments || []).filter((a: any) => 
      a && typeof a.title === 'string' && a.title.length > 0
    ).map((a: any) => ({
      title: a.title,
      description: a.description || undefined,
      due_date: validateDate(a.due_date),
      course_hint: a.course_hint || undefined,
      confidence: typeof a.confidence === 'number' ? Math.min(1, Math.max(0, a.confidence)) : 0.5,
    }));
    
    const exams = (parsed.exams || []).filter((e: any) => 
      e && typeof e.title === 'string' && e.title.length > 0
    ).map((e: any) => ({
      title: e.title,
      description: e.description || undefined,
      exam_date: validateDate(e.exam_date),
      start_time: validateTime(e.start_time),
      duration_minutes: typeof e.duration_minutes === 'number' ? e.duration_minutes : undefined,
      exam_type: validateExamType(e.exam_type),
      course_hint: e.course_hint || undefined,
      room: e.room || undefined,
      confidence: typeof e.confidence === 'number' ? Math.min(1, Math.max(0, e.confidence)) : 0.5,
    }));
    
    return { assignments, exams };
    
  } catch (error) {
    console.error('Detection error:', error);
    return { assignments: [], exams: [] };
  }
}

function validateDate(dateStr: any): string | undefined {
  if (!dateStr || typeof dateStr !== 'string') return undefined;
  
  // Try to parse and validate the date
  const parsed = new Date(dateStr);
  if (isNaN(parsed.getTime())) return undefined;
  
  return parsed.toISOString().split('T')[0];
}

function validateTime(timeStr: any): string | undefined {
  if (!timeStr || typeof timeStr !== 'string') return undefined;
  
  // Check HH:MM format
  const match = timeStr.match(/^(\d{1,2}):(\d{2})$/);
  if (!match) return undefined;
  
  const hours = parseInt(match[1]);
  const minutes = parseInt(match[2]);
  
  if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) return undefined;
  
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
}

function validateExamType(type: any): string | undefined {
  const validTypes = ['quiz', 'midterm', 'final', 'practical', 'oral', 'other'];
  if (!type || typeof type !== 'string') return undefined;
  return validTypes.includes(type.toLowerCase()) ? type.toLowerCase() : 'other';
}

export async function detectFromAudio(transcription: string, apiKey: string): Promise<DetectionResult> {
  // Use the same detection logic for audio transcriptions
  return detectAssignmentsAndExams(transcription, apiKey);
}
