import { query } from '../database/db';
import { NotFoundError } from '../middleware/errorHandler';

const GRADE_POINTS: Record<string, number> = {
  'A+': 4.0, 'A': 4.0, 'A-': 3.7,
  'B+': 3.3, 'B': 3.0, 'B-': 2.7,
  'C+': 2.3, 'C': 2.0, 'C-': 1.7,
  'D+': 1.3, 'D': 1.0, 'D-': 0.7,
  'F': 0.0
};

export interface CreateGradeData {
  course_id?: string;
  course_name: string;
  course_code?: string;
  credits: number;
  grade: string;
  semester: string;
  year?: number;
}

export async function createGrade(userId: string, data: CreateGradeData) {
  const gradePoints = GRADE_POINTS[data.grade.toUpperCase()] ?? null;
  
  const result = await query(
    `INSERT INTO grades (user_id, course_id, course_name, course_code, credits, grade, grade_points, semester, year)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
     RETURNING *`,
    [
      userId,
      data.course_id || null,
      data.course_name,
      data.course_code || null,
      data.credits,
      data.grade.toUpperCase(),
      gradePoints,
      data.semester,
      data.year || null,
    ]
  );
  
  return result.rows[0];
}

export async function getGrades(userId: string, options: {
  semester?: string;
  includeArchived?: boolean;
} = {}) {
  let whereClause = 'g.user_id = $1';
  const params: any[] = [userId];
  
  if (!options.includeArchived) {
    whereClause += ' AND g.is_archived = false';
  }
  
  if (options.semester) {
    params.push(options.semester);
    whereClause += ` AND g.semester = $${params.length}`;
  }
  
  const result = await query(
    `SELECT g.*, c.color as course_color
     FROM grades g
     LEFT JOIN courses c ON c.id = g.course_id
     WHERE ${whereClause}
     ORDER BY g.year DESC NULLS LAST, g.semester DESC, g.course_name`,
    params
  );
  
  return result.rows;
}

export async function getGradeById(userId: string, gradeId: string) {
  const result = await query(
    `SELECT g.*, c.color as course_color
     FROM grades g
     LEFT JOIN courses c ON c.id = g.course_id
     WHERE g.id = $1 AND g.user_id = $2`,
    [gradeId, userId]
  );
  
  if (result.rows.length === 0) {
    throw new NotFoundError('Grade');
  }
  
  return result.rows[0];
}

export async function updateGrade(userId: string, gradeId: string, data: Partial<CreateGradeData>) {
  const fields: string[] = [];
  const values: any[] = [];
  let paramCount = 0;
  
  if (data.course_name !== undefined) {
    paramCount++;
    fields.push(`course_name = $${paramCount}`);
    values.push(data.course_name);
  }
  if (data.course_code !== undefined) {
    paramCount++;
    fields.push(`course_code = $${paramCount}`);
    values.push(data.course_code);
  }
  if (data.credits !== undefined) {
    paramCount++;
    fields.push(`credits = $${paramCount}`);
    values.push(data.credits);
  }
  if (data.grade !== undefined) {
    paramCount++;
    fields.push(`grade = $${paramCount}`);
    values.push(data.grade.toUpperCase());
    paramCount++;
    fields.push(`grade_points = $${paramCount}`);
    values.push(GRADE_POINTS[data.grade.toUpperCase()] ?? null);
  }
  if (data.semester !== undefined) {
    paramCount++;
    fields.push(`semester = $${paramCount}`);
    values.push(data.semester);
  }
  if (data.year !== undefined) {
    paramCount++;
    fields.push(`year = $${paramCount}`);
    values.push(data.year);
  }
  
  if (fields.length === 0) {
    return getGradeById(userId, gradeId);
  }
  
  paramCount++;
  values.push(gradeId);
  paramCount++;
  values.push(userId);
  
  const result = await query(
    `UPDATE grades SET ${fields.join(', ')}
     WHERE id = $${paramCount - 1} AND user_id = $${paramCount}
     RETURNING *`,
    values
  );
  
  if (result.rows.length === 0) {
    throw new NotFoundError('Grade');
  }
  
  return result.rows[0];
}

export async function deleteGrade(userId: string, gradeId: string) {
  const result = await query(
    'DELETE FROM grades WHERE id = $1 AND user_id = $2 RETURNING id',
    [gradeId, userId]
  );
  
  if (result.rows.length === 0) {
    throw new NotFoundError('Grade');
  }
}

export async function calculateGPA(userId: string) {
  // Cumulative GPA
  const cumulativeResult = await query(
    `SELECT 
       COALESCE(SUM(grade_points * credits) / NULLIF(SUM(credits), 0), 0) as cumulative_gpa,
       COALESCE(SUM(credits), 0) as total_credits,
       COUNT(*) as total_courses
     FROM grades
     WHERE user_id = $1 AND is_archived = false AND grade_points IS NOT NULL`,
    [userId]
  );
  
  // Per-semester GPA
  const semesterResult = await query(
    `SELECT 
       semester,
       year,
       SUM(grade_points * credits) / NULLIF(SUM(credits), 0) as semester_gpa,
       SUM(credits) as semester_credits,
       COUNT(*) as semester_courses
     FROM grades
     WHERE user_id = $1 AND is_archived = false AND grade_points IS NOT NULL
     GROUP BY semester, year
     ORDER BY year DESC NULLS LAST, semester DESC`,
    [userId]
  );
  
  return {
    cumulative: {
      gpa: parseFloat(cumulativeResult.rows[0].cumulative_gpa) || 0,
      total_credits: parseInt(cumulativeResult.rows[0].total_credits) || 0,
      total_courses: parseInt(cumulativeResult.rows[0].total_courses) || 0,
    },
    semesters: semesterResult.rows.map(row => ({
      semester: row.semester,
      year: row.year,
      gpa: parseFloat(row.semester_gpa) || 0,
      credits: parseInt(row.semester_credits) || 0,
      courses: parseInt(row.semester_courses) || 0,
    })),
  };
}

export async function getSemesters(userId: string) {
  const result = await query(
    `SELECT DISTINCT semester, year 
     FROM grades 
     WHERE user_id = $1 AND is_archived = false
     ORDER BY year DESC NULLS LAST, semester DESC`,
    [userId]
  );
  
  return result.rows;
}
