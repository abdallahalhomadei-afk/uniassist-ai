import { query } from '../database/db';

export interface SearchResult {
  entity_type: 'course' | 'assignment' | 'exam' | 'document' | 'grade' | 'chat';
  entity_id: string;
  title: string;
  description?: string;
  relevance: number;
  metadata?: Record<string, unknown>;
}

export interface SearchOptions {
  types?: string[];
  courseId?: string;
  dateFrom?: string;
  dateTo?: string;
  status?: string;
  limit?: number;
  offset?: number;
}

export async function search(userId: string, queryText: string, options: SearchOptions = {}): Promise<SearchResult[]> {
  const results: SearchResult[] = [];
  const limit = options.limit || 50;
  const types = options.types || ['course', 'assignment', 'exam', 'document'];
  const searchPattern = `%${queryText.toLowerCase()}%`;
  
  // Save search history
  try {
    await query(
      `INSERT INTO search_history (user_id, query, filters, results_count) VALUES ($1, $2, $3, 0)`,
      [userId, queryText, JSON.stringify(options)]
    );
  } catch (e) {
    // Ignore history save errors
  }
  
  // Search courses
  if (types.includes('course')) {
    try {
      const courseResults = await query(
        `SELECT id, name as title, code as description,
                CASE 
                  WHEN LOWER(name) = LOWER($2) THEN 1.0
                  WHEN LOWER(name) LIKE $3 THEN 0.8
                  WHEN LOWER(code) LIKE $3 THEN 0.7
                  ELSE 0.5
                END as relevance
         FROM courses
         WHERE user_id = $1 
           AND is_archived = false
           AND (LOWER(name) LIKE $3 OR LOWER(code) LIKE $3 OR LOWER(COALESCE(instructor, '')) LIKE $3)
         ORDER BY relevance DESC
         LIMIT 10`,
        [userId, queryText.toLowerCase(), searchPattern]
      );
      
      for (const row of courseResults.rows) {
        results.push({
          entity_type: 'course',
          entity_id: row.id,
          title: row.title,
          description: row.description,
          relevance: parseFloat(row.relevance) || 0.5,
        });
      }
    } catch (e) {
      console.error('Course search error:', e);
    }
  }
  
  // Search assignments
  if (types.includes('assignment')) {
    try {
      let assignmentQuery = `
        SELECT a.id, a.title, a.description, a.status, a.due_date, c.name as course_name,
               CASE 
                 WHEN LOWER(a.title) = LOWER($2) THEN 1.0
                 WHEN LOWER(a.title) LIKE $3 THEN 0.8
                 WHEN LOWER(COALESCE(a.description, '')) LIKE $3 THEN 0.6
                 ELSE 0.5
               END as relevance
        FROM assignments a
        LEFT JOIN courses c ON c.id = a.course_id
        WHERE a.user_id = $1 
          AND a.is_archived = false
          AND (LOWER(a.title) LIKE $3 OR LOWER(COALESCE(a.description, '')) LIKE $3)`;
      
      const params: (string | number)[] = [userId, queryText.toLowerCase(), searchPattern];
      
      if (options.courseId) {
        params.push(options.courseId);
        assignmentQuery += ` AND a.course_id = $${params.length}`;
      }
      
      if (options.status) {
        params.push(options.status);
        assignmentQuery += ` AND a.status = $${params.length}`;
      }
      
      assignmentQuery += ' ORDER BY relevance DESC LIMIT 15';
      
      const assignmentResults = await query(assignmentQuery, params);
      
      for (const row of assignmentResults.rows) {
        results.push({
          entity_type: 'assignment',
          entity_id: row.id,
          title: row.title,
          description: row.description,
          relevance: parseFloat(row.relevance) || 0.5,
          metadata: {
            status: row.status,
            due_date: row.due_date,
            course_name: row.course_name,
          },
        });
      }
    } catch (e) {
      console.error('Assignment search error:', e);
    }
  }
  
  // Search exams
  if (types.includes('exam')) {
    try {
      let examQuery = `
        SELECT e.id, e.title, e.description, e.exam_type, e.exam_date, c.name as course_name,
               CASE 
                 WHEN LOWER(e.title) = LOWER($2) THEN 1.0
                 WHEN LOWER(e.title) LIKE $3 THEN 0.8
                 WHEN LOWER(COALESCE(e.description, '')) LIKE $3 THEN 0.6
                 ELSE 0.5
               END as relevance
        FROM exams e
        LEFT JOIN courses c ON c.id = e.course_id
        WHERE e.user_id = $1 
          AND e.is_archived = false
          AND (LOWER(e.title) LIKE $3 OR LOWER(COALESCE(e.description, '')) LIKE $3)`;
      
      const params: (string | number)[] = [userId, queryText.toLowerCase(), searchPattern];
      
      if (options.courseId) {
        params.push(options.courseId);
        examQuery += ` AND e.course_id = $${params.length}`;
      }
      
      examQuery += ' ORDER BY relevance DESC LIMIT 15';
      
      const examResults = await query(examQuery, params);
      
      for (const row of examResults.rows) {
        results.push({
          entity_type: 'exam',
          entity_id: row.id,
          title: row.title,
          description: row.description,
          relevance: parseFloat(row.relevance) || 0.5,
          metadata: {
            exam_type: row.exam_type,
            exam_date: row.exam_date,
            course_name: row.course_name,
          },
        });
      }
    } catch (e) {
      console.error('Exam search error:', e);
    }
  }
  
  // Search documents
  if (types.includes('document')) {
    try {
      const docResults = await query(
        `SELECT d.id, d.original_filename as title, d.summary as description,
                CASE 
                  WHEN LOWER(d.original_filename) LIKE $3 THEN 0.9
                  WHEN LOWER(COALESCE(d.summary, '')) LIKE $3 THEN 0.7
                  WHEN LOWER(COALESCE(d.content_text, '')) LIKE $3 THEN 0.5
                  ELSE 0.4
                END as relevance
         FROM documents d
         WHERE d.user_id = $1 
           AND d.is_archived = false
           AND (
             LOWER(d.original_filename) LIKE $3 
             OR LOWER(COALESCE(d.content_text, '')) LIKE $3
             OR LOWER(COALESCE(d.summary, '')) LIKE $3
           )
         ORDER BY relevance DESC
         LIMIT 10`,
        [userId, queryText.toLowerCase(), searchPattern]
      );
      
      for (const row of docResults.rows) {
        results.push({
          entity_type: 'document',
          entity_id: row.id,
          title: row.title,
          description: row.description,
          relevance: parseFloat(row.relevance) || 0.5,
        });
      }
    } catch (e) {
      console.error('Document search error:', e);
    }
  }
  
  // Sort all results by relevance
  results.sort((a, b) => b.relevance - a.relevance);
  
  // Update search history with count
  try {
    await query(
      `UPDATE search_history SET results_count = $1 
       WHERE user_id = $2 AND query = $3 
       AND created_at = (SELECT MAX(created_at) FROM search_history WHERE user_id = $2 AND query = $3)`,
      [results.length, userId, queryText]
    );
  } catch (e) {
    // Ignore history update errors
  }
  
  return results.slice(0, limit);
}

export async function getSearchHistory(userId: string, limit: number = 10) {
  const result = await query(
    `SELECT query, results_count, created_at
     FROM search_history
     WHERE user_id = $1
     GROUP BY query, results_count, created_at
     ORDER BY created_at DESC
     LIMIT $2`,
    [userId, limit]
  );
  
  return result.rows;
}

export async function getSuggestions(userId: string, partial: string): Promise<string[]> {
  if (!partial || partial.length < 2) return [];
  
  const suggestions: string[] = [];
  const searchPattern = `%${partial.toLowerCase()}%`;
  
  try {
    // Course names
    const courseResult = await query(
      `SELECT DISTINCT name FROM courses WHERE user_id = $1 AND LOWER(name) LIKE $2 AND is_archived = false LIMIT 5`,
      [userId, searchPattern]
    );
    suggestions.push(...courseResult.rows.map(r => r.name));
    
    // Assignment titles
    const assignmentResult = await query(
      `SELECT DISTINCT title FROM assignments WHERE user_id = $1 AND LOWER(title) LIKE $2 AND is_archived = false LIMIT 5`,
      [userId, searchPattern]
    );
    suggestions.push(...assignmentResult.rows.map(r => r.title));
    
    // Recent searches
    const historyResult = await query(
      `SELECT DISTINCT query FROM search_history WHERE user_id = $1 AND LOWER(query) LIKE $2 ORDER BY created_at DESC LIMIT 5`,
      [userId, searchPattern]
    );
    suggestions.push(...historyResult.rows.map(r => r.query));
  } catch (e) {
    console.error('Suggestions error:', e);
  }
  
  // Remove duplicates and limit
  return [...new Set(suggestions)].slice(0, 10);
}

export async function clearSearchHistory(userId: string): Promise<void> {
  await query('DELETE FROM search_history WHERE user_id = $1', [userId]);
}
