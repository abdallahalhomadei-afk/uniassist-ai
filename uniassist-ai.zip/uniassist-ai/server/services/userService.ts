import { query, transaction } from '../database/db';
import { hashPassword, verifyPassword, generateAccessToken, generateRefreshToken, generateToken, hashToken, encrypt, decrypt } from '../utils/crypto';
import { ValidationError, NotFoundError, UnauthorizedError } from '../middleware/errorHandler';

export interface CreateUserData {
  email: string;
  password: string;
  name: string;
  university?: string;
  major?: string;
  language?: string;
}

export interface LoginData {
  email: string;
  password: string;
}

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  university?: string;
  major?: string;
  avatar_url?: string;
  language: string;
  theme: string;
  notifications_enabled: boolean;
  timezone: string;
  telegram_username?: string;
  has_api_key: boolean;
  created_at: string;
}

export async function createUser(data: CreateUserData) {
  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(data.email)) {
    throw new ValidationError('Invalid email format');
  }
  
  // Validate password strength
  if (data.password.length < 8) {
    throw new ValidationError('Password must be at least 8 characters');
  }
  
  // Check if email exists
  const existing = await query('SELECT id FROM users WHERE email = $1', [data.email.toLowerCase()]);
  if (existing.rows.length > 0) {
    throw new ValidationError('Email already registered');
  }
  
  const passwordHash = await hashPassword(data.password);
  const verificationToken = generateToken();
  
  const result = await query(
    `INSERT INTO users (email, password_hash, name, university, major, language, verification_token)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING id, email, name, university, major, language, theme, created_at`,
    [
      data.email.toLowerCase(),
      passwordHash,
      data.name,
      data.university || null,
      data.major || null,
      data.language || 'en',
      verificationToken,
    ]
  );
  
  const user = result.rows[0];
  const accessToken = generateAccessToken({ userId: user.id, email: user.email });
  const refreshToken = generateRefreshToken({ userId: user.id });
  
  // Store session
  await query(
    `INSERT INTO sessions (user_id, token_hash, expires_at)
     VALUES ($1, $2, NOW() + INTERVAL '30 days')`,
    [user.id, hashToken(refreshToken)]
  );
  
  return {
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      university: user.university,
      major: user.major,
      language: user.language,
      theme: user.theme,
    },
    accessToken,
    refreshToken,
  };
}

export async function loginUser(data: LoginData) {
  const result = await query(
    `SELECT id, email, password_hash, name, university, major, language, theme, is_active
     FROM users WHERE email = $1`,
    [data.email.toLowerCase()]
  );
  
  if (result.rows.length === 0) {
    throw new UnauthorizedError('Invalid email or password');
  }
  
  const user = result.rows[0];
  
  if (!user.is_active) {
    throw new UnauthorizedError('Account is deactivated');
  }
  
  const validPassword = await verifyPassword(data.password, user.password_hash);
  if (!validPassword) {
    throw new UnauthorizedError('Invalid email or password');
  }
  
  // Update last login
  await query('UPDATE users SET last_login_at = NOW() WHERE id = $1', [user.id]);
  
  const accessToken = generateAccessToken({ userId: user.id, email: user.email });
  const refreshToken = generateRefreshToken({ userId: user.id });
  
  // Store session
  await query(
    `INSERT INTO sessions (user_id, token_hash, expires_at)
     VALUES ($1, $2, NOW() + INTERVAL '30 days')`,
    [user.id, hashToken(refreshToken)]
  );
  
  return {
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      university: user.university,
      major: user.major,
      language: user.language,
      theme: user.theme,
    },
    accessToken,
    refreshToken,
  };
}

export async function refreshTokens(refreshToken: string) {
  const tokenHash = hashToken(refreshToken);
  
  const result = await query(
    `SELECT s.user_id, u.email, u.name, u.is_active
     FROM sessions s
     JOIN users u ON u.id = s.user_id
     WHERE s.token_hash = $1 AND s.is_active = true AND s.expires_at > NOW()`,
    [tokenHash]
  );
  
  if (result.rows.length === 0) {
    throw new UnauthorizedError('Invalid refresh token');
  }
  
  const session = result.rows[0];
  
  if (!session.is_active) {
    throw new UnauthorizedError('Account is deactivated');
  }
  
  // Invalidate old session
  await query('UPDATE sessions SET is_active = false WHERE token_hash = $1', [tokenHash]);
  
  // Create new tokens
  const newAccessToken = generateAccessToken({ userId: session.user_id, email: session.email });
  const newRefreshToken = generateRefreshToken({ userId: session.user_id });
  
  // Store new session
  await query(
    `INSERT INTO sessions (user_id, token_hash, expires_at)
     VALUES ($1, $2, NOW() + INTERVAL '30 days')`,
    [session.user_id, hashToken(newRefreshToken)]
  );
  
  return {
    accessToken: newAccessToken,
    refreshToken: newRefreshToken,
  };
}

export async function logout(userId: string, refreshToken?: string) {
  if (refreshToken) {
    const tokenHash = hashToken(refreshToken);
    await query('UPDATE sessions SET is_active = false WHERE user_id = $1 AND token_hash = $2', [userId, tokenHash]);
  } else {
    // Logout all sessions
    await query('UPDATE sessions SET is_active = false WHERE user_id = $1', [userId]);
  }
}

export async function getProfile(userId: string): Promise<UserProfile> {
  const result = await query(
    `SELECT id, email, name, university, major, avatar_url, language, theme,
            notifications_enabled, timezone, telegram_username, api_key_encrypted,
            created_at
     FROM users WHERE id = $1`,
    [userId]
  );
  
  if (result.rows.length === 0) {
    throw new NotFoundError('User');
  }
  
  const user = result.rows[0];
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    university: user.university,
    major: user.major,
    avatar_url: user.avatar_url,
    language: user.language,
    theme: user.theme,
    notifications_enabled: user.notifications_enabled,
    timezone: user.timezone,
    telegram_username: user.telegram_username,
    has_api_key: !!user.api_key_encrypted,
    created_at: user.created_at,
  };
}

export async function updateProfile(userId: string, data: Partial<{
  name: string;
  university: string;
  major: string;
  language: string;
  theme: string;
  notifications_enabled: boolean;
  timezone: string;
}>) {
  const fields: string[] = [];
  const values: any[] = [];
  let paramCount = 0;
  
  if (data.name !== undefined) {
    paramCount++;
    fields.push(`name = $${paramCount}`);
    values.push(data.name);
  }
  if (data.university !== undefined) {
    paramCount++;
    fields.push(`university = $${paramCount}`);
    values.push(data.university);
  }
  if (data.major !== undefined) {
    paramCount++;
    fields.push(`major = $${paramCount}`);
    values.push(data.major);
  }
  if (data.language !== undefined) {
    paramCount++;
    fields.push(`language = $${paramCount}`);
    values.push(data.language);
  }
  if (data.theme !== undefined) {
    paramCount++;
    fields.push(`theme = $${paramCount}`);
    values.push(data.theme);
  }
  if (data.notifications_enabled !== undefined) {
    paramCount++;
    fields.push(`notifications_enabled = $${paramCount}`);
    values.push(data.notifications_enabled);
  }
  if (data.timezone !== undefined) {
    paramCount++;
    fields.push(`timezone = $${paramCount}`);
    values.push(data.timezone);
  }
  
  if (fields.length === 0) {
    return getProfile(userId);
  }
  
  paramCount++;
  values.push(userId);
  
  await query(
    `UPDATE users SET ${fields.join(', ')} WHERE id = $${paramCount}`,
    values
  );
  
  return getProfile(userId);
}

export async function setApiKey(userId: string, apiKey: string) {
  const encrypted = encrypt(apiKey);
  await query('UPDATE users SET api_key_encrypted = $1 WHERE id = $2', [encrypted, userId]);
}

export async function getApiKey(userId: string): Promise<string | null> {
  const result = await query('SELECT api_key_encrypted FROM users WHERE id = $1', [userId]);
  if (result.rows.length === 0 || !result.rows[0].api_key_encrypted) {
    return null;
  }
  return decrypt(result.rows[0].api_key_encrypted);
}

export async function changePassword(userId: string, currentPassword: string, newPassword: string) {
  const result = await query('SELECT password_hash FROM users WHERE id = $1', [userId]);
  
  if (result.rows.length === 0) {
    throw new NotFoundError('User');
  }
  
  const valid = await verifyPassword(currentPassword, result.rows[0].password_hash);
  if (!valid) {
    throw new ValidationError('Current password is incorrect');
  }
  
  if (newPassword.length < 8) {
    throw new ValidationError('New password must be at least 8 characters');
  }
  
  const newHash = await hashPassword(newPassword);
  await query('UPDATE users SET password_hash = $1 WHERE id = $2', [newHash, userId]);
  
  // Invalidate all sessions except current
  await query('UPDATE sessions SET is_active = false WHERE user_id = $1', [userId]);
}

export async function getDashboardSummary(userId: string) {
  const result = await query(
    `SELECT * FROM dashboard_summary WHERE user_id = $1`,
    [userId]
  );
  
  if (result.rows.length === 0) {
    return {
      active_courses: 0,
      pending_assignments: 0,
      overdue_assignments: 0,
      upcoming_exams: 0,
      cumulative_gpa: null,
      total_credits: 0,
      unread_notifications: 0,
    };
  }
  
  return result.rows[0];
}
