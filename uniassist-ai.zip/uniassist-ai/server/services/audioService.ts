import { query } from '../database/db';
import { NotFoundError } from '../middleware/errorHandler';
import { env } from '../config/env';
import fs from 'fs/promises';
import path from 'path';
import { v4 as uuid } from 'uuid';
import OpenAI from 'openai';
import { getApiKey } from './userService';
import { detectFromAudio } from './detectionService';

export interface AudioFile {
  originalname: string;
  mimetype: string;
  size: number;
  buffer: Buffer;
}

export async function uploadAndTranscribe(userId: string, file: AudioFile) {
  const apiKey = await getApiKey(userId);
  if (!apiKey) {
    throw new Error('OpenAI API key not configured. Please add your API key in settings.');
  }
  
  const fileId = uuid();
  const ext = path.extname(file.originalname) || '.mp3';
  const filename = `${fileId}${ext}`;
  const storagePath = path.join(env.STORAGE_PATH, 'audio', userId, filename);
  
  // Ensure directory exists
  await fs.mkdir(path.dirname(storagePath), { recursive: true });
  
  // Save file
  await fs.writeFile(storagePath, file.buffer);
  
  // Create database record
  const result = await query(
    `INSERT INTO audio_transcriptions (user_id, filename, original_filename, file_size, storage_path, processing_status)
     VALUES ($1, $2, $3, $4, $5, 'processing')
     RETURNING *`,
    [userId, filename, file.originalname, file.size, storagePath]
  );
  
  const transcription = result.rows[0];
  
  // Process transcription asynchronously
  processTranscription(userId, transcription.id, apiKey).catch(console.error);
  
  return transcription;
}

async function processTranscription(userId: string, transcriptionId: string, apiKey: string) {
  try {
    const openai = new OpenAI({ apiKey });
    
    // Get transcription record
    const recordResult = await query(
      'SELECT * FROM audio_transcriptions WHERE id = $1',
      [transcriptionId]
    );
    
    if (recordResult.rows.length === 0) return;
    
    const record = recordResult.rows[0];
    
    // Read audio file
    const audioBuffer = await fs.readFile(record.storage_path);
    
    // Create a File object for OpenAI
    const audioFile = new File([audioBuffer], record.original_filename, {
      type: 'audio/mpeg',
    });
    
    // Transcribe with Whisper
    const whisperResponse = await openai.audio.transcriptions.create({
      file: audioFile,
      model: 'whisper-1',
      response_format: 'json',
    });
    
    const transcriptionText = whisperResponse.text;
    
    // Detect language
    const languageResponse = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: 'What language is this text in? Reply with only the ISO 639-1 code (e.g., "en", "ar", "es").' },
        { role: 'user', content: transcriptionText.substring(0, 500) }
      ],
      max_tokens: 10,
    });
    
    const language = languageResponse.choices[0]?.message?.content?.trim().toLowerCase().substring(0, 2) || 'en';
    
    // Detect assignments and exams
    let detectedAssignments: any[] = [];
    let detectedExams: any[] = [];
    
    try {
      const detections = await detectFromAudio(transcriptionText, apiKey);
      detectedAssignments = detections.assignments;
      detectedExams = detections.exams;
    } catch (e) {
      console.error('Detection from audio failed:', e);
    }
    
    // Update record
    await query(
      `UPDATE audio_transcriptions SET 
         transcription_text = $1,
         language = $2,
         detected_assignments = $3,
         detected_exams = $4,
         processing_status = 'completed'
       WHERE id = $5`,
      [transcriptionText, language, JSON.stringify(detectedAssignments), JSON.stringify(detectedExams), transcriptionId]
    );
    
  } catch (error) {
    console.error('Transcription error:', error);
    await query(
      `UPDATE audio_transcriptions SET processing_status = 'failed', processing_error = $1 WHERE id = $2`,
      [(error as Error).message, transcriptionId]
    );
  }
}

export async function getTranscriptions(userId: string) {
  const result = await query(
    `SELECT * FROM audio_transcriptions WHERE user_id = $1 ORDER BY created_at DESC`,
    [userId]
  );
  return result.rows;
}

export async function getTranscriptionById(userId: string, transcriptionId: string) {
  const result = await query(
    `SELECT * FROM audio_transcriptions WHERE id = $1 AND user_id = $2`,
    [transcriptionId, userId]
  );
  
  if (result.rows.length === 0) {
    throw new NotFoundError('Transcription');
  }
  
  return result.rows[0];
}

export async function deleteTranscription(userId: string, transcriptionId: string) {
  const record = await getTranscriptionById(userId, transcriptionId);
  
  // Delete file
  try {
    await fs.unlink(record.storage_path);
  } catch (e) {
    console.error('Error deleting audio file:', e);
  }
  
  await query('DELETE FROM audio_transcriptions WHERE id = $1', [transcriptionId]);
}
