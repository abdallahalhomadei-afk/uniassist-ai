import { query } from '../database/db';
import OpenAI from 'openai';
import { getApiKey, getProfile } from './userService';
import { getCourses } from './courseService';
import { getAssignments } from './assignmentService';
import { getUpcomingExams } from './examService';

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export async function sendMessage(userId: string, message: string) {
  const apiKey = await getApiKey(userId);
  if (!apiKey) {
    throw new Error('Please configure your OpenAI API key in settings to use the AI chat.');
  }
  
  // Save user message
  await query(
    `INSERT INTO chat_messages (user_id, role, content) VALUES ($1, 'user', $2)`,
    [userId, message]
  );
  
  // Get context
  const [profile, courses, assignments, exams, recentMessages] = await Promise.all([
    getProfile(userId),
    getCourses(userId),
    getAssignments(userId, { upcoming: true }),
    getUpcomingExams(userId, 14),
    getRecentMessages(userId, 10),
  ]);
  
  // Build system prompt with context
  const systemPrompt = buildSystemPrompt(profile, courses, assignments, exams);
  
  const openai = new OpenAI({ apiKey });
  
  const messages: OpenAI.ChatCompletionMessageParam[] = [
    { role: 'system', content: systemPrompt },
    ...recentMessages.map(m => ({
      role: m.role as 'user' | 'assistant',
      content: m.content,
    })),
    { role: 'user', content: message },
  ];
  
  const response = await openai.chat.completions.create({
    model: 'gpt-3.5-turbo',
    messages,
    max_tokens: 1500,
    temperature: 0.7,
  });
  
  const assistantMessage = response.choices[0]?.message?.content || 'I could not generate a response.';
  const tokensUsed = response.usage?.total_tokens || 0;
  
  // Save assistant message
  await query(
    `INSERT INTO chat_messages (user_id, role, content, tokens_used, model) 
     VALUES ($1, 'assistant', $2, $3, $4)`,
    [userId, assistantMessage, tokensUsed, 'gpt-3.5-turbo']
  );
  
  return {
    message: assistantMessage,
    tokens_used: tokensUsed,
  };
}

function buildSystemPrompt(profile: any, courses: any[], assignments: any[], exams: any[]): string {
  const courseList = courses.map(c => `${c.name} (${c.code})`).join(', ') || 'None';
  const assignmentList = assignments.slice(0, 5).map(a => 
    `"${a.title}" for ${a.course_name || 'N/A'} - due ${a.due_date}`
  ).join('; ') || 'None';
  const examList = exams.slice(0, 5).map(e => 
    `"${e.title}" (${e.exam_type}) - ${e.exam_date}`
  ).join('; ') || 'None';
  
  return `You are UniAssist AI, a helpful and knowledgeable university assistant. You help students with:
- Understanding course material and concepts
- Assignment help and writing tips
- Exam preparation strategies
- Time management and study planning
- Academic questions in any subject

Current Student Context:
- Name: ${profile.name}
- University: ${profile.university || 'Not specified'}
- Major: ${profile.major || 'Not specified'}
- Language preference: ${profile.language === 'ar' ? 'Arabic' : 'English'}

Current Courses: ${courseList}

Upcoming Assignments: ${assignmentList}

Upcoming Exams: ${examList}

Guidelines:
1. Be encouraging, supportive, and patient
2. Provide clear, structured explanations
3. If the student writes in Arabic, respond in Arabic
4. Reference their specific courses and deadlines when relevant
5. Offer practical study tips and strategies
6. If you don't know something, admit it and suggest resources
7. Keep responses focused and actionable`;
}

export async function getRecentMessages(userId: string, limit: number = 20) {
  const result = await query(
    `SELECT role, content, created_at 
     FROM chat_messages 
     WHERE user_id = $1 AND is_archived = false
     ORDER BY created_at DESC
     LIMIT $2`,
    [userId, limit]
  );
  
  return result.rows.reverse();
}

export async function getChatHistory(userId: string, options: {
  limit?: number;
  offset?: number;
  before?: string;
} = {}) {
  let whereClause = 'user_id = $1 AND is_archived = false';
  const params: any[] = [userId];
  
  if (options.before) {
    params.push(options.before);
    whereClause += ` AND created_at < $${params.length}`;
  }
  
  const limit = options.limit || 50;
  const offset = options.offset || 0;
  
  const result = await query(
    `SELECT id, role, content, created_at, tokens_used 
     FROM chat_messages 
     WHERE ${whereClause}
     ORDER BY created_at DESC
     LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
    [...params, limit, offset]
  );
  
  return result.rows.reverse();
}

export async function clearChatHistory(userId: string) {
  await query(
    `UPDATE chat_messages SET is_archived = true WHERE user_id = $1`,
    [userId]
  );
}

export async function deleteChatMessage(userId: string, messageId: string) {
  await query(
    `DELETE FROM chat_messages WHERE id = $1 AND user_id = $2`,
    [messageId, userId]
  );
}
