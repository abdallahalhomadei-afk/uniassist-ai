import { query } from '../database/db';
import { NotFoundError } from '../middleware/errorHandler';
import { env } from '../config/env';
import fs from 'fs/promises';
import path from 'path';
import { v4 as uuid } from 'uuid';
import OpenAI from 'openai';
import { getApiKey } from './userService';
import { detectAssignmentsAndExams } from './detectionService';

export interface UploadedFile {
  originalname: string;
  mimetype: string;
  size: number;
  buffer: Buffer;
}

export async function uploadDocument(userId: string, file: UploadedFile, courseId?: string) {
  const fileId = uuid();
  const ext = path.extname(file.originalname);
  const filename = `${fileId}${ext}`;
  const storagePath = path.join(env.STORAGE_PATH, 'documents', userId, filename);
  
  // Ensure directory exists
  await fs.mkdir(path.dirname(storagePath), { recursive: true });
  
  // Save file
  await fs.writeFile(storagePath, file.buffer);
  
  // Create database record
  const result = await query(
    `INSERT INTO documents (user_id, course_id, filename, original_filename, mime_type, file_size, storage_path, storage_type)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
     RETURNING *`,
    [userId, courseId || null, filename, file.originalname, file.mimetype, file.size, storagePath, 'local']
  );
  
  const document = result.rows[0];
  
  // Process document asynchronously
  processDocument(userId, document.id).catch(console.error);
  
  return document;
}

export async function processDocument(userId: string, documentId: string) {
  try {
    // Update status to processing
    await query(
      `UPDATE documents SET processing_status = 'processing' WHERE id = $1`,
      [documentId]
    );
    
    // Get document
    const docResult = await query('SELECT * FROM documents WHERE id = $1', [documentId]);
    if (docResult.rows.length === 0) return;
    
    const doc = docResult.rows[0];
    
    // Extract text content
    let contentText = '';
    
    if (doc.mime_type === 'application/pdf') {
      const pdfParse = (await import('pdf-parse')).default;
      const buffer = await fs.readFile(doc.storage_path);
      const pdf = await pdfParse(buffer);
      contentText = pdf.text;
    } else if (doc.mime_type.startsWith('text/')) {
      contentText = await fs.readFile(doc.storage_path, 'utf-8');
    }
    
    // Store extracted text
    await query(
      `UPDATE documents SET content_text = $1 WHERE id = $2`,
      [contentText.substring(0, 50000), documentId]
    );
    
    // Get user's API key for AI processing
    const apiKey = await getApiKey(userId);
    
    let summary = null;
    let detectedAssignments: any[] = [];
    let detectedExams: any[] = [];
    
    if (apiKey && contentText) {
      try {
        const openai = new OpenAI({ apiKey });
        
        // Generate summary
        const summaryResponse = await openai.chat.completions.create({
          model: 'gpt-3.5-turbo',
          messages: [
            {
              role: 'system',
              content: 'Summarize the following academic document in 2-3 paragraphs. Focus on key topics, concepts, and any deadlines mentioned.'
            },
            { role: 'user', content: contentText.substring(0, 8000) }
          ],
          max_tokens: 500,
        });
        
        summary = summaryResponse.choices[0]?.message?.content;
        
        // Detect assignments and exams
        const detections = await detectAssignmentsAndExams(contentText, apiKey);
        detectedAssignments = detections.assignments;
        detectedExams = detections.exams;
        
      } catch (aiError) {
        console.error('AI processing error:', aiError);
      }
    }
    
    // Update document with results
    await query(
      `UPDATE documents SET 
         summary = $1,
         detected_assignments = $2,
         detected_exams = $3,
         processing_status = 'completed'
       WHERE id = $4`,
      [summary, JSON.stringify(detectedAssignments), JSON.stringify(detectedExams), documentId]
    );
    
  } catch (error) {
    console.error('Document processing error:', error);
    await query(
      `UPDATE documents SET processing_status = 'failed', processing_error = $1 WHERE id = $2`,
      [(error as Error).message, documentId]
    );
  }
}

export async function getDocuments(userId: string, options: {
  courseId?: string;
  includeArchived?: boolean;
} = {}) {
  let whereClause = 'd.user_id = $1';
  const params: any[] = [userId];
  
  if (!options.includeArchived) {
    whereClause += ' AND d.is_archived = false';
  }
  
  if (options.courseId) {
    params.push(options.courseId);
    whereClause += ` AND d.course_id = $${params.length}`;
  }
  
  const result = await query(
    `SELECT d.*, c.name as course_name
     FROM documents d
     LEFT JOIN courses c ON c.id = d.course_id
     WHERE ${whereClause}
     ORDER BY d.created_at DESC`,
    params
  );
  
  return result.rows;
}

export async function getDocumentById(userId: string, documentId: string) {
  const result = await query(
    `SELECT d.*, c.name as course_name
     FROM documents d
     LEFT JOIN courses c ON c.id = d.course_id
     WHERE d.id = $1 AND d.user_id = $2`,
    [documentId, userId]
  );
  
  if (result.rows.length === 0) {
    throw new NotFoundError('Document');
  }
  
  return result.rows[0];
}

export async function deleteDocument(userId: string, documentId: string) {
  const doc = await getDocumentById(userId, documentId);
  
  // Delete file
  try {
    await fs.unlink(doc.storage_path);
  } catch (e) {
    console.error('Error deleting file:', e);
  }
  
  // Delete database record
  await query('DELETE FROM documents WHERE id = $1', [documentId]);
}

export async function askAboutDocument(userId: string, documentId: string, question: string) {
  const doc = await getDocumentById(userId, documentId);
  
  if (!doc.content_text) {
    throw new NotFoundError('Document content not available');
  }
  
  const apiKey = await getApiKey(userId);
  if (!apiKey) {
    throw new NotFoundError('API key not configured');
  }
  
  const openai = new OpenAI({ apiKey });
  
  const response = await openai.chat.completions.create({
    model: 'gpt-3.5-turbo',
    messages: [
      {
        role: 'system',
        content: `Answer questions about this document. Be helpful and accurate. Document content:\n\n${doc.content_text.substring(0, 8000)}`
      },
      { role: 'user', content: question }
    ],
    max_tokens: 1000,
  });
  
  return response.choices[0]?.message?.content || 'Unable to generate answer';
}

export async function getDocumentContent(userId: string, documentId: string) {
  const doc = await getDocumentById(userId, documentId);
  const buffer = await fs.readFile(doc.storage_path);
  return { buffer, mimeType: doc.mime_type, filename: doc.original_filename };
}
