import { query, transaction } from '../database/db';
import { NotFoundError } from '../middleware/errorHandler';

export interface CreateExamData {
  course_id?: string;
  title: string;
  description?: string;
  exam_date: string;
  start_time: string;
  end_time?: string;
  duration_minutes?: number;
  room?: string;
  building?: string;
  exam_type?: 'quiz' | 'midterm' | 'final' | 'practical' | 'oral' | 'other';
  weight?: number;
  topics?: string[];
  materials_allowed?: string;
  notes?: string;
  source?: 'manual' | 'detected' | 'telegram' | 'document';
}

export async function createExam(userId: string, data: CreateExamData) {
  const result = await query(
    `INSERT INTO exams (
      user_id, course_id, title, description, exam_date, start_time, end_time,
      duration_minutes, room, building, exam_type, weight, topics, materials_allowed, notes, source
    )
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
     RETURNING *`,
    [
      userId,
      data.course_id || null,
      data.title,
      data.description || null,
      data.exam_date,
      data.start_time,
      data.end_time || null,
      data.duration_minutes || null,
      data.room || null,
      data.building || null,
      data.exam_type || 'midterm',
      data.weight || null,
      data.topics || null,
      data.materials_allowed || null,
      data.notes || null,
      data.source || 'manual',
    ]
  );
  
  return getExamById(userId, result.rows[0].id);
}

export async function getExams(userId: string, options: {
  courseId?: string;
  examType?: string;
  includeArchived?: boolean;
  upcoming?: boolean;
  past?: boolean;
} = {}) {
  let whereClause = 'e.user_id = $1';
  const params: any[] = [userId];
  
  if (!options.includeArchived) {
    whereClause += ' AND e.is_archived = false';
  }
  
  if (options.courseId) {
    params.push(options.courseId);
    whereClause += ` AND e.course_id = $${params.length}`;
  }
  
  if (options.examType) {
    params.push(options.examType);
    whereClause += ` AND e.exam_type = $${params.length}`;
  }
  
  if (options.upcoming) {
    whereClause += ' AND e.exam_date >= CURRENT_DATE';
  }
  
  if (options.past) {
    whereClause += ' AND e.exam_date < CURRENT_DATE';
  }
  
  const result = await query(
    `SELECT e.*, c.name as course_name, c.code as course_code, c.color as course_color,
            e.exam_date - CURRENT_DATE as days_until
     FROM exams e
     LEFT JOIN courses c ON c.id = e.course_id
     WHERE ${whereClause}
     ORDER BY e.exam_date ASC, e.start_time ASC`,
    params
  );
  
  return result.rows;
}

export async function getExamById(userId: string, examId: string) {
  const result = await query(
    `SELECT e.*, c.name as course_name, c.code as course_code, c.color as course_color,
            e.exam_date - CURRENT_DATE as days_until
     FROM exams e
     LEFT JOIN courses c ON c.id = e.course_id
     WHERE e.id = $1 AND e.user_id = $2`,
    [examId, userId]
  );
  
  if (result.rows.length === 0) {
    throw new NotFoundError('Exam');
  }
  
  return result.rows[0];
}

export async function updateExam(userId: string, examId: string, data: Partial<CreateExamData & {
  grade?: number;
  max_grade?: number;
}>) {
  const fields: string[] = [];
  const values: any[] = [];
  let paramCount = 0;
  
  const allowedFields = [
    'course_id', 'title', 'description', 'exam_date', 'start_time', 'end_time',
    'duration_minutes', 'room', 'building', 'exam_type', 'weight', 'topics',
    'materials_allowed', 'notes', 'grade', 'max_grade'
  ];
  
  for (const field of allowedFields) {
    if ((data as any)[field] !== undefined) {
      paramCount++;
      fields.push(`${field} = $${paramCount}`);
      values.push((data as any)[field]);
    }
  }
  
  if (fields.length === 0) {
    return getExamById(userId, examId);
  }
  
  paramCount++;
  values.push(examId);
  paramCount++;
  values.push(userId);
  
  const result = await query(
    `UPDATE exams SET ${fields.join(', ')}
     WHERE id = $${paramCount - 1} AND user_id = $${paramCount}
     RETURNING *`,
    values
  );
  
  if (result.rows.length === 0) {
    throw new NotFoundError('Exam');
  }
  
  return getExamById(userId, examId);
}

export async function deleteExam(userId: string, examId: string) {
  const result = await query(
    'DELETE FROM exams WHERE id = $1 AND user_id = $2 RETURNING id',
    [examId, userId]
  );
  
  if (result.rows.length === 0) {
    throw new NotFoundError('Exam');
  }
}

export async function archiveExam(userId: string, examId: string) {
  return transaction(async (client) => {
    const result = await client.query(
      'SELECT * FROM exams WHERE id = $1 AND user_id = $2',
      [examId, userId]
    );
    
    if (result.rows.length === 0) {
      throw new NotFoundError('Exam');
    }
    
    await client.query(
      `INSERT INTO archives (user_id, entity_type, entity_id, entity_data)
       VALUES ($1, 'exam', $2, $3)`,
      [userId, examId, JSON.stringify(result.rows[0])]
    );
    
    await client.query(
      'UPDATE exams SET is_archived = true WHERE id = $1',
      [examId]
    );
    
    return { archived: true };
  });
}

export async function getUpcomingExams(userId: string, days: number = 14) {
  const result = await query(
    `SELECT e.*, c.name as course_name, c.color as course_color,
            e.exam_date - CURRENT_DATE as days_until
     FROM exams e
     LEFT JOIN courses c ON c.id = e.course_id
     WHERE e.user_id = $1 
       AND e.is_archived = false
       AND e.exam_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '${days} days'
     ORDER BY e.exam_date ASC, e.start_time ASC
     LIMIT 10`,
    [userId]
  );
  
  return result.rows;
}
