import { query, transaction } from '../database/db';
import { NotFoundError } from '../middleware/errorHandler';

export type ArchiveEntityType = 'course' | 'assignment' | 'exam' | 'document' | 'grade' | 'chat';

export async function getArchives(userId: string, options: {
  entityType?: ArchiveEntityType;
  limit?: number;
  offset?: number;
} = {}) {
  let whereClause = 'user_id = $1';
  const params: any[] = [userId];
  
  if (options.entityType) {
    params.push(options.entityType);
    whereClause += ` AND entity_type = $${params.length}`;
  }
  
  const limit = options.limit || 50;
  const offset = options.offset || 0;
  
  const result = await query(
    `SELECT * FROM archives 
     WHERE ${whereClause}
     ORDER BY archived_at DESC
     LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
    [...params, limit, offset]
  );
  
  return result.rows;
}

export async function getArchiveById(userId: string, archiveId: string) {
  const result = await query(
    `SELECT * FROM archives WHERE id = $1 AND user_id = $2`,
    [archiveId, userId]
  );
  
  if (result.rows.length === 0) {
    throw new NotFoundError('Archive');
  }
  
  return result.rows[0];
}

export async function restoreFromArchive(userId: string, archiveId: string) {
  return transaction(async (client) => {
    // Get archive
    const archiveResult = await client.query(
      'SELECT * FROM archives WHERE id = $1 AND user_id = $2',
      [archiveId, userId]
    );
    
    if (archiveResult.rows.length === 0) {
      throw new NotFoundError('Archive');
    }
    
    const archive = archiveResult.rows[0];
    const entityData = archive.entity_data;
    
    // Restore based on entity type
    switch (archive.entity_type) {
      case 'course':
        await client.query(
          `UPDATE courses SET is_archived = false, is_active = true WHERE id = $1`,
          [archive.entity_id]
        );
        break;
        
      case 'assignment':
        await client.query(
          `UPDATE assignments SET is_archived = false WHERE id = $1`,
          [archive.entity_id]
        );
        break;
        
      case 'exam':
        await client.query(
          `UPDATE exams SET is_archived = false WHERE id = $1`,
          [archive.entity_id]
        );
        break;
        
      case 'document':
        await client.query(
          `UPDATE documents SET is_archived = false WHERE id = $1`,
          [archive.entity_id]
        );
        break;
        
      case 'grade':
        await client.query(
          `UPDATE grades SET is_archived = false WHERE id = $1`,
          [archive.entity_id]
        );
        break;
        
      case 'chat':
        await client.query(
          `UPDATE chat_messages SET is_archived = false WHERE id = $1`,
          [archive.entity_id]
        );
        break;
    }
    
    // Delete archive entry
    await client.query('DELETE FROM archives WHERE id = $1', [archiveId]);
    
    return { restored: true, entity_type: archive.entity_type, entity_id: archive.entity_id };
  });
}

export async function permanentlyDelete(userId: string, archiveId: string) {
  return transaction(async (client) => {
    // Get archive
    const archiveResult = await client.query(
      'SELECT * FROM archives WHERE id = $1 AND user_id = $2',
      [archiveId, userId]
    );
    
    if (archiveResult.rows.length === 0) {
      throw new NotFoundError('Archive');
    }
    
    const archive = archiveResult.rows[0];
    
    // Delete the actual entity
    switch (archive.entity_type) {
      case 'course':
        await client.query('DELETE FROM courses WHERE id = $1', [archive.entity_id]);
        break;
      case 'assignment':
        await client.query('DELETE FROM assignments WHERE id = $1', [archive.entity_id]);
        break;
      case 'exam':
        await client.query('DELETE FROM exams WHERE id = $1', [archive.entity_id]);
        break;
      case 'document':
        await client.query('DELETE FROM documents WHERE id = $1', [archive.entity_id]);
        break;
      case 'grade':
        await client.query('DELETE FROM grades WHERE id = $1', [archive.entity_id]);
        break;
      case 'chat':
        await client.query('DELETE FROM chat_messages WHERE id = $1', [archive.entity_id]);
        break;
    }
    
    // Delete archive entry
    await client.query('DELETE FROM archives WHERE id = $1', [archiveId]);
    
    return { deleted: true };
  });
}

export async function cleanupOldArchives(days: number = 90) {
  // Delete archives older than specified days
  const result = await query(
    `DELETE FROM archives 
     WHERE archived_at < NOW() - INTERVAL '${days} days'
     AND (restore_until IS NULL OR restore_until < NOW())
     RETURNING id, entity_type, entity_id`
  );
  
  return {
    deleted_count: result.rowCount,
    deleted_items: result.rows,
  };
}

export async function getArchiveStats(userId: string) {
  const result = await query(
    `SELECT 
       entity_type,
       COUNT(*) as count,
       MIN(archived_at) as oldest,
       MAX(archived_at) as newest
     FROM archives
     WHERE user_id = $1
     GROUP BY entity_type`,
    [userId]
  );
  
  const total = await query(
    'SELECT COUNT(*) as count FROM archives WHERE user_id = $1',
    [userId]
  );
  
  return {
    total: parseInt(total.rows[0].count),
    by_type: result.rows,
  };
}
