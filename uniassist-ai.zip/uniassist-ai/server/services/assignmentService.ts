import { query, transaction } from '../database/db';
import { NotFoundError } from '../middleware/errorHandler';

export interface CreateAssignmentData {
  course_id?: string;
  title: string;
  description?: string;
  due_date: string;
  priority?: 'low' | 'medium' | 'high';
  status?: 'pending' | 'in-progress' | 'completed';
  estimated_hours?: number;
  tags?: string[];
  source?: 'manual' | 'detected' | 'telegram' | 'document';
}

export async function createAssignment(userId: string, data: CreateAssignmentData) {
  // Get course name if course_id provided
  let courseName = null;
  if (data.course_id) {
    const courseResult = await query(
      'SELECT name FROM courses WHERE id = $1 AND user_id = $2',
      [data.course_id, userId]
    );
    if (courseResult.rows.length > 0) {
      courseName = courseResult.rows[0].name;
    }
  }
  
  const result = await query(
    `INSERT INTO assignments (user_id, course_id, title, description, due_date, priority, status, estimated_hours, tags, source)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
     RETURNING *`,
    [
      userId,
      data.course_id || null,
      data.title,
      data.description || null,
      data.due_date,
      data.priority || 'medium',
      data.status || 'pending',
      data.estimated_hours || null,
      data.tags || null,
      data.source || 'manual',
    ]
  );
  
  return { ...result.rows[0], course_name: courseName };
}

export async function getAssignments(userId: string, options: {
  status?: string;
  courseId?: string;
  includeArchived?: boolean;
  upcoming?: boolean;
  overdue?: boolean;
} = {}) {
  let whereClause = 'a.user_id = $1';
  const params: any[] = [userId];
  
  if (!options.includeArchived) {
    whereClause += ' AND a.is_archived = false';
  }
  
  if (options.status) {
    params.push(options.status);
    whereClause += ` AND a.status = $${params.length}`;
  }
  
  if (options.courseId) {
    params.push(options.courseId);
    whereClause += ` AND a.course_id = $${params.length}`;
  }
  
  if (options.upcoming) {
    whereClause += ` AND a.due_date >= NOW() AND a.status != 'completed'`;
  }
  
  if (options.overdue) {
    whereClause += ` AND a.due_date < NOW() AND a.status NOT IN ('completed', 'overdue')`;
  }
  
  const result = await query(
    `SELECT a.*, c.name as course_name, c.code as course_code, c.color as course_color
     FROM assignments a
     LEFT JOIN courses c ON c.id = a.course_id
     WHERE ${whereClause}
     ORDER BY 
       CASE WHEN a.status = 'completed' THEN 1 ELSE 0 END,
       a.due_date ASC`,
    params
  );
  
  return result.rows;
}

export async function getAssignmentById(userId: string, assignmentId: string) {
  const result = await query(
    `SELECT a.*, c.name as course_name, c.code as course_code, c.color as course_color
     FROM assignments a
     LEFT JOIN courses c ON c.id = a.course_id
     WHERE a.id = $1 AND a.user_id = $2`,
    [assignmentId, userId]
  );
  
  if (result.rows.length === 0) {
    throw new NotFoundError('Assignment');
  }
  
  return result.rows[0];
}

export async function updateAssignment(userId: string, assignmentId: string, data: Partial<CreateAssignmentData & {
  grade?: number;
  max_grade?: number;
  actual_hours?: number;
  submission_url?: string;
  notes?: string;
}>) {
  const fields: string[] = [];
  const values: any[] = [];
  let paramCount = 0;
  
  const allowedFields = [
    'course_id', 'title', 'description', 'due_date', 'priority', 'status',
    'estimated_hours', 'actual_hours', 'grade', 'max_grade', 'submission_url',
    'notes', 'tags'
  ];
  
  for (const field of allowedFields) {
    if ((data as any)[field] !== undefined) {
      paramCount++;
      fields.push(`${field} = $${paramCount}`);
      values.push((data as any)[field]);
    }
  }
  
  // Handle completion
  if (data.status === 'completed') {
    fields.push(`completed_at = NOW()`);
  } else if (data.status && data.status !== 'completed') {
    fields.push(`completed_at = NULL`);
  }
  
  if (fields.length === 0) {
    return getAssignmentById(userId, assignmentId);
  }
  
  paramCount++;
  values.push(assignmentId);
  paramCount++;
  values.push(userId);
  
  const result = await query(
    `UPDATE assignments SET ${fields.join(', ')}
     WHERE id = $${paramCount - 1} AND user_id = $${paramCount}
     RETURNING *`,
    values
  );
  
  if (result.rows.length === 0) {
    throw new NotFoundError('Assignment');
  }
  
  return getAssignmentById(userId, assignmentId);
}

export async function deleteAssignment(userId: string, assignmentId: string) {
  const result = await query(
    'DELETE FROM assignments WHERE id = $1 AND user_id = $2 RETURNING id',
    [assignmentId, userId]
  );
  
  if (result.rows.length === 0) {
    throw new NotFoundError('Assignment');
  }
}

export async function archiveAssignment(userId: string, assignmentId: string) {
  return transaction(async (client) => {
    const result = await client.query(
      'SELECT * FROM assignments WHERE id = $1 AND user_id = $2',
      [assignmentId, userId]
    );
    
    if (result.rows.length === 0) {
      throw new NotFoundError('Assignment');
    }
    
    await client.query(
      `INSERT INTO archives (user_id, entity_type, entity_id, entity_data)
       VALUES ($1, 'assignment', $2, $3)`,
      [userId, assignmentId, JSON.stringify(result.rows[0])]
    );
    
    await client.query(
      'UPDATE assignments SET is_archived = true WHERE id = $1',
      [assignmentId]
    );
    
    return { archived: true };
  });
}

export async function getUpcomingDeadlines(userId: string, days: number = 7) {
  const result = await query(
    `SELECT a.*, c.name as course_name, c.color as course_color,
            EXTRACT(DAY FROM a.due_date - NOW()) as days_remaining
     FROM assignments a
     LEFT JOIN courses c ON c.id = a.course_id
     WHERE a.user_id = $1 
       AND a.status NOT IN ('completed')
       AND a.is_archived = false
       AND a.due_date BETWEEN NOW() AND NOW() + INTERVAL '${days} days'
     ORDER BY a.due_date ASC
     LIMIT 10`,
    [userId]
  );
  
  return result.rows;
}

export async function checkAndUpdateOverdue() {
  await query(`
    UPDATE assignments 
    SET status = 'overdue'
    WHERE status IN ('pending', 'in-progress') 
    AND due_date < NOW()
    AND is_archived = false
  `);
}
