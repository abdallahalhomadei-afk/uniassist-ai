import { Telegraf } from 'telegraf';
import { query } from '../database/db';
import { env } from '../config/env';
import { createAssignment } from './assignmentService';
import { createExam } from './examService';
import { sendMessage as sendChatMessage } from './chatService';
import { getApiKey } from './userService';
import { detectAssignmentsAndExams } from './detectionService';
import OpenAI from 'openai';

let bot: Telegraf | null = null;

export function initializeTelegramBot() {
  if (!env.TELEGRAM_BOT_TOKEN) {
    console.log('Telegram bot token not configured, skipping initialization');
    return null;
  }
  
  bot = new Telegraf(env.TELEGRAM_BOT_TOKEN);
  
  // Start command
  bot.start(async (ctx) => {
    const chatId = ctx.chat.id;
    
    // Check if user is linked
    const userResult = await query(
      'SELECT id, name FROM users WHERE telegram_chat_id = $1',
      [chatId]
    );
    
    if (userResult.rows.length > 0) {
      await ctx.reply(
        `Welcome back, ${userResult.rows[0].name}! 👋\n\n` +
        `I'm your UniAssist AI bot. Here's what I can do:\n\n` +
        `📝 /add_assignment - Add a new assignment\n` +
        `📚 /add_exam - Add a new exam\n` +
        `📅 /schedule - View today's schedule\n` +
        `📋 /deadlines - View upcoming deadlines\n` +
        `🤖 /ask [question] - Ask AI a question\n` +
        `🔗 /unlink - Unlink this account\n\n` +
        `You can also send me:\n` +
        `• Voice messages - I'll transcribe and detect deadlines\n` +
        `• Documents - I'll analyze them for assignments\n` +
        `• Text - I'll try to detect any deadlines mentioned`
      );
    } else {
      await ctx.reply(
        `Welcome to UniAssist AI! 🎓\n\n` +
        `To get started, please link your account:\n\n` +
        `1. Open the UniAssist app\n` +
        `2. Go to Settings\n` +
        `3. Click "Link Telegram"\n` +
        `4. Enter this code: \`${chatId}\`\n\n` +
        `Or use: /link YOUR_EMAIL YOUR_PASSWORD`,
        { parse_mode: 'Markdown' }
      );
    }
  });
  
  // Link account
  bot.command('link', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length < 2) {
      await ctx.reply('Usage: /link your@email.com your_password');
      return;
    }
    
    const [email, password] = args;
    const chatId = ctx.chat.id;
    const username = ctx.from?.username;
    
    // Verify credentials (simplified - in production use proper auth)
    const userResult = await query(
      'SELECT id, name, password_hash FROM users WHERE email = $1',
      [email.toLowerCase()]
    );
    
    if (userResult.rows.length === 0) {
      await ctx.reply('❌ Account not found. Please check your email.');
      return;
    }
    
    const bcrypt = await import('bcryptjs');
    const valid = await bcrypt.compare(password, userResult.rows[0].password_hash);
    
    if (!valid) {
      await ctx.reply('❌ Invalid password.');
      return;
    }
    
    // Link account
    await query(
      'UPDATE users SET telegram_chat_id = $1, telegram_username = $2 WHERE id = $3',
      [chatId, username, userResult.rows[0].id]
    );
    
    await ctx.reply(
      `✅ Account linked successfully!\n\n` +
      `Welcome, ${userResult.rows[0].name}! You can now receive notifications and manage your academic tasks through Telegram.`
    );
  });
  
  // Unlink account
  bot.command('unlink', async (ctx) => {
    const chatId = ctx.chat.id;
    
    await query(
      'UPDATE users SET telegram_chat_id = NULL, telegram_username = NULL WHERE telegram_chat_id = $1',
      [chatId]
    );
    
    await ctx.reply('✅ Account unlinked. Use /start to link a new account.');
  });
  
  // Add assignment via Telegram
  bot.command('add_assignment', async (ctx) => {
    const userId = await getUserIdFromChat(ctx.chat.id);
    if (!userId) {
      await ctx.reply('Please link your account first with /start');
      return;
    }
    
    const text = ctx.message.text.replace('/add_assignment', '').trim();
    if (!text) {
      await ctx.reply(
        'Usage: /add_assignment Title | Due Date\n\n' +
        'Example: /add_assignment Math Homework | 2024-12-20'
      );
      return;
    }
    
    const parts = text.split('|').map(s => s.trim());
    const title = parts[0];
    const dueDate = parts[1] || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    
    try {
      const assignment = await createAssignment(userId, {
        title,
        due_date: dueDate,
        source: 'telegram',
      });
      
      await ctx.reply(
        `✅ Assignment created!\n\n` +
        `📝 ${assignment.title}\n` +
        `📅 Due: ${assignment.due_date}`
      );
    } catch (error) {
      await ctx.reply('❌ Failed to create assignment. Please try again.');
    }
  });
  
  // Add exam
  bot.command('add_exam', async (ctx) => {
    const userId = await getUserIdFromChat(ctx.chat.id);
    if (!userId) {
      await ctx.reply('Please link your account first with /start');
      return;
    }
    
    const text = ctx.message.text.replace('/add_exam', '').trim();
    if (!text) {
      await ctx.reply(
        'Usage: /add_exam Title | Date | Time\n\n' +
        'Example: /add_exam Physics Final | 2024-12-25 | 09:00'
      );
      return;
    }
    
    const parts = text.split('|').map(s => s.trim());
    const title = parts[0];
    const examDate = parts[1] || new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const startTime = parts[2] || '09:00';
    
    try {
      const exam = await createExam(userId, {
        title,
        exam_date: examDate,
        start_time: startTime,
        source: 'telegram',
      });
      
      await ctx.reply(
        `✅ Exam scheduled!\n\n` +
        `📚 ${exam.title}\n` +
        `📅 Date: ${exam.exam_date}\n` +
        `⏰ Time: ${exam.start_time}`
      );
    } catch (error) {
      await ctx.reply('❌ Failed to schedule exam. Please try again.');
    }
  });
  
  // View today's schedule
  bot.command('schedule', async (ctx) => {
    const userId = await getUserIdFromChat(ctx.chat.id);
    if (!userId) {
      await ctx.reply('Please link your account first with /start');
      return;
    }
    
    const result = await query(
      `SELECT * FROM todays_schedule WHERE user_id = $1`,
      [userId]
    );
    
    if (result.rows.length === 0) {
      await ctx.reply('📅 No classes scheduled for today! 🎉');
      return;
    }
    
    let message = '📅 *Today\'s Schedule*\n\n';
    for (const course of result.rows) {
      message += `📚 *${course.course_name}*\n`;
      message += `   ⏰ ${course.start_time} - ${course.end_time}\n`;
      if (course.room) message += `   📍 ${course.room}\n`;
      message += '\n';
    }
    
    await ctx.reply(message, { parse_mode: 'Markdown' });
  });
  
  // View deadlines
  bot.command('deadlines', async (ctx) => {
    const userId = await getUserIdFromChat(ctx.chat.id);
    if (!userId) {
      await ctx.reply('Please link your account first with /start');
      return;
    }
    
    const assignments = await query(
      `SELECT title, due_date, course_id FROM assignments 
       WHERE user_id = $1 AND status NOT IN ('completed') AND is_archived = false
       AND due_date >= NOW()
       ORDER BY due_date LIMIT 10`,
      [userId]
    );
    
    const exams = await query(
      `SELECT title, exam_date, exam_type FROM exams
       WHERE user_id = $1 AND is_archived = false AND exam_date >= CURRENT_DATE
       ORDER BY exam_date LIMIT 5`,
      [userId]
    );
    
    let message = '📋 *Upcoming Deadlines*\n\n';
    
    if (assignments.rows.length > 0) {
      message += '*Assignments:*\n';
      for (const a of assignments.rows) {
        const daysLeft = Math.ceil((new Date(a.due_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
        message += `📝 ${a.title} - ${daysLeft} day(s) left\n`;
      }
      message += '\n';
    }
    
    if (exams.rows.length > 0) {
      message += '*Exams:*\n';
      for (const e of exams.rows) {
        message += `📚 ${e.title} (${e.exam_type}) - ${e.exam_date}\n`;
      }
    }
    
    if (assignments.rows.length === 0 && exams.rows.length === 0) {
      message = '✨ No upcoming deadlines! You\'re all caught up!';
    }
    
    await ctx.reply(message, { parse_mode: 'Markdown' });
  });
  
  // Ask AI
  bot.command('ask', async (ctx) => {
    const userId = await getUserIdFromChat(ctx.chat.id);
    if (!userId) {
      await ctx.reply('Please link your account first with /start');
      return;
    }
    
    const question = ctx.message.text.replace('/ask', '').trim();
    if (!question) {
      await ctx.reply('Usage: /ask your question here');
      return;
    }
    
    try {
      await ctx.sendChatAction('typing');
      const response = await sendChatMessage(userId, question);
      await ctx.reply(response.message, { parse_mode: 'Markdown' });
    } catch (error: any) {
      await ctx.reply(`❌ ${error.message || 'Failed to get response'}`);
    }
  });
  
  // Handle voice messages
  bot.on('voice', async (ctx) => {
    const userId = await getUserIdFromChat(ctx.chat.id);
    if (!userId) {
      await ctx.reply('Please link your account first with /start');
      return;
    }
    
    const apiKey = await getApiKey(userId);
    if (!apiKey) {
      await ctx.reply('❌ Please configure your OpenAI API key in the app settings to use voice features.');
      return;
    }
    
    try {
      await ctx.reply('🎤 Processing your voice message...');
      
      // Get file
      const file = await ctx.telegram.getFile(ctx.message.voice.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${env.TELEGRAM_BOT_TOKEN}/${file.file_path}`;
      
      // Download file
      const response = await fetch(fileUrl);
      const buffer = await response.arrayBuffer();
      
      // Transcribe with Whisper
      const openai = new OpenAI({ apiKey });
      const audioFile = new File([buffer], 'voice.ogg', { type: 'audio/ogg' });
      
      const transcription = await openai.audio.transcriptions.create({
        file: audioFile,
        model: 'whisper-1',
      });
      
      await ctx.reply(`📝 *Transcription:*\n${transcription.text}`, { parse_mode: 'Markdown' });
      
      // Detect assignments and exams
      const detections = await detectAssignmentsAndExams(transcription.text, apiKey);
      
      if (detections.assignments.length > 0 || detections.exams.length > 0) {
        let detectMsg = '🔍 *Detected items:*\n\n';
        
        for (const a of detections.assignments) {
          detectMsg += `📝 Assignment: "${a.title}"`;
          if (a.due_date) detectMsg += ` (Due: ${a.due_date})`;
          detectMsg += '\n';
          
          // Auto-create assignment
          await createAssignment(userId, {
            title: a.title,
            description: a.description,
            due_date: a.due_date || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            source: 'telegram',
          });
        }
        
        for (const e of detections.exams) {
          detectMsg += `📚 Exam: "${e.title}"`;
          if (e.exam_date) detectMsg += ` (Date: ${e.exam_date})`;
          detectMsg += '\n';
          
          // Auto-create exam
          await createExam(userId, {
            title: e.title,
            description: e.description,
            exam_date: e.exam_date || new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            start_time: e.start_time || '09:00',
            exam_type: e.exam_type as any,
            source: 'telegram',
          });
        }
        
        detectMsg += '\n✅ Items have been added automatically!';
        await ctx.reply(detectMsg, { parse_mode: 'Markdown' });
      }
      
      // Log message
      await logTelegramMessage(userId, ctx.chat.id, ctx.message.message_id, 'incoming', 'voice', transcription.text);
      
    } catch (error: any) {
      console.error('Voice processing error:', error);
      await ctx.reply('❌ Failed to process voice message. Please try again.');
    }
  });
  
  // Handle text messages (detect deadlines)
  bot.on('text', async (ctx) => {
    // Skip commands
    if (ctx.message.text.startsWith('/')) return;
    
    const userId = await getUserIdFromChat(ctx.chat.id);
    if (!userId) return;
    
    const apiKey = await getApiKey(userId);
    if (!apiKey) return;
    
    // Try to detect deadlines in the message
    try {
      const detections = await detectAssignmentsAndExams(ctx.message.text, apiKey);
      
      if (detections.assignments.length > 0 || detections.exams.length > 0) {
        let message = '🔍 I detected some items in your message:\n\n';
        
        for (const a of detections.assignments) {
          message += `📝 Assignment: "${a.title}"`;
          if (a.due_date) message += ` (Due: ${a.due_date})`;
          message += '\n';
        }
        
        for (const e of detections.exams) {
          message += `📚 Exam: "${e.title}"`;
          if (e.exam_date) message += ` (Date: ${e.exam_date})`;
          message += '\n';
        }
        
        message += '\nWould you like me to add these? Reply with "yes" to confirm.';
        
        // Store pending items (simplified - in production use a proper state management)
        await ctx.reply(message);
      }
    } catch (e) {
      // Silently fail for text analysis
    }
  });
  
  // Handle documents
  bot.on('document', async (ctx) => {
    const userId = await getUserIdFromChat(ctx.chat.id);
    if (!userId) {
      await ctx.reply('Please link your account first with /start');
      return;
    }
    
    await ctx.reply('📄 Document received! Please upload it through the app for full analysis.');
  });
  
  // Start bot
  bot.launch().then(() => {
    console.log('✅ Telegram bot started');
  }).catch(err => {
    console.error('Failed to start Telegram bot:', err);
  });
  
  // Graceful shutdown
  process.once('SIGINT', () => bot?.stop('SIGINT'));
  process.once('SIGTERM', () => bot?.stop('SIGTERM'));
  
  return bot;
}

async function getUserIdFromChat(chatId: number): Promise<string | null> {
  const result = await query(
    'SELECT id FROM users WHERE telegram_chat_id = $1',
    [chatId]
  );
  return result.rows[0]?.id || null;
}

async function logTelegramMessage(
  userId: string | null,
  chatId: number,
  messageId: number,
  direction: 'incoming' | 'outgoing',
  messageType: string,
  content?: string
) {
  await query(
    `INSERT INTO telegram_messages (user_id, chat_id, message_id, direction, message_type, content)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [userId, chatId, messageId, direction, messageType, content]
  );
}

export async function sendTelegramMessage(chatId: number, message: string) {
  if (!bot) {
    console.warn('Telegram bot not initialized');
    return;
  }
  
  await bot.telegram.sendMessage(chatId, message, { parse_mode: 'Markdown' });
}

export { bot };
