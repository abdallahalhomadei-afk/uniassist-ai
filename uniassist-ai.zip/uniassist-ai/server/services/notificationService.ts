import { query } from '../database/db';
import { sendTelegramMessage } from './telegramService';

export type NotificationType = 'assignment_due' | 'exam_reminder' | 'grade_posted' | 'document_processed' | 'system' | 'telegram';
export type NotificationPriority = 'low' | 'normal' | 'high' | 'urgent';

export interface CreateNotificationData {
  user_id: string;
  type: NotificationType;
  title: string;
  message: string;
  reference_type?: string;
  reference_id?: string;
  priority?: NotificationPriority;
  channels?: string[];
  scheduled_for?: string;
}

export async function createNotification(data: CreateNotificationData) {
  const result = await query(
    `INSERT INTO notifications (user_id, type, title, message, reference_type, reference_id, priority, channels, scheduled_for)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
     RETURNING *`,
    [
      data.user_id,
      data.type,
      data.title,
      data.message,
      data.reference_type || null,
      data.reference_id || null,
      data.priority || 'normal',
      data.channels || ['app'],
      data.scheduled_for || null,
    ]
  );
  
  const notification = result.rows[0];
  
  // If not scheduled, send immediately
  if (!data.scheduled_for) {
    await sendNotification(notification);
  }
  
  return notification;
}

export async function sendNotification(notification: any) {
  const channels = notification.channels || ['app'];
  
  // Send via Telegram if enabled
  if (channels.includes('telegram')) {
    const userResult = await query(
      'SELECT telegram_chat_id FROM users WHERE id = $1',
      [notification.user_id]
    );
    
    if (userResult.rows[0]?.telegram_chat_id) {
      try {
        const telegramMessage = formatTelegramNotification(notification);
        await sendTelegramMessage(userResult.rows[0].telegram_chat_id, telegramMessage);
      } catch (e) {
        console.error('Telegram notification failed:', e);
      }
    }
  }
  
  // Mark as sent
  await query(
    `UPDATE notifications SET is_sent = true, sent_at = NOW() WHERE id = $1`,
    [notification.id]
  );
}

function formatTelegramNotification(notification: any): string {
  const priorityEmoji = {
    low: 'ℹ️',
    normal: '📢',
    high: '⚠️',
    urgent: '🚨',
  };
  
  const typeEmoji = {
    assignment_due: '📝',
    exam_reminder: '📚',
    grade_posted: '📊',
    document_processed: '📄',
    system: '⚙️',
    telegram: '💬',
  };
  
  const emoji = priorityEmoji[notification.priority as keyof typeof priorityEmoji] || '📢';
  const typeIcon = typeEmoji[notification.type as keyof typeof typeEmoji] || '';
  
  return `${emoji} ${typeIcon} *${notification.title}*\n\n${notification.message}`;
}

export async function getNotifications(userId: string, options: {
  unreadOnly?: boolean;
  limit?: number;
  offset?: number;
} = {}) {
  let whereClause = 'user_id = $1';
  const params: any[] = [userId];
  
  if (options.unreadOnly) {
    whereClause += ' AND is_read = false';
  }
  
  const limit = options.limit || 50;
  const offset = options.offset || 0;
  
  const result = await query(
    `SELECT * FROM notifications 
     WHERE ${whereClause}
     ORDER BY created_at DESC
     LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
    [...params, limit, offset]
  );
  
  return result.rows;
}

export async function getUnreadCount(userId: string) {
  const result = await query(
    'SELECT COUNT(*) as count FROM notifications WHERE user_id = $1 AND is_read = false',
    [userId]
  );
  return parseInt(result.rows[0].count);
}

export async function markAsRead(userId: string, notificationId: string) {
  await query(
    `UPDATE notifications SET is_read = true, read_at = NOW() 
     WHERE id = $1 AND user_id = $2`,
    [notificationId, userId]
  );
}

export async function markAllAsRead(userId: string) {
  await query(
    `UPDATE notifications SET is_read = true, read_at = NOW() 
     WHERE user_id = $1 AND is_read = false`,
    [userId]
  );
}

export async function deleteNotification(userId: string, notificationId: string) {
  await query(
    'DELETE FROM notifications WHERE id = $1 AND user_id = $2',
    [notificationId, userId]
  );
}

// Scheduled notification processor
export async function processScheduledNotifications() {
  const result = await query(
    `SELECT * FROM notifications 
     WHERE scheduled_for IS NOT NULL 
       AND scheduled_for <= NOW() 
       AND is_sent = false`
  );
  
  for (const notification of result.rows) {
    try {
      await sendNotification(notification);
    } catch (e) {
      console.error('Failed to send scheduled notification:', e);
    }
  }
}

// Create reminders for upcoming deadlines
export async function createUpcomingReminders() {
  // Assignment reminders (1 day before)
  const assignmentResult = await query(
    `SELECT a.id, a.title, a.due_date, a.user_id, c.name as course_name
     FROM assignments a
     LEFT JOIN courses c ON c.id = a.course_id
     WHERE a.status NOT IN ('completed', 'overdue')
       AND a.is_archived = false
       AND a.reminder_sent = false
       AND a.due_date BETWEEN NOW() AND NOW() + INTERVAL '24 hours'`
  );
  
  for (const assignment of assignmentResult.rows) {
    await createNotification({
      user_id: assignment.user_id,
      type: 'assignment_due',
      title: 'Assignment Due Tomorrow',
      message: `"${assignment.title}" for ${assignment.course_name || 'your course'} is due tomorrow.`,
      reference_type: 'assignment',
      reference_id: assignment.id,
      priority: 'high',
      channels: ['app', 'telegram'],
    });
    
    await query('UPDATE assignments SET reminder_sent = true WHERE id = $1', [assignment.id]);
  }
  
  // Exam reminders (2 days before)
  const examResult = await query(
    `SELECT e.id, e.title, e.exam_date, e.start_time, e.user_id, c.name as course_name
     FROM exams e
     LEFT JOIN courses c ON c.id = e.course_id
     WHERE e.is_archived = false
       AND e.reminder_sent = false
       AND e.exam_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '2 days'`
  );
  
  for (const exam of examResult.rows) {
    await createNotification({
      user_id: exam.user_id,
      type: 'exam_reminder',
      title: 'Exam Coming Up',
      message: `"${exam.title}" for ${exam.course_name || 'your course'} is on ${exam.exam_date} at ${exam.start_time}.`,
      reference_type: 'exam',
      reference_id: exam.id,
      priority: 'urgent',
      channels: ['app', 'telegram'],
    });
    
    await query('UPDATE exams SET reminder_sent = true WHERE id = $1', [exam.id]);
  }
}
