-- UniAssist AI Database Schema
-- PostgreSQL 14+

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ============================================
-- USERS TABLE
-- ============================================
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    university VARCHAR(255),
    major VARCHAR(255),
    avatar_url TEXT,
    telegram_chat_id BIGINT UNIQUE,
    telegram_username VARCHAR(255),
    api_key_encrypted TEXT,
    language VARCHAR(10) DEFAULT 'en',
    theme VARCHAR(20) DEFAULT 'light',
    notifications_enabled BOOLEAN DEFAULT true,
    timezone VARCHAR(50) DEFAULT 'UTC',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_login_at TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT true,
    is_verified BOOLEAN DEFAULT false,
    verification_token VARCHAR(255),
    reset_token VARCHAR(255),
    reset_token_expires TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_telegram_chat_id ON users(telegram_chat_id);

-- ============================================
-- SESSIONS TABLE
-- ============================================
CREATE TABLE sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash VARCHAR(255) NOT NULL,
    device_info TEXT,
    ip_address INET,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT true
);

CREATE INDEX idx_sessions_user_id ON sessions(user_id);
CREATE INDEX idx_sessions_token_hash ON sessions(token_hash);

-- ============================================
-- COURSES TABLE
-- ============================================
CREATE TABLE courses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) NOT NULL,
    instructor VARCHAR(255),
    color VARCHAR(20) DEFAULT '#3b82f6',
    credits INTEGER DEFAULT 3,
    semester VARCHAR(50),
    year INTEGER,
    is_active BOOLEAN DEFAULT true,
    is_archived BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_courses_user_id ON courses(user_id);
CREATE INDEX idx_courses_is_archived ON courses(is_archived);

-- ============================================
-- COURSE SCHEDULES TABLE
-- ============================================
CREATE TABLE course_schedules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    day_of_week INTEGER NOT NULL CHECK (day_of_week >= 0 AND day_of_week <= 6),
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    room VARCHAR(100),
    building VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_course_schedules_course_id ON course_schedules(course_id);
CREATE INDEX idx_course_schedules_day ON course_schedules(day_of_week);

-- ============================================
-- ASSIGNMENTS TABLE
-- ============================================
CREATE TABLE assignments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    course_id UUID REFERENCES courses(id) ON DELETE SET NULL,
    title VARCHAR(500) NOT NULL,
    description TEXT,
    due_date TIMESTAMP WITH TIME ZONE NOT NULL,
    status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'in-progress', 'completed', 'overdue')),
    priority VARCHAR(20) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high')),
    estimated_hours DECIMAL(5,2),
    actual_hours DECIMAL(5,2),
    grade DECIMAL(5,2),
    max_grade DECIMAL(5,2),
    submission_url TEXT,
    notes TEXT,
    tags TEXT[],
    reminder_sent BOOLEAN DEFAULT false,
    is_archived BOOLEAN DEFAULT false,
    completed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    source VARCHAR(50) DEFAULT 'manual' CHECK (source IN ('manual', 'detected', 'telegram', 'document'))
);

CREATE INDEX idx_assignments_user_id ON assignments(user_id);
CREATE INDEX idx_assignments_course_id ON assignments(course_id);
CREATE INDEX idx_assignments_due_date ON assignments(due_date);
CREATE INDEX idx_assignments_status ON assignments(status);
CREATE INDEX idx_assignments_is_archived ON assignments(is_archived);
CREATE INDEX idx_assignments_search ON assignments USING gin(to_tsvector('english', title || ' ' || COALESCE(description, '')));

-- ============================================
-- EXAMS TABLE
-- ============================================
CREATE TABLE exams (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    course_id UUID REFERENCES courses(id) ON DELETE SET NULL,
    title VARCHAR(500) NOT NULL,
    description TEXT,
    exam_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME,
    duration_minutes INTEGER,
    room VARCHAR(100),
    building VARCHAR(100),
    exam_type VARCHAR(50) DEFAULT 'midterm' CHECK (exam_type IN ('quiz', 'midterm', 'final', 'practical', 'oral', 'other')),
    weight DECIMAL(5,2),
    topics TEXT[],
    materials_allowed TEXT,
    notes TEXT,
    grade DECIMAL(5,2),
    max_grade DECIMAL(5,2),
    reminder_sent BOOLEAN DEFAULT false,
    is_archived BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    source VARCHAR(50) DEFAULT 'manual' CHECK (source IN ('manual', 'detected', 'telegram', 'document'))
);

CREATE INDEX idx_exams_user_id ON exams(user_id);
CREATE INDEX idx_exams_course_id ON exams(course_id);
CREATE INDEX idx_exams_exam_date ON exams(exam_date);
CREATE INDEX idx_exams_is_archived ON exams(is_archived);
CREATE INDEX idx_exams_search ON exams USING gin(to_tsvector('english', title || ' ' || COALESCE(description, '')));

-- ============================================
-- GRADES TABLE
-- ============================================
CREATE TABLE grades (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    course_id UUID REFERENCES courses(id) ON DELETE SET NULL,
    course_name VARCHAR(255) NOT NULL,
    course_code VARCHAR(50),
    credits INTEGER NOT NULL,
    grade VARCHAR(10) NOT NULL,
    grade_points DECIMAL(3,2),
    semester VARCHAR(50) NOT NULL,
    year INTEGER,
    is_archived BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_grades_user_id ON grades(user_id);
CREATE INDEX idx_grades_semester ON grades(semester);

-- ============================================
-- DOCUMENTS TABLE
-- ============================================
CREATE TABLE documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    course_id UUID REFERENCES courses(id) ON DELETE SET NULL,
    filename VARCHAR(500) NOT NULL,
    original_filename VARCHAR(500) NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    file_size BIGINT NOT NULL,
    storage_path TEXT NOT NULL,
    storage_type VARCHAR(50) DEFAULT 'local' CHECK (storage_type IN ('local', 's3', 'gcs', 'azure')),
    content_text TEXT,
    summary TEXT,
    detected_assignments JSONB,
    detected_exams JSONB,
    processing_status VARCHAR(50) DEFAULT 'pending' CHECK (processing_status IN ('pending', 'processing', 'completed', 'failed')),
    processing_error TEXT,
    tags TEXT[],
    is_archived BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_documents_user_id ON documents(user_id);
CREATE INDEX idx_documents_course_id ON documents(course_id);
CREATE INDEX idx_documents_is_archived ON documents(is_archived);
CREATE INDEX idx_documents_content_search ON documents USING gin(to_tsvector('english', COALESCE(content_text, '') || ' ' || COALESCE(summary, '')));

-- ============================================
-- AUDIO TRANSCRIPTIONS TABLE
-- ============================================
CREATE TABLE audio_transcriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    document_id UUID REFERENCES documents(id) ON DELETE SET NULL,
    filename VARCHAR(500) NOT NULL,
    original_filename VARCHAR(500) NOT NULL,
    duration_seconds INTEGER,
    file_size BIGINT NOT NULL,
    storage_path TEXT NOT NULL,
    transcription_text TEXT,
    detected_assignments JSONB,
    detected_exams JSONB,
    language VARCHAR(10),
    processing_status VARCHAR(50) DEFAULT 'pending' CHECK (processing_status IN ('pending', 'processing', 'completed', 'failed')),
    processing_error TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_audio_transcriptions_user_id ON audio_transcriptions(user_id);

-- ============================================
-- CHAT MESSAGES TABLE
-- ============================================
CREATE TABLE chat_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
    content TEXT NOT NULL,
    context_data JSONB,
    tokens_used INTEGER,
    model VARCHAR(50),
    is_archived BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_chat_messages_user_id ON chat_messages(user_id);
CREATE INDEX idx_chat_messages_created_at ON chat_messages(created_at);

-- ============================================
-- NOTIFICATIONS TABLE
-- ============================================
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL CHECK (type IN ('assignment_due', 'exam_reminder', 'grade_posted', 'document_processed', 'system', 'telegram')),
    title VARCHAR(500) NOT NULL,
    message TEXT NOT NULL,
    reference_type VARCHAR(50),
    reference_id UUID,
    priority VARCHAR(20) DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
    channels TEXT[] DEFAULT ARRAY['app'],
    is_read BOOLEAN DEFAULT false,
    is_sent BOOLEAN DEFAULT false,
    sent_at TIMESTAMP WITH TIME ZONE,
    read_at TIMESTAMP WITH TIME ZONE,
    scheduled_for TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);
CREATE INDEX idx_notifications_scheduled ON notifications(scheduled_for) WHERE scheduled_for IS NOT NULL;

-- ============================================
-- ARCHIVES TABLE
-- ============================================
CREATE TABLE archives (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    entity_type VARCHAR(50) NOT NULL CHECK (entity_type IN ('course', 'assignment', 'exam', 'document', 'grade', 'chat')),
    entity_id UUID NOT NULL,
    entity_data JSONB NOT NULL,
    archived_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    restore_until TIMESTAMP WITH TIME ZONE,
    reason TEXT
);

CREATE INDEX idx_archives_user_id ON archives(user_id);
CREATE INDEX idx_archives_entity ON archives(entity_type, entity_id);

-- ============================================
-- TELEGRAM MESSAGES LOG
-- ============================================
CREATE TABLE telegram_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    chat_id BIGINT NOT NULL,
    message_id BIGINT,
    direction VARCHAR(10) NOT NULL CHECK (direction IN ('incoming', 'outgoing')),
    message_type VARCHAR(50) NOT NULL,
    content TEXT,
    file_id VARCHAR(255),
    processed BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_telegram_messages_chat_id ON telegram_messages(chat_id);
CREATE INDEX idx_telegram_messages_user_id ON telegram_messages(user_id);

-- ============================================
-- SEARCH HISTORY TABLE
-- ============================================
CREATE TABLE search_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    query TEXT NOT NULL,
    filters JSONB,
    results_count INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_search_history_user_id ON search_history(user_id);

-- ============================================
-- API USAGE LOG
-- ============================================
CREATE TABLE api_usage_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    endpoint VARCHAR(255) NOT NULL,
    method VARCHAR(10) NOT NULL,
    status_code INTEGER,
    response_time_ms INTEGER,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_api_usage_log_user_id ON api_usage_log(user_id);
CREATE INDEX idx_api_usage_log_created_at ON api_usage_log(created_at);

-- ============================================
-- FUNCTIONS
-- ============================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply triggers
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_courses_updated_at BEFORE UPDATE ON courses FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_assignments_updated_at BEFORE UPDATE ON assignments FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_exams_updated_at BEFORE UPDATE ON exams FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_grades_updated_at BEFORE UPDATE ON grades FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_documents_updated_at BEFORE UPDATE ON documents FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to calculate GPA
CREATE OR REPLACE FUNCTION calculate_user_gpa(p_user_id UUID)
RETURNS TABLE(cumulative_gpa DECIMAL, total_credits INTEGER, semester_gpa DECIMAL, semester VARCHAR) AS $$
BEGIN
    RETURN QUERY
    WITH gpa_calc AS (
        SELECT 
            SUM(g.grade_points * g.credits) / NULLIF(SUM(g.credits), 0) as gpa,
            SUM(g.credits) as credits,
            g.semester as sem
        FROM grades g
        WHERE g.user_id = p_user_id AND g.is_archived = false
        GROUP BY g.semester
    )
    SELECT 
        (SELECT SUM(grade_points * credits) / NULLIF(SUM(credits), 0) FROM grades WHERE user_id = p_user_id AND is_archived = false) as cumulative_gpa,
        (SELECT SUM(credits)::INTEGER FROM grades WHERE user_id = p_user_id AND is_archived = false) as total_credits,
        gpa_calc.gpa as semester_gpa,
        gpa_calc.sem as semester
    FROM gpa_calc;
END;
$$ LANGUAGE plpgsql;

-- Function to check overdue assignments
CREATE OR REPLACE FUNCTION check_overdue_assignments()
RETURNS void AS $$
BEGIN
    UPDATE assignments 
    SET status = 'overdue'
    WHERE status IN ('pending', 'in-progress') 
    AND due_date < CURRENT_TIMESTAMP
    AND is_archived = false;
END;
$$ LANGUAGE plpgsql;

-- Full text search function
CREATE OR REPLACE FUNCTION search_all(p_user_id UUID, p_query TEXT)
RETURNS TABLE(
    entity_type TEXT,
    entity_id UUID,
    title TEXT,
    description TEXT,
    relevance REAL
) AS $$
BEGIN
    RETURN QUERY
    SELECT 'assignment'::TEXT, a.id, a.title, a.description, ts_rank(to_tsvector('english', a.title || ' ' || COALESCE(a.description, '')), plainto_tsquery('english', p_query)) as relevance
    FROM assignments a
    WHERE a.user_id = p_user_id AND a.is_archived = false
    AND to_tsvector('english', a.title || ' ' || COALESCE(a.description, '')) @@ plainto_tsquery('english', p_query)
    
    UNION ALL
    
    SELECT 'exam'::TEXT, e.id, e.title, e.description, ts_rank(to_tsvector('english', e.title || ' ' || COALESCE(e.description, '')), plainto_tsquery('english', p_query)) as relevance
    FROM exams e
    WHERE e.user_id = p_user_id AND e.is_archived = false
    AND to_tsvector('english', e.title || ' ' || COALESCE(e.description, '')) @@ plainto_tsquery('english', p_query)
    
    UNION ALL
    
    SELECT 'document'::TEXT, d.id, d.original_filename, d.summary, ts_rank(to_tsvector('english', COALESCE(d.content_text, '') || ' ' || COALESCE(d.summary, '')), plainto_tsquery('english', p_query)) as relevance
    FROM documents d
    WHERE d.user_id = p_user_id AND d.is_archived = false
    AND to_tsvector('english', COALESCE(d.content_text, '') || ' ' || COALESCE(d.summary, '')) @@ plainto_tsquery('english', p_query)
    
    UNION ALL
    
    SELECT 'course'::TEXT, c.id, c.name, c.code, 1.0 as relevance
    FROM courses c
    WHERE c.user_id = p_user_id AND c.is_archived = false
    AND (c.name ILIKE '%' || p_query || '%' OR c.code ILIKE '%' || p_query || '%')
    
    ORDER BY relevance DESC
    LIMIT 50;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- VIEWS
-- ============================================

-- Dashboard summary view
CREATE OR REPLACE VIEW dashboard_summary AS
SELECT 
    u.id as user_id,
    (SELECT COUNT(*) FROM courses c WHERE c.user_id = u.id AND c.is_active = true AND c.is_archived = false) as active_courses,
    (SELECT COUNT(*) FROM assignments a WHERE a.user_id = u.id AND a.status IN ('pending', 'in-progress') AND a.is_archived = false) as pending_assignments,
    (SELECT COUNT(*) FROM assignments a WHERE a.user_id = u.id AND a.status = 'overdue' AND a.is_archived = false) as overdue_assignments,
    (SELECT COUNT(*) FROM exams e WHERE e.user_id = u.id AND e.exam_date >= CURRENT_DATE AND e.is_archived = false) as upcoming_exams,
    (SELECT SUM(g.grade_points * g.credits) / NULLIF(SUM(g.credits), 0) FROM grades g WHERE g.user_id = u.id AND g.is_archived = false) as cumulative_gpa,
    (SELECT SUM(g.credits) FROM grades g WHERE g.user_id = u.id AND g.is_archived = false) as total_credits,
    (SELECT COUNT(*) FROM notifications n WHERE n.user_id = u.id AND n.is_read = false) as unread_notifications
FROM users u
WHERE u.is_active = true;

-- Today's schedule view
CREATE OR REPLACE VIEW todays_schedule AS
SELECT 
    c.user_id,
    c.id as course_id,
    c.name as course_name,
    c.code as course_code,
    c.color,
    cs.start_time,
    cs.end_time,
    cs.room,
    cs.building
FROM courses c
JOIN course_schedules cs ON cs.course_id = c.id
WHERE cs.day_of_week = EXTRACT(DOW FROM CURRENT_DATE)
AND c.is_active = true
AND c.is_archived = false
ORDER BY cs.start_time;
