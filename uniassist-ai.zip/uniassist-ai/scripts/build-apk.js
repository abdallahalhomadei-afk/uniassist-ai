#!/usr/bin/env node
/**
 * UniAssist AI - APK Build Script
 * 
 * This script builds the Android APK using Capacitor.
 * Requires: Java 17+, Android SDK (or auto-setup)
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

const ROOT = path.resolve(__dirname, '..');
const ANDROID_DIR = path.join(ROOT, 'android');

function run(cmd, cwd = ROOT) {
  console.log(`  $ ${cmd}`);
  try {
    return execSync(cmd, { cwd, stdio: 'inherit', encoding: 'utf-8' });
  } catch (e) {
    console.error(`  Error: ${e.message}`);
    throw e;
  }
}

function step(num, msg) {
  console.log(`\n${'─'.repeat(50)}`);
  console.log(`[${num}] ${msg}`);
  console.log('─'.repeat(50));
}

async function main() {
  console.log('\n🚀 UniAssist AI - Android APK Builder\n');
  
  // Step 1: Build web app
  step(1, 'Building web application...');
  run('npm run build');
  
  // Step 2: Sync Capacitor
  step(2, 'Syncing with Capacitor...');
  run('npx cap sync android --no-build');
  
  // Step 3: Ensure gradlew exists
  step(3, 'Preparing Android build...');
  
  const gradlewPath = path.join(ANDROID_DIR, 'gradlew');
  if (!fs.existsSync(gradlewPath)) {
    console.log('  Gradle wrapper not found. Creating...');
    
    // Create gradlew script
    const gradlewContent = `#!/bin/sh
# Gradle wrapper for UniAssist
DIR="$(cd "$(dirname "$0")" && pwd)"
exec gradle -p "$DIR" "$@"
`;
    fs.writeFileSync(gradlewPath, gradlewContent, { mode: 0o755 });
  }
  
  // Step 4: Check for Java and Android SDK
  step(4, 'Checking prerequisites...');
  
  let hasJava = false;
  let hasSdk = false;
  
  try {
    const javaVersion = execSync('java -version 2>&1', { encoding: 'utf-8' });
    console.log('  Java: ' + javaVersion.split('\n')[0]);
    hasJava = true;
  } catch {
    console.log('  ⚠️  Java not found. Install JDK 17+');
    console.log('  Ubuntu: sudo apt install openjdk-17-jdk');
    console.log('  macOS:  brew install openjdk@17');
  }
  
  const sdkPaths = [
    process.env.ANDROID_HOME,
    process.env.ANDROID_SDK_ROOT,
    path.join(os.homedir(), 'Android', 'Sdk'),
    '/usr/local/share/android-sdk',
    '/opt/android-sdk',
  ].filter(Boolean);
  
  for (const sdkPath of sdkPaths) {
    if (fs.existsSync(sdkPath)) {
      console.log('  Android SDK:', sdkPath);
      hasSdk = true;
      if (!process.env.ANDROID_HOME) {
        process.env.ANDROID_HOME = sdkPath;
      }
      break;
    }
  }
  
  if (!hasSdk) {
    console.log('  ⚠️  Android SDK not found at common locations');
    console.log('  Install via: https://developer.android.com/studio');
    console.log('  Or download command-line tools:');
    console.log('  https://developer.android.com/studio#command-tools');
  }
  
  if (!hasJava || !hasSdk) {
    console.log('\n❌ Cannot build APK without Java and Android SDK');
    console.log('\n📱 Install prerequisites, then run:');
    console.log('  npm run build');
    console.log('  npx cap sync android');
    console.log('  cd android && ./gradlew assembleDebug');
    console.log('\nOr open android/ in Android Studio and click Build > Build APK');
    process.exit(1);
  }
  
  // Step 5: Build
  step(5, 'Building APK...');
  
  try {
    run('./gradlew assembleDebug', ANDROID_DIR);
  } catch {
    // Try with system gradle
    run('gradle assembleDebug', ANDROID_DIR);
  }
  
  // Step 6: Copy output
  step(6, 'Copying APK...');
  
  const apkDir = path.join(ANDROID_DIR, 'app', 'build', 'outputs', 'apk', 'debug');
  const debugApk = path.join(apkDir, 'app-debug.apk');
  
  if (fs.existsSync(debugApk)) {
    const outputApk = path.join(ROOT, 'app-debug.apk');
    fs.copyFileSync(debugApk, outputApk);
    
    const stats = fs.statSync(outputApk);
    const sizeMB = (stats.size / 1024 / 1024).toFixed(2);
    
    console.log('\n✅ APK built successfully!');
    console.log(`   File: ${outputApk}`);
    console.log(`   Size: ${sizeMB} MB`);
    console.log(`   Install: adb install ${outputApk}`);
  } else {
    console.log('\n❌ APK not found at expected location');
    console.log('   Check:', apkDir);
  }
}

main().catch(err => {
  console.error('\n❌ Build failed:', err.message);
  process.exit(1);
});
