#!/bin/bash
set -e

echo "========================================"
echo "UniAssist AI - Building Android APK"
echo "========================================"
echo ""

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Step 1: Build web app
echo -e "${GREEN}[1/4]${NC} Building web application..."
npm run build
echo ""

# Step 2: Sync Capacitor
echo -e "${GREEN}[2/4]${NC} Syncing with Capacitor..."
npx cap sync android --no-build
echo ""

# Step 3: Check for Android SDK
echo -e "${GREEN}[3/4]${NC} Building Android APK..."
cd android

if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
    echo -e "${YELLOW}Warning: ANDROID_HOME not set.${NC}"
    echo "Please install Android SDK and set ANDROID_HOME environment variable."
    echo ""
    echo "Quick setup:"
    echo "  1. Download Android Studio: https://developer.android.com/studio"
    echo "  2. Install SDK through SDK Manager"
    echo "  3. Export ANDROID_HOME: export ANDROID_HOME=\$HOME/Android/Sdk"
    echo ""
    echo "Or install command-line tools and run:"
    echo "  sdkmanager \"platforms;android-34\" \"build-tools;34.0.0\""
    echo ""
    echo "Once SDK is installed, run:"
    echo "  cd android && ./gradlew assembleDebug"
    echo ""
    
    # Try to use local gradlew if available
    if [ -f "./gradlew" ]; then
        echo "Gradle wrapper found. Attempting build..."
        chmod +x ./gradlew
        ./gradlew assembleDebug
    fi
else
    # Build debug APK
    if [ -f "./gradlew" ]; then
        chmod +x ./gradlew
        ./gradlew assembleDebug
    else
        echo "Running Gradle..."
        gradle assembleDebug
    fi
fi

cd ..

# Step 4: Copy APK
echo ""
echo -e "${GREEN}[4/4]${NC} Copying APK..."
if [ -f "android/app/build/outputs/apk/debug/app-debug.apk" ]; then
    cp android/app/build/outputs/apk/debug/app-debug.apk app-debug.apk
    echo -e "${GREEN}✅ Debug APK built successfully!${NC}"
    echo "   Location: $(pwd)/app-debug.apk"
    echo "   Size: $(du -h app-debug.apk | cut -f1)"
elif [ -f "android/app/build/outputs/apk/release/app-release.apk" ]; then
    cp android/app/build/outputs/apk/release/app-release.apk app-release.apk
    echo -e "${GREEN}✅ Release APK built successfully!${NC}"
else
    echo -e "${RED}❌ APK not found. Build may have failed.${NC}"
    echo "Check the error messages above."
fi
echo ""

# Also create release if keystore available
if [ -f "keystore.properties" ]; then
    echo -e "${GREEN}Building release APK...${NC}"
    cd android
    ./gradlew assembleRelease
    cd ..
    if [ -f "android/app/build/outputs/apk/release/app-release.apk" ]; then
        cp android/app/build/outputs/apk/release/app-release.apk app-release.apk
        echo -e "${GREEN}✅ Release APK: app-release.apk${NC}"
    fi
fi
