#!/bin/bash

# UniAssist AI - Setup Verification Script
# This script verifies that all components are properly configured

set -e

echo "========================================"
echo "UniAssist AI - Setup Verification"
echo "========================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Counters
PASSED=0
FAILED=0
WARNINGS=0

check() {
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓${NC} $1"
        ((PASSED++))
    else
        echo -e "${RED}✗${NC} $1"
        ((FAILED++))
    fi
}

warn() {
    echo -e "${YELLOW}⚠${NC} $1"
    ((WARNINGS++))
}

# Check Node.js
echo "Checking prerequisites..."
echo ""

node --version > /dev/null 2>&1
check "Node.js installed ($(node --version 2>/dev/null || echo 'not found'))"

npm --version > /dev/null 2>&1
check "npm installed ($(npm --version 2>/dev/null || echo 'not found'))"

# Check if psql is available
if command -v psql &> /dev/null; then
    check "PostgreSQL client installed"
else
    warn "PostgreSQL client not found (optional for verification)"
fi

echo ""
echo "Checking project structure..."
echo ""

# Check directories
[ -d "server" ]
check "server/ directory exists"

[ -d "src" ]
check "src/ directory exists"

[ -f "server/database/schema.sql" ]
check "Database schema exists"

[ -f "server/index.ts" ]
check "Server entry point exists"

[ -f "src/App.tsx" ]
check "Frontend entry point exists"

echo ""
echo "Checking configuration..."
echo ""

# Check .env files
if [ -f "server/.env" ]; then
    check "server/.env exists"
    
    # Check required variables
    if grep -q "DATABASE_URL=" "server/.env"; then
        check "DATABASE_URL configured"
    else
        warn "DATABASE_URL not configured in server/.env"
    fi
    
    if grep -q "JWT_SECRET=" "server/.env"; then
        JWT_SECRET=$(grep "JWT_SECRET=" "server/.env" | cut -d'=' -f2)
        if [ ${#JWT_SECRET} -ge 32 ]; then
            check "JWT_SECRET has valid length"
        else
            warn "JWT_SECRET should be at least 32 characters"
        fi
    else
        warn "JWT_SECRET not configured"
    fi
else
    warn "server/.env not found - copy from server/.env.example"
fi

echo ""
echo "Checking dependencies..."
echo ""

[ -d "node_modules" ]
check "node_modules exists"

[ -f "node_modules/.package-lock.json" ] || [ -f "package-lock.json" ]
check "Dependencies installed"

echo ""
echo "Checking build..."
echo ""

# Try to check TypeScript compilation (without actually building)
if [ -f "node_modules/.bin/tsc" ]; then
    check "TypeScript compiler available"
fi

if [ -d "dist" ]; then
    check "Frontend build exists (dist/)"
else
    warn "Frontend not built yet - run 'npm run build'"
fi

echo ""
echo "Checking file storage..."
echo ""

[ -d "uploads" ] || mkdir -p uploads
check "uploads/ directory exists"

[ -d "uploads/documents" ] || mkdir -p uploads/documents
check "uploads/documents/ directory exists"

[ -d "uploads/audio" ] || mkdir -p uploads/audio
check "uploads/audio/ directory exists"

# Check write permissions
touch uploads/.test 2>/dev/null && rm uploads/.test
check "uploads/ is writable"

echo ""
echo "========================================"
echo "Summary"
echo "========================================"
echo -e "${GREEN}Passed:${NC} $PASSED"
echo -e "${RED}Failed:${NC} $FAILED"
echo -e "${YELLOW}Warnings:${NC} $WARNINGS"
echo ""

if [ $FAILED -gt 0 ]; then
    echo -e "${RED}Some checks failed. Please fix the issues above.${NC}"
    exit 1
elif [ $WARNINGS -gt 0 ]; then
    echo -e "${YELLOW}Setup completed with warnings. Review the items above.${NC}"
    exit 0
else
    echo -e "${GREEN}All checks passed! Your setup is ready.${NC}"
    exit 0
fi
